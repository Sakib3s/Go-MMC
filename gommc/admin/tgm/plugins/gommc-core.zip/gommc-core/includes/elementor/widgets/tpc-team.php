<?php
/*
 * This template can be overridden by copying it to yourtheme/gommc-core/elementor/widgets/tpc-team.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{Widget_Base, Controls_Manager, Control_Media, Group_Control_Background, Group_Control_Box_Shadow, Group_Control_Typography, Utils};
use TPCAddons\GoMMC_Global_Variables as GoMMC_Globals;

class TPC_Team extends Widget_Base
{

    public function get_name()
    {
        return 'tpc-team';
    }

    public function get_title()
    {
        return esc_html__('Team', 'gommc-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }

    protected function register_controls()
    {
        /*-----------------------------------------------------------------------------------*/
        /*  Content
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'gommc-core'),
            ]
        );
        $this->add_control(
            'team_name',
            [
                'label' => esc_html__('Name', 'gommc-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic' => ['active' => true],
                'default' => esc_html__('John Doe', 'gommc-core'),
            ]
        );

        $this->add_control(
            'team_name_tag',
            [
                'label' => esc_html__('HTML Tag', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
                'default' => 'h3',
            ]
        );

        $this->add_control(
            'team_deg',
            [
                'label' => esc_html__('Degree', 'gommc-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic' => ['active' => true],
                'default' => esc_html__('Developer', 'gommc-core'),
            ]
        );

        $this->add_control(
            'deg_tag',
            [
                'label' => esc_html__('HTML Tag', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
                'default' => 'h4',
            ]
        );

        $this->add_control(
            'thumbnail',
            [
                'label' => esc_html__('Image', 'gommc-core'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

           $this->add_control(
            'team_link',
            [
                'label' => esc_html__('Team Details Link', 'gommc-core'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                 'default' => ['url' => '#'],
            ]
        );
        $this->add_responsive_control(
            'image_fixed_height',
            [
                'label' => __( 'Height', 'gommc-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 900,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 300,
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-team .items-image' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tpc-team .items-image img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

       $this->add_responsive_control(
            'space_top',
            [
                'label' => __( 'Position', 'gommc-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 210,
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-team .team-content' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

     $this->add_responsive_control(
            'space_between',
            [
                'label' => __( 'Name Degree Space', 'gommc-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 300,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-team .single-team__item .team-content .team-deg-tag' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  Carousel styles
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style',
            [
                'label' => esc_html__('Style', 'gommc-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'alignment',
            [
                'label' => __( 'Alignment', 'gommc-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'gommc-core' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'gommc-core' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'gommc-core' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-team .single-team__item' => 'text-align: {{VALUE}};',
                ],
                'default' => 'center',
                'separator' =>'after',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'name_typo',
                'label' => __( 'Name Typography', 'gommc-core' ),
                'selector' => '{{WRAPPER}} .tpc-team .single-team__item .team-content .team-title-tag',
            ]
        );

        $this->start_controls_tabs( 'name_color_tab' );

        $this->start_controls_tab(
            'custom_name_color',
            [ 'label' => esc_html__('Name Color' , 'gommc-core') ]
        );

        $this->add_control(
            'name_color',
            [
                'label' => esc_html__('Name Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .tpc-team .single-team__item .team-content .team-title-tag' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_name_color_hover',
            [ 'label' => esc_html__('Hover' , 'gommc-core') ]
        );

        $this->add_control(
            'name_color_hover',
            [
                'label' => esc_html__('Name Hover Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .tpc-team .single-team__item .team-content .team-title-tag:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'degree_type',
                'label' => __( 'Degree Typography', 'gommc-core' ),
                'selector' => '{{WRAPPER}} .tpc-team .single-team__item .team-content .team-deg-tag',
                'separator' =>'before',
            ]
        );
        $this->add_control(
            'degree_color',
            [
                'label' => esc_html__('Degree Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .tpc-team .single-team__item .team-content .team-deg-tag' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'border_radius',
            [
                'label' => esc_html__('Border Radius', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'default' => [
                    'top' => 10,
                    'right' => 10,
                    'bottom' => 10,
                    'left' => 10,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-team .single-team__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' =>'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'box_shadow',
                'selector' => '{{WRAPPER}} .tpc-team .single-team__item',
            ]
        );

        $this->add_control(
            'bg_overlay_heading',
            [
                'label' => esc_html__( 'Background Overlay', 'gommc-core' ),
                'type' => Controls_Manager::HEADING,
                
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'bg_overlay_color',
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .tpc-team .single-team__item .items-image::before',
            ]
        );
        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $this->add_render_attribute('tpc-team-wrap', 'class', 'tpc-team');

        if (!empty($settings['team_link']['url'])) {
            $this->add_link_attributes('cat_button', $settings['team_link']);
        }
        $this->add_render_attribute('team_link', 'class', 'team-item_image-link');
        if (!empty($settings['team_link']['url'])) {
            $this->add_link_attributes('team_link', $settings['team_link']);
        }

        $this->add_render_attribute('title_link', 'class', 'team-item_title-link');
        if (!empty($settings['team_link']['url'])) {
            $this->add_link_attributes('title_link', $settings['team_link']);
        }

        $this->add_render_attribute('team_img', [
            'class' => 'team-item_image',
            'src' => isset($settings['thumbnail']['url']) ? esc_url($settings['thumbnail']['url']) : '',
            'alt' => Control_Media::get_image_alt( $settings['thumbnail'] ),
        ]);

        ?>

        <div <?php echo $this->get_render_attribute_string('tpc-team-wrap'); ?>>

     
            <div class="single-team__item text-center">


            <?php if ($settings['team_link']['url']): ?>
                    <a <?php echo $this->get_render_attribute_string('title_link') ?>>
            <?php endif;?>

            <?php if (!empty($settings['thumbnail'])) {?>
                <div class="items-image">
                    <img <?php echo $this->get_render_attribute_string('team_img'); ?> />
                </div>
            <?php } ?>

                <div class="team-content">
   

                    <?php                 
                        if (!empty($settings['team_name'])) {
                            echo '<', $settings['team_name_tag'], ' class="team-title-tag">',
                                    $settings['team_name'],
                                '</', $settings['team_name_tag'], '>';
                        }
                    ?>

                    <?php                 
                        if (!empty($settings['team_deg'])) {
                            echo '<', $settings['deg_tag'], ' class="team-deg-tag">',
                                    $settings['team_deg'],
                                '</', $settings['deg_tag'], '>';
                        }
                    ?>
                   
                </div>
                <?php if(!empty($settings['team_link']['url'])) : ?>
                </a>
                <?php endif; ?>
            </div> 

        </div>

        <?php
    }

}