<?php
/*
 * This template can be overridden by copying it to yourtheme/gommc-core/elementor/widgets/tpc-feedback.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\{Widget_Base, Controls_Manager, Control_Media};
use Elementor\{Group_Control_Border, Group_Control_Box_Shadow, Group_Control_Background, Group_Control_Image_Size, Group_Control_Typography};
use Elementor\{Repeater, Utils};
use TPCAddons\GoMMC_Global_Variables as GoMMC_Globals;
use TPCAddons\Includes\{TPC_Feedback_Settings, TPC_Elementor_Helper};

class TPC_Features extends Widget_Base
{

    public function get_name()
    {
        return 'tpc-features';
    }

    public function get_title()
    {
        return esc_html__('Features', 'gommc-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }

   
protected function register_controls()
{

    $this->start_controls_section(
        'content_section',
        [
            'label' => __( 'Content', 'gommc-core' ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'image',
        [
            'label' => __( 'Choose Image', 'gommc-core' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Image_Size::get_type(),
        [
            'name'      => 'imagesize',
            'default'   => 'large',
            'separator' => 'none',
        ]
    );

    $this->add_control(
        'title',
        [
            'label' => __( 'Title', 'gommc-core' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'Learning & Fun', 'lms-core' ),
            'placeholder' => __( 'Type your title here', 'edubin-core' ),
            'label_block' => true
        ]
    );

    $this->add_control(
        'text',
        [
            'label' => __( 'Text', 'gommc-core' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => __( 'World-class training and development programs developed by top teachers', 'lms-core' ),
            'placeholder' => __( 'Type your text here', 'lms-core' ),
            'label_block' => true,
        ]
    );

    $this->add_control(
        'link',
        [
            'label' => __( 'Link', 'gommc-core' ),
            'type' => \Elementor\Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
            'show_external' => true,
            'default' => [
                'url' => '#',
            ],
        ]
    );



    $this->end_controls_section();

    $this->start_controls_section(
        'style_section',
        [
            'label' => __( 'Content', 'gommc-core' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );

    $this->add_control(
        'features_title',
        [
            'label' => esc_html__( 'Title', 'gommc-core' ),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
    );

    $this->add_control(
        'title_color',
        [
            'label' => esc_html__( 'Color', 'gommc-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .gommc-features-item .features-content .title a' => 'color: {{VALUE}};',
            ],
            
        ]
    );

    $this->add_responsive_control(
        'title_bottom_space',
        [
            'label' => esc_html__( 'Spacing', 'gommc-core' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .gommc-features-item .features-content .title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name' => 'title_typography',
            'selector' => '{{WRAPPER}} .gommc-features-item .features-content .title',
            'global' => [
                'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
            ],
        ]
    );

    $this->add_control(
        'features_text',
        [
            'label' => esc_html__( 'Text', 'gommc-core' ),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
    );

    $this->add_control(
        'text_color',
        [
            'label' => esc_html__( 'Color', 'gommc-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .gommc-features-item .features-content p' => 'color: {{VALUE}};',
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name' => 'text_typography',
            'selector' => '{{WRAPPER}} .gommc-features-item .features-content p',
            'global' => [
                'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
            ],
        ]
    );

    $this->add_control(
        'border_color',
        [
            'label' => esc_html__( 'Border Color', 'gommc-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .gommc-features-item .features-img' => 'border-color: {{VALUE}};',
            ],
            'separator' => 'before',
        ]
    );

    $this->add_responsive_control(
        'text_padding',
        [
            'label' => esc_html__( 'Padding', 'gommc-core' ),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', 'em', '%' ],
            'selectors' => [
                '{{WRAPPER}} .gommc-features-item .features-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
            'separator' => 'before',
        ]
    );

    $this->add_group_control(
        Group_Control_Background::get_type(),
        [
            'name' => 'media_overlay',
            'label' => esc_html__('Background Overlay', 'gommc-core'),
            'types' => ['classic', 'gradient'],
            'default' => 'classic',
            'selector' => '{{WRAPPER}} .gommc-features-item',
        ]
    );

    
    $this->end_controls_section();

}

protected function render($instance = []){ 
    $settings = $this->get_settings_for_display();
    ?>
    
            <div class="gommc-features-item">
                <div class="svg-shape">
                    <svg xmlns="http://www.w3.org/2000/svg" width="443px" height="235px">
                        <path fill-rule="evenodd" opacity="0.102" fill="rgb(0, 0, 0)" d="M25.0,5.999 C62.999,27.770 118.999,76.231 260.999,59.999 C402.999,43.768 530.999,160.254 362.999,187.999 C194.999,215.745 10.999,292.228 6.999,157.999 C2.999,23.770 -13.0,-15.770 25.0,5.999 Z" />
                    </svg>
                </div>

                <div class="features-img">
                        <?php if($settings['link']['url']):?>
                            <a <?php if($settings['link']['nofollow'] == 'on'): echo 'rel ="nofollow"'; endif;?> <?php if($settings['link']['is_external'] == 'on'): echo 'target="_blank"'; endif; ?> href="<?php echo $settings['link']['url'] ?>">
                        <?php endif ?>
                    
                        <?php echo Group_Control_Image_Size::get_attachment_image_html($settings, 'imagesize', 'image'); ?>
                    <?php if($settings['link']['url']): ?>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="features-content">
                    <h3 class="title">
                        <?php if($settings['link']['url']):?>
                            <a <?php if($settings['link']['nofollow'] == 'on'): echo 'rel ="nofollow"'; endif;?> <?php if($settings['link']['is_external'] == 'on'): echo 'target="_blank"'; endif; ?> href="<?php echo $settings['link']['url'] ?>">
                        <?php endif ?>

                            <?php echo $settings['title']; ?>  

                        <?php if($settings['link']['url']): ?>
                        </a>
                        <?php endif; ?>
                    </h3>
                    <p><?php echo $settings['text']; ?></p>
                </div>
            </div>



<?php
}


}
