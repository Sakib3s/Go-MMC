<?php
/*
 * This template can be overridden by copying it to yourtheme/gommc-core/elementor/widgets/tpc-courses.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{Widget_Base, Controls_Manager};
use Elementor\{
    Group_Control_Typography, 
    Group_Control_Background, 
    Group_Control_Image_Size, 
    Group_Control_Box_Shadow
};
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

use TPCAddons\GoMMC_Global_Variables as GoMMC_Globals;
use TPCAddons\Includes\{TPC_Loop_Settings};
use TPCAddons\Templates\TPCFilterCoursesLP;

use GoMMC_Theme_Helper as GoMMC;

class TPC_Filter_Courses extends Widget_Base
{
    public function get_name() {
        return 'tpc-filter-courses';
    }

    public function get_title() {
        return esc_html__('LearnPress Filter Courses', 'gommc-core');
    }

    public function get_icon() {
        return 'tpc-icon eicon-filter';
    }

    public function get_categories() {
        return [ 'tpc-extensions' ];
    }

    public function get_script_depends()
    {
        return ['jquery-appear'];
    }

    protected function register_controls()
    {

         $this->start_controls_section(
            'learnpress_courses',
            [
                'label' => __( 'Course Query', 'gommc-core' ),
            ]
        );

        $this->add_control(
            'course_style',
            [
                'label' => __( 'Style', 'gommc-core' ),
                'type' => Controls_Manager::SELECT,
                'default' => '1',
                'options' => [
                    '1'   => __( 'Style 1', 'gommc-core' ),
                    '2'   => __( 'Style 2', 'gommc-core' ),
                    '3'   => __( 'Style 3', 'gommc-core' ),
                ],
            ]
        );
        $this->add_control(
            'grid_columns',
            [
                'label' => esc_html__('Grid Columns Amount', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('1 / One', 'gommc-core'),
                    '2' => esc_html__('2 / Two', 'gommc-core'),
                    '3' => esc_html__('3 / Three', 'gommc-core'),
                    '4' => esc_html__('4 / Four', 'gommc-core'),
                    '5' => esc_html__('5 / Five', 'gommc-core'),
                ],
                'default' => '3',
            ]
        );

        $this->add_control(
            'post_limit',
            [
                'label' => __('Number of Course', 'gommc-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 6,
            ]
        );
        $this->add_control(
            'title_length',
            [
                'label' => __( 'Title Length', 'gommc-core' ),
                'type' => Controls_Manager::NUMBER,
                'step' => 1,
                'default' => 15,
                'separator'=>'before',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'filter_media_option',
            [
                'label' => __( 'Media', 'gommc-core' ),
            ]
        );
        $this->add_control(
            'show_media',
            [
                'label' => esc_html__( 'Media', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );  
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'image',
                'default' => 'large',
                'separator' => 'none',
            ]
        );
        $this->add_responsive_control(
            'lp_image_height',
            [
                'label' => __( 'Image Height', 'gommc-core' ),
                'description' => __('Keep blank value for the default', 'gommc-core'),
                'type' => Controls_Manager::SLIDER,
                'separator' => 'before',
                'size_units' => [ 'px'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 400,
                        'step' => 1,
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .course__container .course__media img' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .gommc-course.gommc-course-list .course__media img' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .gommc-single-course-2 .image img' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} gommc-course .course__media img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'course_filter_option',
            [
                'label' => __( 'Filter', 'gommc-core' ),
            ]
        );
        $this->add_control(
            'filter_top_type',
            [
                'label' => __('Filter Layout', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '2',
                'options' => [
                    '1' => __('Layout 1', 'gommc-core'),
                    '2' => __('Layout 2', 'gommc-core'),
                ],
            ]
        );
        $this->add_control(
            'filter_grid_list',
            [
                'label' => __('Default Grid/List Layout', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'list',
                'options' => [
                    'grid' => __('Grid', 'gommc-core'),
                    'list' => __('List', 'gommc-core'),
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'course_filter_top_option',
            [
                'label' => __( 'Filter Top', 'gommc-core' ),
            ]
        );

        $this->add_control(
            'show_filter_top',
            [
                'label' => esc_html__( 'Filter Top', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'show_filter_search',
            [
                'label' => esc_html__( 'Search', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'filter_search_placeholder',
            [
              'label' => __( 'Search Placeholder', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'Search courses',
              'label_block' => true,
          ]
        ); 
        $this->add_control(
            'filter_ajax_search_text',
            [
              'label' => __( 'Ajax Search Text', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'Searching..',
              'label_block' => true,
          ]
        ); 
        $this->add_control(
            'show_filter_order',
            [
                'label' => esc_html__( 'Order by', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'filter_newly_published',
            [
              'label' => __( 'Newly Published', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'Newly Published',
              'label_block' => true,
          ]
        ); 
        $this->add_control(
            'filter_oldest_published',
            [
              'label' => __( 'Oldest Published', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'Oldest Published',
              'label_block' => true,
          ]
        ); 
        $this->add_control(
            'filter_a_to_z',
            [
              'label' => __( 'Course Title (A-Z)', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'Course Title (A-Z)',
              'label_block' => true,
          ]
        ); 
        $this->add_control(
            'filter_z_to_a',
            [
              'label' => __( 'Course Title (Z-A)', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'Course Title (Z-A)',
              'label_block' => true,
          ]
        ); 
        $this->add_control(
            'show_filter_showing_results',
            [
                'label' => esc_html__( 'Showing Results', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'filter_showing',
            [
              'label' => __( 'Showing', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'Showing',
              'label_block' => true,
          ]
        ); 
        $this->add_control(
            'filter_results',
            [
              'label' => __( 'Total Results', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'results',
              'label_block' => true,
          ]
        ); 
        $this->add_control(
            'show_filter_grid_list',
            [
                'label' => esc_html__( 'Grid/List', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'course_filter_sidebar_option',
            [
                'label' => __( 'Filter Sidebar', 'gommc-core' ),
            ]
        );
        $this->add_control(
            'show_filter_section',
            [
                'label' => esc_html__( 'Filter', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'sidebar_position',
            [
                'label' => __('Filter Position', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'left',
                'options' => [
                    'left' => __('Left', 'gommc-core'),
                    'right' => __('Right', 'gommc-core'),
                ],
            ]
        );
        $this->add_control(
            'show_filter_cat',
            [
                'label' => esc_html__( 'Category', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'separator' => 'before',
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );  
        $this->add_control(
            'filter_cat_text',
            [
              'label' => __( 'Category Text', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'Filter by category',
              'label_block' => true,
          ]
        );
        $this->add_control(
            'show_filter_cat_count',
            [
                'label' => esc_html__( 'Category Count', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,

                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );  
        $this->add_control(
            'show_filter_tag',
            [
                'label' => esc_html__( 'Tag', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'separator' => 'before',
                'return_value' => 'yes',
                'default' => '',
            ]
        );
        $this->add_control(
            'filter_tag_text',
            [
              'label' => __( 'Tag Text', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'Tag',
              'label_block' => true,
          ]
        );
        $this->add_control(
            'show_filter_tag_count',
            [
                'label' => esc_html__( 'Tag Count', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'show_filter_author',
            [
                'label' => esc_html__( 'Instructor', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                 'separator' => 'before',
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'filter_author_text',
            [
              'label' => __( 'Instructor Text', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'Instructor',
              'label_block' => true,
          ]
        );
        $this->add_control(
            'show_filter_author_count',
            [
                'label' => esc_html__( 'Instructor Count', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'show_filter_language',
            [
                'label' => esc_html__( 'Languages', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'separator' => 'before',
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );  
        $this->add_control(
            'filter_language_text',
            [
              'label' => __( 'Languages Text', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'Languages',
              'label_block' => true,
          ]
        ); 
        $this->add_control(
            'show_filter_language_count',
            [
                'label' => esc_html__( 'Languages Count', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );  
        $this->add_control(
            'show_filter_level',
            [
                'label' => esc_html__( 'Level', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'separator' => 'before',
                'return_value' => 'yes',
                'default' => '',
            ]
        ); 
        $this->add_control(
            'filter_level_text',
            [
              'label' => __( 'Level Text', 'gommc-core' ),
              'type'  => Controls_Manager::TEXT,
              'default' => 'Level',
              'label_block' => true,
          ]
        );     
        $this->end_controls_section();

        $this->start_controls_section(
            'course_meta_option',
            [
                'label' => __( 'Course Meta', 'gommc-core' ),
            ]
        );
        $this->add_control(
            'show_price',
            [
                'label' => esc_html__( 'Price', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );   
        $this->add_control(
            'show_full_price',
            [
                'label' => esc_html__( 'Show Price .00', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => '',
                'condition' => [
                    'course_style' => '1',
                ]
            ]
        );     
        $this->add_control(
            'show_review',
            [
                'label' => esc_html__( 'Review', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'show_review_text',
            [
                'label' => esc_html__( 'Review Text', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'show_instructor_img',
            [
                'label' => esc_html__( 'Instructor Image', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );        
        $this->add_control(
            'show_instructor_name',
            [
                'label' => esc_html__( 'Instructor Name', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'show_title',
            [
                'label' => esc_html__( 'Title', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'show_enroll',
            [
                'label' => esc_html__( 'Enroll', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'course_style!' => '4',
                ]
            ]
        );
        $this->add_control(
            'show_enroll_btn',
            [
                'label' => esc_html__( 'Enroll Button', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'course_style!' => '4',
                ]
            ]
        );
        $this->add_control(
            'show_cat',
            [
                'label' => esc_html__( 'Category', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'course_style!' => '4',
                ]
            ]
        );
        $this->add_control(
            'show_lesson',
            [
                'label' => esc_html__( 'Lesson', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'course_style!' => '4',
                ]
            ]
        );
        $this->add_control(
            'show_duration',
            [
                'label' => esc_html__( 'Duration', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'show_quiz',
            [
                'label' => esc_html__( 'Quiz', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => '',
                'condition' => [
                    'course_style!' => '4',
                ]
            ]
        );
        $this->add_control(
            'show_comments',
            [
                'label' => esc_html__( 'Comments', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'course_style!' => '4',
                ]
            ]
        );

        $this->end_controls_section(); // Option End

        // Popup
        $this->start_controls_section(
            'course_popup_option',
            [
                'label' => __( 'Hover Popup', 'gommc-core' ),
            ]
        );
        $this->add_control(
            'show_hover_popup',
            [
                'label' => esc_html__( 'Hover Popup', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'show_popup_instructor',
            [
                'label' => esc_html__( 'Instructor', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'show_popup_cat',
            [
                'label' => esc_html__( 'Category', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'show_popup_price',
            [
                'label' => esc_html__( 'Price', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'show_popup_title',
            [
                'label' => esc_html__( 'Title', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'show_popup_lesson',
            [
                'label' => esc_html__( 'Lesson', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'show_popup_duration',
            [
                'label' => esc_html__( 'Duration', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'show_popup_excerpt',
            [
                'label' => esc_html__( 'Excerpt', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_control(
            'show_popup_btn',
            [
                'label' => esc_html__( 'Excerpt', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->end_controls_section();

        // Pagination 
        $this->start_controls_section(
        'pagination_section',
            [
                'label' => __( 'Pagination', 'gommc-core' ),
            ]
        );

        $this->add_control(
        'pagi_on_off',
            [
                'label' => esc_html__( 'Pagination', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        ); 
        $this->add_responsive_control(
        'pagi_align',
            [
                'label'         => esc_html__( 'Alignment', 'gommc-core' ),
                'type'          => Controls_Manager::CHOOSE,
                'options'       => [
                    'left'      => [
                        'title'=> esc_html__( 'Left', 'gommc-core' ),
                        'icon' => 'fa fa-align-left',
                        ],
                    'center'    => [
                        'title'=> esc_html__( 'Center', 'gommc-core' ),
                        'icon' => 'fa fa-align-center',
                        ],
                    'right'     => [
                        'title'=> esc_html__( 'Right', 'gommc-core' ),
                        'icon' => 'fa fa-align-right',
                        ],
                    ],
                'toggle'        => false,
                'default'       => 'center',
                'selectors'     => [
                    '{{WRAPPER}} .tpc-paginate_links' => 'text-align: {{VALUE}};',
                    ],
            ]
        );
        $this->add_control(
            'pagi_end_size',
            [
                'label' => __('End Size', 'gommc-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 2,
            ]
        );  
        $this->add_control(
        'pagi_mid_size',
            [
                'label' => __('Mid Size', 'gommc-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 1,
            ]
        );  

        $this->add_control(
        'pagi_show_all',
            [   
                'label' => esc_html__( 'Show All', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_off' => __('No', 'gommc-core'),
                'label_on' => __('Yes', 'gommc-core'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );
        $this->end_controls_section();

        // Style Title tab section
        $this->start_controls_section(
            'filter_style_section',
            [
                'label' => __( 'Filter Top', 'gommc-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'filter_sidebar_top_bg_color',
            [
                'label' => __( 'Background', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default'=>'',
                'selectors' => [
                    '{{WRAPPER}} .switch-layout-container' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_section();

        // Style Title tab section
        $this->start_controls_section(
            'filter_sidebar_style_section',
            [
                'label' => __( 'Filter Sidebar', 'gommc-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
                   
        $this->add_control(
            'filter_widget_color',
            [
                'label' => __( 'Heading Color', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default'=>'',
                'selectors' => [
                    '{{WRAPPER}} .gommc-course-filter-wrapper .widget-title' => 'color: {{VALUE}}',
                ],
            ]
        );   
        $this->add_control(
            'filter_headeing_bg_color',
            [
                'label' => __( 'Heading Border', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default'=>'',
                'selectors' => [
                    '{{WRAPPER}} .widget .widget-title:before' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'filter_widget_count_typography',
                'label' => __( 'Heading Typography', 'gommc-core' ),
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
                'selector' => '{{WRAPPER}} .gommc-course-filter-wrapper .widget-title',
            ]
        );
        $this->add_control(
            'filter_sidebar_bg_color',
            [
                'label' => __( 'Sidebar Background', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default'=>'',
                'selectors' => [
                    '{{WRAPPER}} .gommc-course-filter-wrapper .single-filter.widget' => 'background: {{VALUE}}',
                ],
            ]
        ); 
        $this->add_responsive_control(
            'filter_section_height',
            [
                'label' => __( 'Widget Fixed Height', 'gommc-core' ),
                'description' => __('Keep blank value for the default', 'gommc-core'),
                'type' => Controls_Manager::SLIDER,
                'separator' => 'before',
                'size_units' => [ 'px'],
                'range' => [
                    'px' => [
                        'min' => 70,
                        'max' => 800,
                        'step' => 1,
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-course-filter-wrapper .filter-content' => 'max-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );  
        $this->add_responsive_control(
            'filter_widget_padding',
            [
                'label' => __( 'Widget Padding', 'gommc-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-sidebar-filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'filter_widget_margin',
            [
                'label' => __( 'Widget Margin', 'gommc-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-sidebar-filter' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        //Level 
        $this->start_controls_tabs('filter_level_style_tabs');

                $this->start_controls_tab(
                    'filter_style_normal_tab',
                    [
                        'label' => __( 'Normal', 'gommc-core' ),
                    ]
                );

                    $this->add_control(
                        'filter_level_color',
                        [
                            'label' => __( 'Level Color', 'gommc-core' ),
                            'type' => Controls_Manager::COLOR,
                            'default'=>'',
                            'selectors' => [
                                '{{WRAPPER}} .gommc-course-filter-wrapper .single-filter.widget label' => 'color: {{VALUE}}',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Typography::get_type(),
                        [
                            'name' => 'filter_level_typography',
                            'label' => __( 'Level Typography', 'gommc-core' ),
                            'global' => [
                                'default' => Global_Typography::TYPOGRAPHY_TEXT,
                            ],
                            'selector' => '{{WRAPPER}} .gommc-course-filter-wrapper .single-filter.widget label',
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Typography::get_type(),
                        [
                            'name' => 'filter_level_count_typography',
                            'label' => __( 'Count Typography', 'gommc-core' ),
                            'global' => [
                                'default' => Global_Typography::TYPOGRAPHY_TEXT,
                            ],
                            'selector' => '{{WRAPPER}} .gommc-course-filter-wrapper .filter-checkbox-count',
                        ]
                    );

                    $this->add_responsive_control(
                        'filter_level_padding',
                        [
                            'label' => __( 'Level Padding', 'gommc-core' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors' => [
                                '{{WRAPPER}} .gommc-course-filter-wrapper .single-filter.widget label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );

                $this->end_controls_tab(); // Normal Tab end

                $this->start_controls_tab(
                    'filter_level_style_hover_tab',
                    [
                        'label' => __( 'Hover', 'gommc-core' ),
                    ]
                );
                $this->add_control(
                    'filter_inpur_hover_color',
                    [
                        'label' => __( 'Level Hover Color', 'gommc-core' ),
                        'type' => Controls_Manager::COLOR,
                        'default'=>'',
                        'selectors' => [
                            '{{WRAPPER}} .gommc-course-filter-wrapper .single-filter.widget label:hover' => 'color: {{VALUE}}',
                        ],
                    ]
                );

                $this->end_controls_tab(); // Hover Tab end

            $this->end_controls_tabs();

        $this->end_controls_section();

        // Style Meta tab section
        $this->start_controls_section(
            'post_meta_style_section',
            [
                'label' => __( 'Course Meta', 'gommc-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'meta_color',
            [
                'label' => __( 'Icon Color', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default'=>'',
                'selectors' => [
                    '{{WRAPPER}} .gommc-single-course-1 .course-bottom .admin ul li i' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-course .course__content--meta span i' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'course_style!' => '4',
                ]
            ]
        );

        $this->add_control(
            'meta_text_color',
            [
                'label' => __( 'Meta Text Color', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default'=>'',
                'separator' => 'after',
                'selectors' => [
                    '{{WRAPPER}} .gommc-single-course-1 .course-bottom .admin ul li span.enroll-users' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course-1 .course-bottom .admin ul li a span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-course .course__content--meta span' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'course_style!' => '4',
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'author_typography',
                'label' => __( 'Instructor Typography', 'gommc-core' ),
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_TEXT,
                ],
                'selector' => '{{WRAPPER}} .gommc-single-course-1 .course-bottom .name .ins-name a, .gommc-single-course-2>.thum .course-teacher .name h6 a, .gommc-course .author__name',
            ]
        );
        $this->add_control(
            'author_color',
            [
                'label' => __( 'Instructor Color', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default'=>'',
                'separator' => 'after',
                'selectors' => [
                    '{{WRAPPER}} .gommc-single-course-1 .course-bottom .name .ins-name a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course-2>.thum .course-teacher .name h6 a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-course .author__name' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'price_typography',
                'label' => __( 'Price Typography', 'gommc-core' ),
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
                'selector' => '{{WRAPPER}} .gommc-single-course-1 .thum .gommc-course-price-1 span, .gommc-single-course-1 .thum .gommc-course-price-2 span, .gommc-single-course-1 .thum .gommc-course-price-3 span, .gommc-single-course-2 > .thum .gommc-course-price-4 span, .gommc-course .course-price .price',
            ]
        );
        $this->add_control(
            'price_color',
            [
                'label' => __( 'Price Color', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default'=>'',
                'selectors' => [
                    '{{WRAPPER}} .gommc-single-course-1 .thum .gommc-course-price-1 span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course-1 .thum .gommc-course-price-2 span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course-1 .thum .gommc-course-price-3 span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course-2 > .thum .gommc-course-price-4 span' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-course .price' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'price_bg_color',
            [
                'label' => __( 'Price Background', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default'=>'',
                'selectors' => [
                    '{{WRAPPER}} .gommc-single-course-1 .thum .gommc-course-price-1 span' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course-1 .thum .gommc-course-price-2 span' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course-1 .thum .gommc-course-price-3 span' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course-2 > .thum .gommc-course-price-4 span' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'price_bg_size',
            [
                'label' => __( 'Price Background Size', 'gommc-core' ),
                'type' => Controls_Manager::SLIDER,
                'separator' => 'after',
                'size_units' => [ 'px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                        'step' => 1,
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-single-course-1 .thum .gommc-course-price-1 span, .gommc-single-course-2>.thum .gommc-course-price-4 span' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'review_typography',
                'label' => __( 'Review Typography', 'gommc-core' ),
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
                'selector' => '{{WRAPPER}} .gommc-single-course-1 .course-content span.course-reviews',
            ]
        );
        $this->add_control(
            'review_color',
            [
                'label' => __( 'Review Color', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default'=>'',
                'selectors' => [
                    '{{WRAPPER}} .gommc-single-course-1 .star-rating span:before' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course .star-rating:before' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course-2 .star-rating:before' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course-2 .star-rating span:before' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'meta_cat_color',
            [
                'label' => esc_html__('Category Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'separator' => 'before',
                'dynamic' => ['active' => true],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .course__categories a, .course__categories a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_cat_bg_color',
            [
                'label' => esc_html__('Category Background Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .course__categories a, .course__categories a' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();


        // Course body style
        $this->start_controls_section(
            'course_style_section',
            [
                'label' => __( 'Course Style', 'gommc-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_responsive_control(
                'courses_align',
                [
                    'label' => __( 'Alignment', 'gommc-core' ),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => __( 'Left', 'gommc-core' ),
                            'icon' => 'fa fa-align-left',
                        ],
                        'center' => [
                            'title' => __( 'Center', 'gommc-core' ),
                            'icon' => 'fa fa-align-center',
                        ],
                        'right' => [
                            'title' => __( 'Right', 'gommc-core' ),
                            'icon' => 'fa fa-align-right',
                        ],
                        'justify' => [
                            'title' => __( 'Justified', 'gommc-core' ),
                            'icon' => 'fa fa-align-justify',
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .gommc-single-course-1' => 'text-align: {{VALUE}};',
                        '{{WRAPPER}} .gommc-single-course-2' => 'text-align: {{VALUE}};',
                        '{{WRAPPER}} .gommc-single-course-3' => 'text-align: {{VALUE}};',
                        '{{WRAPPER}} .gommc-course' => 'text-align: {{VALUE}};',
                    ],
                    'default' => 'left',
                    'separator' =>'before',
                ]
            );
            $this->start_controls_tabs('body_box_tabs');

                $this->start_controls_tab(
                    'body_box_normal_tab',
                    [
                        'label' => __( 'Normal', 'gommc-core' ),
                    ]
                );

                $this->add_group_control(
                    Group_Control_Box_Shadow::get_type(),
                    [
                        'name' => 'box_shadow',
                        'selector' => '{{WRAPPER}} .gommc-single-course, .gommc-single-course-2, .gommc-course .course',
                    ]
                );

                $this->end_controls_tab(); // Normal Tab end

                $this->start_controls_tab(
                    'body_box_hover_tab',
                    [
                        'label' => __( 'Hover', 'gommc-core' ),
                    ]
                );

                $this->add_group_control(
                    Group_Control_Box_Shadow::get_type(),
                    [   'label' => __( 'Box Shadow Hover', 'gommc-core' ),
                        'name' => 'box_shadow_hover',
                        'selector' => '{{WRAPPER}} .gommc-single-course:hover, .gommc-single-course-2:hover, .gommc-course .course:hover',
                    ]
                );

                $this->end_controls_tab(); // Hover Tab end

            $this->end_controls_tabs();
            
         $this->add_control(
            'course_bg_color',
            [
                'label' => __( 'Background', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default'=>'',
                'selectors' => [
                    '{{WRAPPER}} .gommc-single-course .course-content' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course-2' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-single-course-1' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .gommc-courses .course' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();


        // Style Title tab section
        $this->start_controls_section(
            'lp_course_title_style_section',
            [
                'label' => __( 'Course Title', 'gommc-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition'=>[
                    'show_review'=>'yes',
                ]
            ]
        );
            
            $this->start_controls_tabs('title_style_tabs');

                $this->start_controls_tab(
                    'title_style_normal_tab',
                    [
                        'label' => __( 'Normal', 'gommc-core' ),
                    ]
                );

                    $this->add_control(
                        'title_color',
                        [
                            'label' => __( 'Color', 'gommc-core' ),
                            'type' => Controls_Manager::COLOR,
                            'default'=>'',
                            'selectors' => [
                                '{{WRAPPER}} .gommc-single-course-1 .course-content .course-title a' => 'color: {{VALUE}}',
                                '{{WRAPPER}} .gommc-single-course-2 .content .course-title a' => 'color: {{VALUE}}',
                                '{{WRAPPER}} .gommc-course .course__title a' => 'color: {{VALUE}}',
                            ],
                        ]
                    );

                    $this->add_group_control(
                        Group_Control_Typography::get_type(),
                        [
                            'name' => 'title_typography',
                            'label' => __( 'Typography', 'gommc-core' ),
                            'global' => [
                                'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                            ],
                            'selector' => '{{WRAPPER}} .gommc-single-course-1 .course-content .course-title a, .gommc-single-course-2 .content .course-title a, .gommc-course .course__title a',
                        ]
                    );
                $this->add_responsive_control(
                    'fixed_title_height',
                    [
                        'label' => __( 'Fixed Title Height', 'gommc-core' ),
                        'description' => __('Keep blank value for the default', 'gommc-core'),
                        'type' => Controls_Manager::SLIDER,
                        'separator' => 'before',
                        'size_units' => [ 'px'],
                        'range' => [
                            'px' => [
                                'min' => 30,
                                'max' => 300,
                                'step' => 1,
                            ]
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .gommc-course .course__title' => 'height: {{SIZE}}{{UNIT}};',
                        ],
                    ]
                );
                    $this->add_responsive_control(
                        'title_padding',
                        [
                            'label' => __( 'Padding', 'gommc-core' ),
                            'type' => Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em' ],
                            'selectors' => [
                                '{{WRAPPER}} .gommc-single-course-1 .course-content .course-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .gommc-single-course-2 .content .course-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                '{{WRAPPER}} .gommc-course .course__title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ]
                    );

                $this->end_controls_tab(); // Normal Tab end

                $this->start_controls_tab(
                    'title_style_hover_tab',
                    [
                        'label' => __( 'Hover', 'gommc-core' ),
                    ]
                );
                $this->add_control(
                    'title_hover_color',
                    [
                        'label' => __( 'Color', 'gommc-core' ),
                        'type' => Controls_Manager::COLOR,
                        'default'=>'',
                        'selectors' => [
                            '{{WRAPPER}} .gommc-single-course-1 .course-content .course-title a:hover' => 'color: {{VALUE}}',
                            '{{WRAPPER}} .gommc-single-course-2 .content .course-title:hover a' => 'color: {{VALUE}}',
                            '{{WRAPPER}} .gommc-course .course__title a:hover' => 'color: {{VALUE}}',
                        ],
                    ]
                );

                $this->end_controls_tab(); // Hover Tab end

            $this->end_controls_tabs();

        $this->end_controls_section();


    }

    protected function render( $instance = [] ) { 

    $settings   = $this->get_settings_for_display();

    $sidebar_position = $settings['sidebar_position'];

    $this->add_render_attribute( 'gommc_grid_columns', 'class', 'col-sm-6 col-lg-'.$settings['grid_columns'] );
        // Price style
    $this->add_render_attribute( 'gommc_price_style', 'class', 'gommc-course-price-'.$settings['course_style'] );

    // Customizer option
    global $wp, $wp_query;

    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

    $selected_cat = !empty($_GET['course_category']) ? (array) $_GET['course_category'] : array();
    $selected_cat = array_map('sanitize_text_field', $selected_cat);
    $selected_cat = array_map('intval', $selected_cat);

    $is_queried_object = false;
    if (isset($wp_query->queried_object->term_id)) {
        $is_queried_object = true;
        $selected_cat = array($wp_query->queried_object->term_id);
    }

    $selected_tag = !empty($_GET['course_tag']) ? (array) $_GET['course_tag'] : array();
    $selected_tag = array_map('sanitize_text_field', $selected_tag);
    $selected_tag = array_map('intval', $selected_tag);

    $selected_language= !empty($_GET['course_language']) ? (array) $_GET['course_language'] : array();
    $selected_language = array_map('sanitize_text_field', $selected_language);
    $selected_language = array_map('intval', $selected_language);

    $selected_author = !empty($_GET['course_author']) ? (array) $_GET['course_author'] : array();
    $selected_author = array_map('sanitize_text_field', $selected_author);

    $selected_level = !empty($_GET['course_level']) ? (array) $_GET['course_level'] : array('all_levels');
    $selected_level = array_map('sanitize_text_field', $selected_level);

    $course_terms_cat = get_terms(array(
        'taxonomy' => 'course_category',
        'hide_empty' => true,
        'parent' => 0,
    ));

    $course_terms_tag = get_terms(array(
        'taxonomy' => 'course_tag',
        'hide_empty' => true,
    ));

    $course_terms_language = get_terms(array(
        'taxonomy' => 'course_language',
        'hide_empty' => true,
    ));

    $course_levels =  lp_course_level();

    $course_level_filter = !empty($selected_level) && !in_array('all_levels', $selected_level) ? array(
        'key' => '_lp_level',
        'value' => $selected_level,
        'compare' => 'IN',
    ) : array();

    if (!empty($selected_author)) {
           $totatl_author_ides = $selected_author;
       }
       else {
            $totatl_author_ides = '';
    }

    $args = array(
        'post_type' => 'lp_course',
        'post_status' => 'publish',
        'author__in' => $totatl_author_ides,
        'paged' => $paged,
        'posts_per_page' => $settings['post_limit'],
        's' => get_search_query(),
        'meta_query' => array(
            $course_level_filter,
        ),
        'tax_query' => array(
            'relation' => 'OR',
            array(
                'taxonomy' => 'course_category',
                'field' => 'term_id',
                'terms' => $selected_cat,
                'operator' => !empty($selected_cat) ? 'IN' : 'NOT IN',
            ),
            array(
                'taxonomy' => 'course_tag',
                'field' => 'term_id',
                'terms' => $selected_tag,
                'operator' => !empty($selected_tag) ? 'IN' : 'NOT IN',
            ),
            array(
                'taxonomy' => 'course_language',
                'field' => 'term_id',
                'terms' => $selected_language,
                'operator' => !empty($selected_language) ? 'IN' : 'NOT IN',
            ),
        ),
    );

    $course_filter = 'newest_first';
    if (!empty($_GET['lp_course_filter'])) {
        $course_filter = sanitize_text_field($_GET['lp_course_filter']);
    }
    switch ($course_filter) {
        case 'newest_first':
            $args['orderby'] = 'ID';
            $args['order'] = 'desc';
            break;
        case 'oldest_first':
            $args['orderby'] = 'ID';
            $args['order'] = 'asc';
            break;
        case 'course_title_az':
            $args['orderby'] = 'post_title';
            $args['order'] = 'asc';
            break;
        case 'course_title_za':
            $args['orderby'] = 'post_title';
            $args['order'] = 'desc';
            break;
    }

    $query = new \WP_Query( $args );
    ob_start();?>


    <div class="row">

    <?php
        // get current url with query string.
        $current_url =  home_url( $wp->request ); 
        // get the position where '/page.. ' text start.
        $pos = strpos($current_url , '/page');
        // remove string from the specific postion
        $finalurl = substr($current_url,0,$pos);

    ?>
    <?php if ($settings['show_filter_section'] && $settings['filter_top_type'] == '2'): ?>

    <div class="col-12 col-md-3 col-sm-4 tpc_col-3  order-2 gommc-order-<?php echo $sidebar_position == 'right' ? 2 : 1; ?> ">
        <?php  
            require_once plugin_dir_path(dirname(__FILE__)) . 'templates/template-part/lp/tpc-filter-sidebar.php';
        ?>
    </div>
    <?php endif; ?>

        <div class="col col-md-9 col-sm-8 tpc_col-<?php if($settings['show_filter_section'] && $settings['filter_top_type'] == '2') : echo '9'; else : echo '12'; endif; ?>  order-1 gommc-order-<?php echo $sidebar_position == 'right' ? 1 : 2; ?> gommc- ">

        <?php  
        if ($settings['filter_top_type'] == '1') : 
            require_once plugin_dir_path(dirname(__FILE__)) . 'templates/template-part/lp/tpc-filter-top.php';
        elseif($settings['filter_top_type'] == '2') : 
            require_once plugin_dir_path(dirname(__FILE__)) . 'templates/template-part/lp/tpc-filter-top-2.php';
        endif;
        ?>

      <!--  Loop course -->
        <div class="gommc-courses-wrap">
            <div class="gommc-lp-course-wrapper-<?php echo esc_attr($settings['course_style']); ?>  tpc-courses__grid grid-col--<?php echo esc_attr($settings['grid_columns']); ?>">


                <div id="gommcdiv2" class="row">
                    <?php
                        if( $query->have_posts() ):
                        while( $query->have_posts() ): $query->the_post();

                            $course    = LP()->global['course'];
                            $course_id = get_the_ID();
                            $count = $course->get_users_enrolled();
 
 
                            require plugin_dir_path(dirname(__FILE__)) . 'templates/template-part/lp/tpc-filter-courses-list.php';    
                

                        endwhile; wp_reset_postdata(); wp_reset_query();  

                        endif; ?>
                </div>

                <div id="gommcdiv1" class="row" style="display:none;">
                    <?php
                        if( $query->have_posts() ):
                        while( $query->have_posts() ): $query->the_post();

                            $course    = LP()->global['course'];
                            $course_id = get_the_ID();
                            $count = $course->get_users_enrolled();

   
                            require plugin_dir_path(dirname(__FILE__)) . 'templates/template-part/lp/tpc-filter-courses-grid.php';
                       
                      endwhile; wp_reset_postdata(); wp_reset_query(); 
                      endif; ?>
                </div>

            </div>
        </div>
      <!--  //End loop course -->

      <!--   pagination -->
             <?php 
             if ($settings['pagi_on_off']) : ?>

                    <nav class="tpc-paginate_links" role="navigation" aria-label="Posts">
                        <div class="nav-links">
                            <?php 
                                echo paginate_links( array(
                                    'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
                                    'total'        => $query->max_num_pages,
                                    'current'      => max( 1, get_query_var( 'paged' ) ),
                                    'format'       => '?paged=%#%',
                                    'show_all'     => $settings['pagi_show_all'],
                                    'type'         => 'plain',
                                    'end_size'     => $settings['pagi_end_size'],
                                    'mid_size'     => $settings['pagi_mid_size'],
                                    'prev_next'    => true,
                                    'prev_text' => '<i class="flaticon-back" aria-hidden="true"></i>',
                                    'next_text' => '<i class="flaticon-next" aria-hidden="true"></i>',
                                    'add_args'     => false,
                                    'add_fragment' => '',
                                ) );
                            ?>
                        </div> <!-- row -->  
                    </nav>
                <?php endif; //end pagination ?>
        <!--  //End pagination -->

        </div>
    </div>

    <?php

    $output = ob_get_contents();
    ob_end_clean();
    echo $output;


    }


}

