          <?php if ($settings['show_filter_top']): ?>
            <div class="gommc-course-top switch-layout-container ">
            <?php if ($settings['show_filter_grid_list']): ?>
               <div class="filter__top gommc-course-switch-layout switch-layout">
                  <a href="javascript:void(0)" id="gommc_showdiv2" ><i class="fa fa-list-ul"></i></a>
                  <a href="javascript:void(0)" id="gommc_showdiv1" ><i class="fa fa-th-large"></i></a>
               </div>
            <?php endif; ?>
            <?php if ($settings['show_filter_showing_results']): ?>
               <div class="filter__top course-index">
                 <?php $count = 0;?>
                  <span><?php echo esc_html($settings['filter_showing']); ?> <?php printf('%d - %d of %d', $count + 1, $count + $query->post_count, $query->found_posts ); ?> <?php echo esc_html($settings['filter_results']); ?></span>
               </div>
            <?php endif; ?>
            <?php if ($settings['show_filter_order']): ?>
               <div class="filter__top gommc-course-order">
                   <form class="gommc-course-filter-form" method="get">
                        <select name="lp_course_filter" class="small">
                            <option value="newest_first" <?php if (isset($_GET["lp_course_filter"]) ? selected("newest_first", $_GET["lp_course_filter"]) : "");?> ><?php echo esc_html($settings['filter_newly_published']); ?></option>
                            <option value="oldest_first" <?php if (isset($_GET["lp_course_filter"]) ? selected("oldest_first", $_GET["lp_course_filter"]) : "");?>><?php echo esc_html($settings['filter_oldest_published']); ?></option>
                            <option value="course_title_az" <?php if (isset($_GET["lp_course_filter"]) ? selected("course_title_az", $_GET["lp_course_filter"]) : "");?>><?php echo esc_html($settings['filter_a_to_z']); ?></option>
                            <option value="course_title_za" <?php if (isset($_GET["lp_course_filter"]) ? selected("course_title_za", $_GET["lp_course_filter"]) : "");?>><?php echo esc_html($settings['filter_z_to_a']); ?></option>
                        </select>
                    </form>
               </div>
            <?php endif; ?>
            <?php if ($settings['show_filter_search']): ?>
               <div class="filter__top courses-searching">
                  <form method="get" action="<?php echo esc_url($finalurl); ?>"  autocomplete="off">
                     <input type="text" name="s" placeholder="<?php echo esc_html($settings['filter_search_placeholder']); ?>" id="keyword" class="input_search form-control course-search-filter">
                     <button type="submit"><i class="flaticon-loupe"></i></button>
                  </form>
               </div>
            <?php endif; ?>
            </div>
            <?php endif; ?>