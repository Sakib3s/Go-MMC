<?php

if (class_exists('SFWD_LMS')) {

    global $post;
    $post_id = $post->ID;

    $_   = $this->get_settings_for_display();

?>

<div class="col-lg-12">
  <div class="gommc-course gommc-course-list">
    <div class="row">
      <div class="col-md-4">

            <?php 

             if (class_exists('RWMB_Loader') && $_['hover_popup_type'] == 'show_video_popup') {
                $ld_intro_video = rwmb_meta('ld_intro_video');

                echo '<div class="tpc-video_popup with_image">';
                echo '<div class="videobox_content">';
            } 

            if ($_['show_media']): ?>
            <div class="course__media">

                <?php if ( has_post_thumbnail() ):?>
                  <a class="course__media-link" href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail($_['image_size']);?>
                  </a>
                 <?php endif; ?>

            <?php    
            if (class_exists('RWMB_Loader') && $_['hover_popup_type'] == 'show_video_popup') { ?>

                <div class="videobox_link_wrapper">

                    <div class="videobox_link popup-youtube popup-vimeo" data-lity="" href="<?php echo esc_url(  $ld_intro_video ); ?>">
                        <svg class="videobox_icon" width="33%" height="33%" viewBox="0 0 232 232"><path d="M203,99L49,2.3c-4.5-2.7-10.2-2.2-14.5-2.2 c-17.1,0-17,13-17,16.6v199c0,2.8-0.07,16.6,17,16.6c4.3,0,10,0.4,14.5-2.2 l154-97c12.7-7.5,10.5-16.5,10.5-16.5S216,107,204,100z"></path>
                        </svg>
                    </div>
                </div>
            <?php     
            } // End video popup ?>

            </div>
        <?php 
        
            endif; // End show_media

            if (class_exists('RWMB_Loader') && $_['hover_popup_type'] == 'show_video_popup') {

            echo '</div>';
            echo '</div>';

             } // End video popup

         ?>

        </div>
        <div class="col-md-<?php if($_['show_media']) : echo '8'; else : echo '12'; endif; ?>">
         <div class="course-content">

            <?php if ($_['show_cat'] || $_['show_price'] ): ?>
              <div class="course__top-meta">

                   <?php if ($_['show_cat'] ): ?>
                      <div class="course__categories ">
                          <?php echo get_the_term_list(get_the_ID(), 'ld_course_category'); ?>
                      </div>
                   <?php endif; ?>

                   <?php if ($_['show_price']): ?>
                       <div class="price">
                            <?php get_template_part('templates/learndash/price_within_button_2'); ?>
                       </div>
                   <?php endif; ?>

              </div>
            <?php endif; ?>

            <?php if ($_['show_title']): ?>
            <?php
              the_title(sprintf('<h4 class="course__title"><a href="%s" rel="bookmark">', esc_url(get_permalink())), '</a></h4>');
              do_action('learn_press_after_the_title');
            ?>
            <?php endif; ?>

            <div class="course__content--meta"> 
                <div class="course__meta-left">

                <?php if ($_['show_lesson']): 
                    $lesson  = learndash_get_course_steps( get_the_ID(), array('sfwd-lessons') );

                    $lesson = $lesson ? count($lesson) : 0;
                    $lesson_text = ('1' == $lesson) ? $_['lesson_text'] : $_['lessons_text']; ?>
                    <span class="course-lessons is__icon"> 
                        <i class="flaticon-book-1"></i> 
                        <?php echo esc_html($lesson); ?>
                        <?php if ($_['hide_lessons_text_list']): ?>
                        <?php echo esc_html($lesson_text); ?>
                        <?php endif; ?>
                    </span>
                <?php endif; ?>
                <?php if ($_['show_topic']): ?>
                  <?php 

                    $topic  = learndash_get_course_steps( get_the_ID(), array('sfwd-topic') );

                    $topic = $topic ? count($topic) : 0;
                    $topic_text = ('1' == $topic) ? $_['topic_text'] : $_['topics_text']; ?>
                    <span class="course-topic is__icon"> 
                        <i class="flaticon-edit-file"></i> 
                        <?php echo esc_html($topic); ?>
                        <?php if ($_['hide_topic_text_list']): ?>
                        <?php echo esc_html($topic_text); ?>
                        <?php endif; ?>
                    </span>

                <?php endif; ?>

                <?php if ($_['show_review']): ?>
                <div class="course__review">
                    <?php 
                        if ( function_exists( 'ldcr_course_rating_stars' ) ) { 
                            ldcr_course_rating_stars();
                        }
                     ?>
                </div>
                <?php endif; ?>

                </div>
            </div>

                <?php                       
                    $description   = get_post_meta( $post_id, '_learndash_course_grid_short_description', true );
                ?>
             <?php if ($_['show_excerpt'] && $description): ?>         

                <p>
                    <?php echo esc_html( $description ); ?>
                </p>
            <?php else : ?>

                <?php the_excerpt(); ?>

            <?php endif; ?>

                <!--  End Excerpt -->

              </div>
            </div>
          </div> <!--  row  -->
        </div> <!-- single course -->
      </div>
<?php } //if class exist SFWD_LMS ?>