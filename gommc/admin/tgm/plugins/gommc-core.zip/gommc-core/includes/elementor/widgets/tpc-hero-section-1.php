<?php
/*
 * This template can be overridden by copying it to yourtheme/gommc-core/elementor/widgets/tpc-hero-section.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Border,
    Group_Control_Typography,
    Group_Control_Image_Size,
    Group_Control_Background,
    Utils,
    Group_Control_Box_Shadow
};
use TPCAddons\{
    GoMMC_Global_Variables as GoMMC_Globals,
};

class TPC_Hero_Section_1 extends Widget_Base
{
    public function get_name()
    {
        return 'tpc-here-section-1';
    }

    public function get_title()
    {
        return esc_html__('Hero Section 1', 'gommc-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-slider-push';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }

    protected function register_controls() {
       
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'gommc-core'),
            ]
        );
        $this->add_control(
            'title',
            [
                'label'       => __('Title', 'gommc-core'),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __('Experience a learning platform that take you next level', 'gommc-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'sub_title',
            [
                'label'       => __('Sub Title', 'gommc-core'),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __('START TO NEW JOURNEY', 'gommc-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'description',
            [
                'label'     => __('Description', 'gommc-core'),
                'type'      => Controls_Manager::TEXTAREA,
                'default'   => __('World-class training and development programs developed by top teachers', 'gommc-core'),
                'separator' =>'before',
            ]
        );

        $this->add_control(
            'shortcode',
            [
                'label' => esc_html__( 'Enter your shortcode', 'gommc-core' ),
                'type' => Controls_Manager::TEXTAREA,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => '[mc4wp_form id="123"]',
                'default' => '',
            ]
        );

        $this->add_control(
            'bottom_text',
            [
                'label'     => __('Bottom Text', 'gommc-core'),
                'type'      => Controls_Manager::TEXTAREA,
                'default'   => __('No credit card required. By <a href="#">clicking ‘Start a Free Trial’</a>', 'gommc-core'),
                'separator' =>'before',
            ]
        );
        $this->add_responsive_control(
            'content_position',
            [
                'label'     => __('Content Position', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'size_units' =>  ['px','%'],
                'range'     => [
                    'px' => [
                        'min' => -500,
                        'max' => 500,
                    ],
                ],
                'default' => ['unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .hero-content' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        ); 

        $this->add_control(
            'show_review',
            [
                'label' => esc_html__('Review', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'
            ]
        );
        $this->add_control(
            'review_text',
            [
                'label'       => __('Review Text', 'gommc-core'),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __('Best Learning Platform', 'gommc-core'),
                'label_block' => true,
                  'condition' => ['show_review' => 'yes'],
            ]
        );
        $this->add_control(
            'show_animation',
            [
                'label' => esc_html__('Animation', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => ''
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_shape_image',
            [
                'label' => __( 'Images', 'gommc-core' ),
            ]
        );
        $this->add_control(
            'hero_thumb',
            [
                'label' => __( 'Thumb', 'gommc-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [ 'url' => Utils::get_placeholder_image_src() ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'hero_thumb_size',
                'default' => 'full',
                'separator' => 'none',
            ]
        );      
        $this->add_responsive_control(
            'thumb_image_width',
            [
                'label'     => __('Thumb Width', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 50,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .hero-thumb-wrap img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .gommc-hero-2-wrap .hero-thumb-wrap img' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );     
        $this->add_responsive_control(
            'thum_image_position',
            [
                'label'     => __('Thumb Position', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => -200,
                        'max' => 500,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '0',
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .hero-images .image' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        ); 
        $this->add_control(
            'shape_1',
            [
                'label' => __( 'Shape 1', 'gommc-core' ),
                'type' => Controls_Manager::MEDIA,
                'separator'  => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'shape_1_size',
                'default' => 'full',
                'separator' => 'none',
            ]
        );      
        $this->add_responsive_control(
            'shape_1_width',
            [
                'label'     => __('Shape 1 Width', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 5,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .shape-2' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );     
        $this->add_responsive_control(
            'shape_1_position',
            [
                'label'     => __('Shape 1 Position', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'size_units' =>  ['px','%'],
                'range' => [
                    'px' => ['min' => 5, 'max' => 500],
                    '%' => ['min' => 1, 'max' => 100],
                ],
                'default' => ['unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .shape-2' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        ); 

        $this->add_control(
            'shape_2',
            [
                'label' => __( 'Shape 2', 'gommc-core' ),
                'type' => Controls_Manager::MEDIA,
                'separator'  => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'shape_2_size',
                'default' => 'full',
                'separator' => 'none',
            ]
        );      
        $this->add_responsive_control(
            'shape_2_width',
            [
                'label'     => __('Shape 2 Width', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 5,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .shape-3' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );     
        $this->add_responsive_control(
            'shape_2_position',
            [
                'label'     => __('Shape 2 Position', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'size_units' =>  ['px','%'],
                'range' => [
                    'px' => ['min' => 5, 'max' => 500],
                    '%' => ['min' => 1, 'max' => 100],
                ],
                'default' => ['unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .shape-3' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        ); 

        $this->add_control(
            'shape_3',
            [
                'label' => __( 'Shape 3', 'gommc-core' ),
                'type' => Controls_Manager::MEDIA,
                'separator'  => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'shape_3_size',
                'default' => 'full',
                'separator' => 'none',
            ]
        );      
        $this->add_responsive_control(
            'shape_3_width',
            [
                'label'     => __('Shape 3 Width', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 5,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .shape-4' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );     
        $this->add_responsive_control(
            'shape_3_position',
            [
                'label'     => __('Shape 3 Position', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'size_units' =>  ['px','%'],
                'range' => [
                    'px' => ['min' => 5, 'max' => 500],
                    '%' => ['min' => 1, 'max' => 100],
                ],
                'default' => ['unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .shape-4' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        ); 


        $this->add_control(
            'shape_4',
            [
                'label' => __( 'Shape 4', 'gommc-core' ),
                'type' => Controls_Manager::MEDIA,
                'separator'  => 'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'shape_4_size',
                'default' => 'full',
                'separator' => 'none',
            ]
        );      
        $this->add_responsive_control(
            'shape_4_width',
            [
                'label'     => __('Shape 4 Width', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 5,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .image-shape-03' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );     
        $this->add_responsive_control(
            'shape_4_position',
            [
                'label'     => __('Shape 4 Position', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'size_units' =>  ['px','%'],
                'range' => [
                    'px' => ['min' => 5, 'max' => 500],
                    '%' => ['min' => 1, 'max' => 100],
                ],
                'default' => ['unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .image-shape-03' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        ); 


        $this->end_controls_section();

         $this->start_controls_section(
            'content_style_section',
            [
                'label' => __('Style', 'gommc-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'section_background_a',
                'label' => __( 'Background A', 'gommc-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .gommc-hero-2-wrap',
            ]
        );

         $this->add_responsive_control(
            'content_padding',
            [
                'label'      => __('Padding', 'gommc-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .gommc-hero-2-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'section_height',
            [
                'label'     => __('Section Height', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'em', 'vh' ],
                'range' => [
                    'px' => ['min' => 100, 'max' => 1400],
                    '%' => ['min' => 1, 'max' => 100],
                    'vh' => ['min' => 0, 'max' => 100, ],
                ],
                'default' => ['unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap' => 'height: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );  
        $this->end_controls_section();

        $this->start_controls_section(
            'title_style_section',
            [
                'label' => __('Title', 'gommc-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'label'    => __('Title Typography', 'gommc-core'),
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
                'selector' => '{{WRAPPER}} .title',
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label'     => __('Title Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#072f60',
                'selectors' => [
                    '{{WRAPPER}}  .title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_span_color',
            [
                'label'     => __('Span Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#09A142',
                'selectors' => [
                    '{{WRAPPER}}  .title span' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ==== Content Style Section ====

        $this->start_controls_section(
            'desc_style_section',
            [
                'label' => __('Description', 'gommc-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'desc_typography',
                'label'    => __('Typography', 'gommc-core'),
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_TEXT,
                ],
                'selector' => '{{WRAPPER}} .gommc-hero-2-wrap p',
            ]
        );
        $this->add_control(
            'desc_color',
            [
                'label'     => __('Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}}  .gommc-hero-2-wrap p' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'desc_padding',
            [
                'label'      => __('Padding', 'gommc-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .gommc-hero-2-wrap p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> Button
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_btn',
            [
                'label' => esc_html__('Button', 'gommc-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'icon_typography',
                'selector' => '{{WRAPPER}} .gommc-hero-2-wrap .here-2-btn a.btn__a',
            ]
        );

        $this->start_controls_tabs('text_color_tabs');

        $this->start_controls_tab(
            'tab_text_idle',
            ['label' => esc_html__('Idle', 'gommc-core')]
        );

        $this->add_control(
            'text_color_idle',
            [
                'label' => esc_html__('Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .here-2-btn a.btn__a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_bg_color',
            [
                'label' => esc_html__('Background Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .here-2-btn a.btn__a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_text_hover',
            ['label' => esc_html__('Hover', 'gommc-core')]
        );

        $this->add_control(
            'btn_color_hover',
            [
                'label' => esc_html__('Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .here-2-btn a.btn__a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'btn_bg_color_hover',
            [
                'label' => esc_html__('background Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .here-2-btn a.btn__a:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();

        // ==== Content Style Section ====

        $this->start_controls_section(
            'btn_link_style_section',
            [
                'label' => __('Bottom Link Text', 'gommc-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'buttom_link_typography',
                'label'    => __('Typography', 'gommc-core'),
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_TEXT,
                ],
                'selector' => '{{WRAPPER}} .gommc-hero-2-wrap p',
            ]
        );
        $this->add_control(
            'buttom_text_color',
            [
                'label'     => __('Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}}  .gommc-hero-2-wrap span.bottom_text' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'buttom_link_text_color',
            [
                'label'     => __('Link Text Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}}  .gommc-hero-2-wrap span.bottom_text a' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'buttom_link_padding',
            [
                'label'      => __('Padding', 'gommc-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .gommc-hero-2-wrap span.bottom_text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->end_controls_section();


        // ==== Reviest Style Section ====

        $this->start_controls_section(
            'review_style_section',
            [
                'label' => __('Revive', 'gommc-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'review_typography',
                'label'    => __('Typography', 'gommc-core'),
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_TEXT,
                ],
                'selector' => '{{WRAPPER}} .gommc-hero-2-wrap .image-content p',
            ]
        );
        $this->add_control(
            'review_text_color',
            [
                'label'     => __('Review Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .image-content p' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'review_bg_color',
            [
                'label'     => __('Review Background', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .image-content' => 'background: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'review_icon_color',
            [
                'label'     => __('Review Icon Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .image-content .image-icon i' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'review_icon_bg_color',
            [
                'label'     => __('Review Icon Background', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '',
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .image-content .image-icon i' => 'background: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'review_padding',
            [
                'label'      => __('Padding', 'gommc-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .gommc-hero-2-wrap .image-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->end_controls_section();


        
    } // End options

    protected function render( $instance = [] ) {

    $settings = $this->get_settings_for_display();

    $shortcode = $this->get_settings_for_display( 'shortcode' );
    $shortcode = do_shortcode( shortcode_unautop( $shortcode ) );

    ?>

        <div class="gommc-hero-2-wrap">

            <div class="shape-2 parallaxed">
                <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'shape_1_size', 'shape_1' );?>
            </div>
            <div class="shape-3 parallaxed">
                <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'shape_2_size', 'shape_2' );?>
            </div>
            <div class="shape-4 parallaxed">
                <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'shape_3_size', 'shape_3' );?>
            </div>

            <div class="gommc-container">
                <div class="row justify-content-center align-items-center">
                    <div class="tpc_col-6 <?php echo ($settings['show_animation']) ? 'tpc_ani_wrap' : ''; ?>">
                        <!-- Slider Start -->
                        <div class="hero-content <?php echo ($settings['show_animation']) ? 'start_tpc_ani' : ''; ?>">
                                <?php if ($settings['sub_title']): ?>
                                    <h5 class="sub-title"><?php echo $settings['sub_title'] ?></h5>
                                 <?php endif;?>
                                 <?php if ($settings['title']): ?>
                                    <h1 class="title"><?php echo $settings['title'] ?></h1>
                                 <?php endif;?>
                                 <?php if ($settings['description']): ?>
                                    <p class="description"><?php echo $settings['description'] ?></p>
                                 <?php endif;?>
                                <div class="hero-form">
                                    <div class="elementor-shortcode"><?php echo $shortcode; ?></div>
                                    <?php if ($settings['bottom_text']): ?>
                                        <span class="bottom_text"><?php echo $settings['bottom_text'] ?></span>
                                     <?php endif;?>
                                </div>
                        </div>
                        <!-- Slider End -->
                    </div>

                    <div class="tpc_col-6 tpc_col-8">
                        <!-- Slider Images Start -->
                        <div class="hero-images">

                            <div class="image-shape-01">
                                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0, 0, 400,422.22222222222223">
                                    <g>
                                        <path class="svg-path" d="M249.170 1.246 C 246.742 1.846,245.369 2.516,239.764 5.836 C 234.465 8.975,234.709 8.879,233.756 8.206 C 227.188 3.570,221.110 4.002,209.834 9.905 C 161.839 35.030,119.112 64.475,79.184 99.941 C 72.153 106.187,69.852 109.920,69.278 116.019 L 69.093 117.980 59.770 124.539 C 36.460 140.937,10.707 159.714,7.243 162.837 C -8.597 177.118,8.117 205.459,28.380 198.678 C 29.278 198.378,38.226 194.189,48.264 189.369 C 58.303 184.550,66.553 180.644,66.599 180.690 C 66.644 180.735,65.920 182.024,64.990 183.554 C 60.112 191.574,59.404 196.542,62.241 202.862 C 62.609 203.682,62.864 204.388,62.809 204.431 C 62.753 204.474,59.374 207.024,55.300 210.097 C 42.267 219.929,21.611 235.907,11.317 244.120 C 4.202 249.797,1.848 253.708,1.593 260.281 C 1.210 270.134,9.389 280.935,18.531 282.650 C 19.583 282.848,19.582 282.837,18.774 284.603 C 12.708 297.851,23.972 313.928,39.313 313.919 C 45.246 313.915,47.657 312.933,56.839 306.774 C 64.645 301.539,63.925 301.862,64.491 303.343 C 65.653 306.388,69.631 311.187,72.973 313.579 L 74.554 314.710 72.736 316.298 C 63.347 324.497,63.224 337.349,72.450 346.245 L 74.052 347.791 73.535 349.438 C 70.197 360.075,77.730 372.787,89.144 375.777 C 96.174 377.619,101.535 375.989,111.622 368.944 C 127.804 357.641,158.936 336.143,159.120 336.143 C 159.237 336.143,159.397 336.402,159.476 336.719 C 159.556 337.036,160.232 338.225,160.979 339.360 L 162.337 341.425 149.950 352.130 C 143.137 358.018,133.831 366.054,129.268 369.987 C 116.968 380.593,115.065 383.436,115.081 391.188 C 115.111 406.739,132.424 417.076,147.000 410.245 C 148.160 409.702,156.047 404.952,164.528 399.689 C 173.010 394.426,180.094 390.036,180.271 389.934 C 180.482 389.813,180.419 390.191,180.092 391.022 C 174.024 406.416,188.847 424.688,204.072 420.583 C 208.639 419.352,208.676 419.324,228.352 402.915 C 244.492 389.456,258.618 377.781,259.161 377.452 C 259.365 377.328,259.447 378.241,259.451 380.658 C 259.481 401.040,279.808 412.735,295.019 401.121 C 316.491 384.728,341.958 359.618,360.013 337.037 C 373.516 320.150,390.020 295.537,396.596 282.480 C 401.209 273.321,399.062 260.118,391.854 253.319 C 390.249 251.805,386.504 249.553,385.590 249.553 C 385.424 249.553,385.140 248.835,384.960 247.957 C 382.336 235.180,366.973 227.119,354.674 232.066 C 353.838 232.402,353.128 232.651,353.096 232.619 C 353.064 232.587,360.028 226.454,368.572 218.990 C 384.722 204.882,386.183 203.453,387.975 200.008 C 394.662 187.156,385.514 171.304,370.434 169.613 C 368.631 169.411,368.485 169.346,367.746 168.416 C 363.254 162.766,356.682 159.580,349.502 159.573 L 346.385 159.569 345.715 157.882 C 344.833 155.661,343.537 153.353,342.282 151.765 L 341.266 150.481 342.983 148.853 C 364.549 128.411,378.779 113.246,381.100 108.232 C 387.088 95.297,374.160 77.537,359.459 78.502 C 355.853 78.739,354.117 79.462,344.936 84.546 L 336.648 89.135 334.672 88.143 C 328.236 84.915,321.389 84.807,315.057 87.834 C 312.598 89.009,293.400 101.783,280.140 111.065 C 278.911 111.926,277.905 112.586,277.905 112.532 C 277.905 112.478,280.405 110.111,283.461 107.271 C 291.904 99.423,294.687 96.607,296.057 94.529 C 299.733 88.952,300.557 82.854,298.462 76.722 C 297.696 74.482,297.593 73.950,297.873 73.695 C 298.059 73.525,299.940 71.947,302.052 70.190 C 308.700 64.656,310.360 62.297,312.171 55.811 C 317.023 38.431,302.429 22.327,286.681 27.683 C 285.134 28.209,277.596 31.690,273.023 33.989 L 271.589 34.711 272.578 32.745 C 279.930 18.132,264.556 -2.557,249.170 1.246 " stroke="none" fill-rule="evenodd"></path>
                                    </g>
                                </svg>
                            </div>

                            <div class="image-shape-03 parallaxed">
                                <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'shape_4_size', 'shape_4' );?>
                            </div>

                            <div class="image">
                             <?php if ($settings['hero_thumb']): ?>
                                <div class="hero-thumb-wrap">
                                    <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'hero_thumb_size', 'hero_thumb' );?>
                                </div>
                            <?php endif; ?>

                            <?php if ($settings['show_review']): ?>
                                <div class="image-content">
                                    <div class="image-icon">
                                        <i><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="31" height="31" viewBox="0 0 31 31">
                                          <image id="L1" width="31" height="31" xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB8AAAAfCAYAAAAfrhY5AAADmElEQVRIib2WXYhWVRSGn3HMmdR0+puMKUupi2yoEGrIMkipQFIoIijxIqMC6yq6KemmwK6KgkS6qpt+LKMQI/CiDCmqi34UDVL8ySGEKWVoxp8afWI769DpnH2++cakBS/n+/Z6915n7bP2uxdqDp3qBZnxAlPV59Xv1ZfVGRlOgZnBr/lqA4HF6lZ1UcaXsMpxG4zn2gwnoV/doi7P+BqD36aOqLvU3oovZbknfDepX6hH1TkV3mx1W7zcikwMppC3r4DngJnArArjIeAa4GPgB+A9oAdYU+FNB3qBdcCn2Si5NwpMUWfFs5z1j+rval+MTVf3qgdKY+X5nZm1W257Ex6NbVxX8T8R4083zMsiO9iArviGR9QrKpyU4T51t3phw/waagMZpEAD6ovqKfWFDCdhdWS/Xr1dnV/5ZDV0nHmDcZsG3AIsAq4G5gJXAXOA84AZwE5gBTBYKx64CNgE3AGMAmPAEHAAOBTPr4FvgJE0oQjeDbwKPAacBE4Ax0uTfwX2AB80BC7sUuABYAFweSRxWVR+dyS4BVgNHC22IonJXyEsy9vdtjYxN9Zfpr5TPvdT441ThofjXP4E7K3ldPb2S6A3tONIxPpXwd2v/hmSOXAOMi7j2tCHZE8WZ79KWhkVPdhC1yeL69QdEfipiUTmQXVYPXQOXuB6dad6Ul3T7jlPBTGkHoxLJseZCP0hOidCA2r82kAJ96iHQ7kuzvhbYZr6ZQRe2cQrfiRyt9pRIayPb3VjbnILzI7AH1U4HSHTXcVRexhYFSr2SKhRYUndhoGDkzxoo7FOT0YF3wAuAd5O9/mzwEJgf6hbYV1AX4wP15ZvbWOhFX2hcoWdAvYB84G1aStuiI6kuo39UfEbM752kC6iY+rSDHeBujBt+46GHK4Mff625hm3O4F7gW3AJ8Dpiv874PzQ+6rtTv+b2ihCDjuBXaWxxB8A3gc+i9ZpM7AVWBp1U1hRJ/NqKxeW2ZICL6ljcTEUn+f1qP5jcUncp26ItirZW+qt/lPxf6jvTrZ1TrfZh+px9a74fr9FgE3q3RV+EqI3w5+O2GuhE/vV7WpPJkZj8HQen4nFhuK5Pa7Frgy/mLNE3Rz81G6dVl9pyrzcyVQtXf6PA4uBjdH+jtZYdUvzloR2pM5nw5nGIWOtgrcTZF6IyUjN24a1qvaJ7Gbgc2DZBLxG+y/B0/lN/VmS4P89eGoskwD9fFazgb8BQvBAP5TnyI8AAAAASUVORK5CYII="/>
                                        </svg>
                                        </i>
                                    </div>

                                        <div class="start">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                        </div>
                                        <?php if ($settings['description']): ?>
                                            <p><?php echo $settings['review_text'] ?></p>
                                        <?php endif; ?>

                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!-- Slider Images End -->
                    </div>
                </div>
            </div>

            <!-- Shape Start -->
            <div class="shape-1">
                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0, 0, 400,25.9375">
                    <g>
                        <path class="shape-path" d="M395.978 7.401 C 387.213 8.942,374.841 10.759,364.167 12.075 C 312.112 18.490,258.708 19.603,209.167 15.306 C 201.972 14.682,197.734 14.248,186.458 12.978 C 136.314 7.332,98.882 6.502,68.750 10.367 C 56.076 11.993,47.455 13.662,27.552 18.345 C 16.230 21.009,13.054 21.719,4.323 23.539 C 3.177 23.778,1.736 24.091,1.120 24.235 L 0.000 24.497 0.000 25.217 L 0.000 25.938 200.000 25.938 L 400.000 25.938 400.000 16.354 L 400.000 6.771 399.714 6.783 C 399.556 6.790,397.875 7.068,395.978 7.401 " stroke="none" fill-rule="evenodd"></path>
                    </g>
                </svg>
            </div>
            <!-- Shape End -->

        </div>

<?php

    }

}

