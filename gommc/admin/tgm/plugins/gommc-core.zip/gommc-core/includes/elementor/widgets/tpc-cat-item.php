<?php
/*
 * This template can be overridden by copying it to yourtheme/gommc-core/elementor/widgets/tpc-Cat-item.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{Widget_Base, Controls_Manager, Control_Media, Group_Control_Background, Group_Control_Box_Shadow, Group_Control_Typography, Utils, Embed};
use TPCAddons\GoMMC_Global_Variables as GoMMC_Globals;

class TPC_Cat_Item extends Widget_Base
{

    public function get_name()
    {
        return 'tpc-cat-item';
    }

    public function get_title()
    {
        return esc_html__('Category Item', 'gommc-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }

    protected function register_controls()
    {
        /*-----------------------------------------------------------------------------------*/
        /*  Content
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'tpc_cat_item_section',
            [
                'label' => esc_html__('Category Item Settings', 'gommc-core'),
            ]
        );

        $this->add_control(
            'cat_layout',
            [
                'label' => __( 'Style', 'gommc-core' ),
                'type' => Controls_Manager::SELECT,
                'default' => '3',
                'options' => [
                    '1' => esc_html__('1 / One', 'gommc-core'),
                    '2' => esc_html__('2 / Two', 'gommc-core'),
                    '3' => esc_html__('3 / Two', 'gommc-core'),
                ],
            ]
        );
        $this->add_control(
            'cat_title',
            [
                'label' => esc_html__('Title', 'gommc-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic' => ['active' => true],
                'default' => esc_html__('This is the heading', 'gommc-core'),
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__('HTML Tag', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
                'default' => 'h3',
            ]
        );

        $this->add_control(
            'cat_name',
            [
                'label' => esc_html__('Category Name', 'gommc-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic' => ['active' => true],
                'default' => esc_html__('Category Name', 'gommc-core'),
            ]
        );

        $this->add_control(
            'cat_tag',
            [
                'label' => esc_html__('HTML Tag', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
                'default' => 'h4',
            ]
        );

        $this->add_control(
            'thumbnail',
            [
                'label' => esc_html__('Image', 'gommc-core'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $this->add_control(
            'video_show',
            [
                'label' => esc_html__('Video', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'gommc-core'),
                'label_off' => esc_html__('Off', 'gommc-core'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'cat_layout' => '2',
                ],
            ]
        );
        $this->add_control(
            'link',
            [
                'label' => esc_html__('Video Link', 'gommc-core'),
                'type' => Controls_Manager::TEXT,
                'description' => esc_html__('Link from youtube or vimeo.', 'gommc-core'),
                'separator' => 'after',
                'label_block' => true,
                'placeholder' => esc_attr__('https://www.youtube.com/watch?v=', 'gommc-core'),
                'default' => 'https://www.youtube.com/watch?v=_X0eYtY8T_U',
                'condition' => [
                    'cat_layout' => '2',
                ],
            ]
        );
           $this->add_control(
            'cat_link',
            [
                'label' => esc_html__('Category Link', 'gommc-core'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                 'default' => ['url' => '#'],
            ]
        );
        $this->add_responsive_control(
            'image_fixed_height',
            [
                'label' => __( 'Height', 'eduent-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 900,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-cat-item .items-image' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tpc-cat-item .items-image img' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tpc-cat-item .single-items-1 .cat-item_image' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

       $this->add_responsive_control(
            'space_top',
            [
                'label' => __( 'Position', 'eduent-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-cat-item .items-cont' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

     $this->add_responsive_control(
            'space_between',
            [
                'label' => __( 'Space Between', 'eduent-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 900,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-cat-item .items-cont .course-cat' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  Carousel styles
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__('Category Item Styles', 'gommc-core'),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );
        $this->add_responsive_control(
            'alignment',
            [
                'label' => __( 'Alignment', 'gommc-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'gommc-core' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'gommc-core' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'gommc-core' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-cat-item .single-cat__item' => 'text-align: {{VALUE}};',
                ],
                'default' => 'left',
                'separator' =>'before',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'lp_catogories_bg_color',
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .tpc-cat-item .single-items-1 a, .tpc-cat-item .single-items-2 .items-image::before',
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'lp_catogories_hover_bg_color',
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .tpc-cat-item .single-items-1 a:hover',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_title',
                'label' => __( 'Category Typography', 'eduent-core' ),
                'selector' => '{{WRAPPER}} .tpc-cat-item .single-items-2 .items-cont .course-cat, .tpc-cat-item .single-items-1 a .cat_name',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_count',
                'label' => __( 'Count Typography', 'eduent-core' ),
                'selector' => '{{WRAPPER}} .tpc-cat-item .single-items-2 .items-cont .total-course',
            ]
        );

        $this->start_controls_tabs( 'title_color_tab' );

        $this->start_controls_tab(
            'custom_title_color',
            [ 'label' => esc_html__('Title Color' , 'gommc-core') ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__('Category Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .tpc-cat-item .single-items-1 a .cat_name' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .tpc-cat-item .single-items-2 .items-cont .course-cat' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'count_color',
            [
                'label' => esc_html__('Count Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .tpc-cat-item .single-items-2 .items-cont .total-course' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_title_color_hover',
            [ 'label' => esc_html__('Hover' , 'gommc-core') ]
        );

        $this->add_control(
            'title_color_hover',
            [
                'label' => esc_html__('Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .tpc-cat-item:hover .single-items-1 a .cat_name' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .tpc-cat-item:hover .course-cat' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->add_control(
            'image_border_radius',
            [
                'label' => esc_html__('Image Border Radius', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'default' => [
                    'top' => 10,
                    'right' => 10,
                    'bottom' => 10,
                    'left' => 10,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-cat-item .single-items-1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .cat-item_image, {{WRAPPER}} .tpc-cat-item .single-items-2 .items-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_box_shadow',
                'selector' => '{{WRAPPER}} .tpc-cat-item .items-image',
            ]
        );

        $this->end_controls_section();

    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $this->add_render_attribute('cat', 'class', 'tpc-cat-item');

        if (!empty($_['cat_link']['url'])) {
            $this->add_link_attributes('cat_button', $settings['cat_link']);
        }
        $this->add_render_attribute('cat_link', 'class', 'cat-item_image-link');
        if (!empty($settings['cat_link']['url'])) {
            $this->add_link_attributes('cat_link', $settings['cat_link']);
        }

        $this->add_render_attribute('title_link', 'class', 'cat-item_title-link');
        if (!empty($settings['cat_link']['url'])) {
            $this->add_link_attributes('title_link', $settings['cat_link']);
        }

        $this->add_render_attribute('cat_img', [
            'class' => 'cat-item_image',
            'src' => isset($settings['thumbnail']['url']) ? esc_url($settings['thumbnail']['url']) : '',
            'alt' => Control_Media::get_image_alt( $settings['thumbnail'] ),
        ]);

        ?>

        <div <?php echo $this->get_render_attribute_string('cat'); ?>>

            <?php if ($settings['cat_layout'] == '1'): ?>

            <div class="single-items-<?php echo $settings['cat_layout']; ?>">
               <?php  echo '<a ', $this->get_render_attribute_string('title_link'), '>'; ?>
                    <img <?php echo $this->get_render_attribute_string('cat_img'); ?> />
                    <span class="cat_name"><?php echo  $settings['cat_name']; ?></span>
                </a>
            </div>

            <?php elseif ($settings['cat_layout'] == '2'): ?>
                
            <div class="single-cat__item layout-<?php echo $settings['cat_layout']; ?> text-center">


            <?php if(!empty($_['cat_link']['url'])) : ?>
                <a href="<?php echo esc_url($title_link['url']); ?>">
            <?php endif ?>

            <?php if (!empty($settings['thumbnail'])) {?>
                <div class="items-image">
                    <img <?php echo $this->get_render_attribute_string('cat_img'); ?> />
                </div>
            <?php } ?>

                <div class="items-cont">
                <?php if ($settings['video_show']): ?>
                        
                <div class="tpc-video_popup">
                <?php
                $triangle_svg = '<svg class="videobox_icon" viewBox="0 0 232 232"><path d="M203,99L49,2.3c-4.5-2.7-10.2-2.2-14.5-2.2 c-17.1,0-17,13-17,16.6v199c0,2.8-0.07,16.6,17,16.6c4.3,0,10,0.4,14.5-2.2 l154-97c12.7-7.5,10.5-16.5,10.5-16.5S216,107,204,100z"/></svg>';

                      echo '<div ', $this->get_render_attribute_string('video-wrap'), '>';
                        echo '<div class="videobox_content">';

                            $lightbox_url = Embed::get_embed_url( $settings['link'], [], [] );

                            $lightbox_options = [
                                'type' => 'video',
                                'url' => $lightbox_url,
                                'modalOptions' => [
                                    'id' => 'elementor-lightbox-' . $this->get_id(),
                                ],
                            ];

                            $this->add_render_attribute( 'video-lightbox', [
                                'class' => 'videobox_link videobox',
                                'data-elementor-open-lightbox' => 'yes',
                                'data-elementor-lightbox' =>  wp_json_encode( $lightbox_options ),
                            ] );

                            echo '<div ', $this->get_render_attribute_string( 'video-lightbox' ) , '>';
                                echo $triangle_svg;
                            echo '</div>';

                        echo '</div>'; // videobox_content
                        echo '</div>';
                ?>
                </div>
                <?php endif ?>
                    <?php                 
                        if (!empty($settings['cat_title'])) {
                            echo '<a ', $this->get_render_attribute_string('title_link'), '>',
                                '<', $settings['title_tag'], ' class="course-cat">',
                                    $settings['cat_title'],
                                '</', $settings['title_tag'], '>',
                            '</a>';
                        }
                    ?>

                    <?php                 
                        if (!empty($settings['cat_name'])) {
                            echo '<', $settings['cat_tag'], ' class="total-course">',
                                    $settings['cat_name'],
                                '</', $settings['cat_tag'], '>';
                        }
                    ?>
                   
                </div>
                <?php if(!empty($_['cat_link']['url'])) : ?>
                </a>
                <?php endif ?>
            </div> 


        <?php elseif ($settings['cat_layout'] == '3'): ?>
                
            <div class="single-cat__item layout-<?php echo $settings['cat_layout']; ?> text-center">


            <?php if(!empty($_['cat_link']['url'])) : ?>
                <a href="<?php echo esc_url($title_link['url']); ?>">
            <?php endif ?>

            <?php if (!empty($settings['thumbnail'])) {?>
                <div class="items-image">
                    <img <?php echo $this->get_render_attribute_string('cat_img'); ?> />
                </div>
            <?php } ?>

                <div class="items-cont">

                  <div class="content__wrap">
                    <?php                 
                        if (!empty($settings['cat_title'])) {
                            echo '<a ', $this->get_render_attribute_string('title_link'), '>',
                                '<', $settings['title_tag'], ' class="course-cat">',
                                    $settings['cat_title'],
                                '</', $settings['title_tag'], '>',
                            '</a>';
                        }
                    ?>

                    <?php                 
                        if (!empty($settings['cat_name'])) {
                            echo '<', $settings['cat_tag'], ' class="total-course">',
                                    $settings['cat_name'],
                                '</', $settings['cat_tag'], '>';
                        }
                    ?>
                  </div>

                  <div class="icon__wrap">
                        <?php  echo '<a ', $this->get_render_attribute_string('title_link'), '>'; ?>
                              <span class="arrow__icon flaticon-right-arrow-2"></span>
                            </a>
                  </div>
                  
                </div>
                <?php if(!empty($_['cat_link']['url'])) : ?>
                </a>
                <?php endif ?>
            </div> 

            <?php endif ?>
        </div>

        <?php
    }

}