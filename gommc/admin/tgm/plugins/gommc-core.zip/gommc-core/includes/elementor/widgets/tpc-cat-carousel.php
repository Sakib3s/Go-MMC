<?php
/*
 * This template can be overridden by copying it to yourtheme/gommc-core/elementor/widgets/tpc-category-carousel.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\{Widget_Base, Controls_Manager, Control_Media};
use Elementor\{Group_Control_Border, Group_Control_Box_Shadow, Group_Control_Background, Group_Control_Image_Size, Group_Control_Typography};
use Elementor\{Repeater, Utils};
use TPCAddons\GoMMC_Global_Variables as GoMMC_Globals;


class TPC_Cat_Carousel extends Widget_Base
{
    public function get_name() {
        return 'tpc-cat-carousel';
    }

    public function get_title() {
        return esc_html__('Category Carousel', 'gommc-core');
    }

    public function get_icon() {
        return 'tpc-icon eicon-slider-full-screen';
    }

    // public function get_script_depends() {
    //     return [ 'slick' ];
    // }

    public function get_categories() {
        return [ 'tpc-extensions' ];
    }

    protected function register_controls()
    {
        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_general',
            [ 'label' => esc_html__('General', 'gommc-core') ]
        );

        $this->add_control(
            'item_grid',
            [
                'label' => esc_html__('Columns Amount', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('1 / One', 'gommc-core'),
                    '2' => esc_html__('2 / Two', 'gommc-core'),
                    '3' => esc_html__('3 / Three', 'gommc-core'),
                    '4' => esc_html__('4 / Four', 'gommc-core'),
                    '5' => esc_html__('5 / Five', 'gommc-core'),
                    '6' => esc_html__('6 / Six', 'gommc-core'),
                ],
                'default' => '4',
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'thumbnail',
            [
                'label' => esc_html__('Thumbnail', 'gommc-core'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [ 'url' => Utils::get_placeholder_image_src() ],
            ]
        );
        $repeater->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'cat_imagesize',
                'default' => 'large',
                'separator' => 'none',
            ]
        );

        $repeater->add_control(
            'cat_name',
            [
                'label'   => __( 'Category Name', 'gommc-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Data Science','gommc-core'),

            ]    
        );
        $repeater->add_control(
            'cat_link',
            [
                'label' => esc_html__('Add Link', 'gommc-core'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'default' => ['url' => '#'],
            ]
        );
        $this->add_control(
            'list',
            [
                'label' => esc_html__('Category Items', 'gommc-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                    'default' => [

                        [
                            'cat_name'           => __('Category Name 1','gommc-core'),
                        ],

                        [
                            'cat_name'           => __('Category Name 2','gommc-core'),
                        ],

                        [
                            'cat_name'           => __('Category Name 3','gommc-core'),
                        ],
                        [
                            'cat_name'           => __('Category Name 4','gommc-core'),
                        ],
                        [
                            'cat_name'           => __('Category Name 5','gommc-core'),
                        ],
                    ],
                    'title_field' => '{{{ cat_name }}}',
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> CAROUSEL OPTIONS
        /*-----------------------------------------------------------------------------------*/
            $this->start_controls_section(
                'tpc_carousel_section',
                ['label' => esc_html__('Carousel Options', 'gommc-core')]
            );

            $this->add_control(
                'autoplay',
                [
                    'label' => esc_html__('Autoplay', 'gommc-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'gommc-core'),
                    'label_off' => esc_html__('Off', 'gommc-core'),
                ]
            );

            $this->add_control(
                'autoplay_speed',
                [
                    'label' => esc_html__('Autoplay Speed', 'gommc-core'),
                    'type' => Controls_Manager::NUMBER,
                    'min' => 1,
                    'step' => 1,
                    'default' => '5000',
                    'condition' => [
                        'autoplay' => 'yes',
                    ],
                ]
            );
            $this->add_control(
                'infinite',
                [
                    'label' => esc_html__('Infinite Loop Sliding', 'gommc-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'gommc-core'),
                    'label_off' => esc_html__('Off', 'gommc-core'),
                    'return_value' => 'yes',
                    'default' => 'yes'
                ]
            );
            $this->add_control(
                'coverflow_effect',
                [
                    'label' => esc_html__('Coverflow Effect', 'gommc-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'gommc-core'),
                    'label_off' => esc_html__('Off', 'gommc-core'),
                ]
            );
            $this->add_control(
                'tablet_item',
                [
                    'label' => esc_html__('Tablet Device Item', 'gommc-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '2',
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'tablet_width',
                [
                    'label' => esc_html__('Tablet Device Width', 'gommc-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '768',
                ]
            );
            $this->add_control(
                'mobile_item',
                [
                    'label' => esc_html__('Mobile Device Item', 'gommc-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '1',
                    'separator' => 'before',
                ]
            );      
            $this->add_control(
                'mobile_width',
                [
                    'label' => esc_html__('Mobile Device Width', 'gommc-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '480',
                ]
            );    
            $this->add_responsive_control(
                'space_between',
                [
                    'label' => esc_html__('Space Between', 'gommc-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '20',
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'use_prev_next',
                [
                    'label' => esc_html__('Add Prev/Next buttons', 'gommc-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'gommc-core'),
                    'label_off' => esc_html__('Off', 'gommc-core'),
                    'separator' => 'before',
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );
         
            $this->add_control(
                'use_pagination',
                [
                    'label' => esc_html__('Add Pagination', 'gommc-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'gommc-core'),
                    'label_off' => esc_html__('Off', 'gommc-core'),
                    'separator' => 'before',
                    'return_value' => 'yes',
                    'default' => 'yes',
                    ]
            );
          $this->add_control(
                'pag_type',
                [
                    'label' => esc_html__('Pagination Type', 'gommc-core'),
                    'type' => 'tpc-radio-image',
                    'condition' => [
                        'use_pagination' => 'yes',
                    ],
                    'options' => [
                        'circle' => [
                            'title' => esc_html__('Circle', 'gommc-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_circle.png',
                        ],
                        'circle_border' => [
                            'title' => esc_html__('Empty Circle', 'gommc-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_circle_border.png',
                        ],
                        'square' => [
                            'title' => esc_html__('Square', 'gommc-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_square.png',
                        ],
                        'square_border' => [
                            'title' => esc_html__('Empty Square', 'gommc-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_square_border.png',
                        ],
                        'line' => [
                            'title' => esc_html__('Line', 'gommc-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_line.png',
                        ],
                        'line_circle' => [
                            'title' => esc_html__('Line - Circle', 'gommc-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_line_circle.png',
                        ],
                    ],
                    'default' => 'circle',
                ]
            );
            $this->end_controls_section();



        /*-----------------------------------------------------------------------------------*/
        /*  STYLES -> ITEMS
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_items',
            [
                'label' => esc_html__('Icon Thumb', 'gommc-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'item_width',
            [
                'label'      => __('Image Width', 'gommc-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 400,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .cat-carousel-image img' => 'width: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'cat-carousel_box_bg_shape',
            [
                'label' => esc_html__('Box Background Shape ', 'gommc-core'),
                'type' =>  Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .cat-carousel__box .cat-carousel__shape-1' => 'background: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'cat-carousel_box_shadow',
                'selector' => '{{WRAPPER}} .cat-carousel__box .cat-carousel__box-icon',
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'cat_carousel_name_style',
            [
                'label'     => __( 'Category Name', 'gommc-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'cat_carousel_name_color',
            [
                'label' => __( 'Color', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .cat-carousel__box-content .cat-carousel__title,  .cat-carousel__box-content .cat-carousel__title a' => 'color: {{VALUE}};',
                ],
            ]
        );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'cat_carousel_name_typography',
                    'global' => [
                        'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                    ],
                    'selector' => '{{WRAPPER}} .cat-carousel__box-content .cat-carousel__title,  .cat-carousel__box-content .cat-carousel__title a',
                ]
            );

            $this->add_responsive_control(
                'cat_carousel_name_padding',
                [
                    'label' => __( 'Padding', 'gommc-core' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .cat-carousel__box-content .cat-carousel__title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .cat-carousel__box-content .cat-carousel__title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

        $this->end_controls_section(); // Style Testimonial name style end


        // Style arrow style start
        $this->start_controls_section(
            'cat_carousel_arrow_style',
            [
                'label'     => __('Prev/Next buttons', 'gommc-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'use_prev_next' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'cat_carousel_arrow_color',
            [
                'label'     => __('Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#5A5A5A',
                'selectors' => [
                    '{{WRAPPER}} .gommc__carousel .swiper-button-next:after, .gommc__carousel .swiper-button-prev:after' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_arrow_fontsize',
            [
                'label'      => __('Arrow Size', 'gommc-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 50,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .gommc__carousel .swiper-button-next:after, .gommc__carousel .swiper-button-prev:after' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'arrow_bg_color',
            [
                'label'     => __('Background Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gommc__carousel .swiper-button-next, .gommc__carousel .swiper-button-prev' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'cat_carousel_arrow_border',
                'label'    => __('Border', 'gommc-core'),
                'selector' => '{{WRAPPER}} .gommc__carousel .swiper-button-next, .gommc__carousel .swiper-button-prev',
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_arrow_border_radius',
            [
                'label'     => __('Border Radius', 'gommc-core'),
                'type'      => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .gommc__carousel .swiper-button-next, .gommc__carousel .swiper-button-prev' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'arrow_box_shadow',
                'selector' => '{{WRAPPER}} .gommc__carousel .swiper-button-next, .gommc__carousel .swiper-button-prev',
            ]
        );


        $this->end_controls_section(); // Style cat box arrow style end

        // Style cat box Dots style start
        $this->start_controls_section(
            'cat_carousel_dots_style',
            [
                'label'     => __('Pagination', 'gommc-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'use_pagination' => 'yes',
                ],
            ]
        );

        $this->start_controls_tabs('cat_carousel_dots_style_tabs');

        // Normal tab Start
        $this->start_controls_tab(
            'cat_carousel_dots_style_normal_tab',
            [
                'label' => __('Normal', 'gommc-core'),
            ]
        );

        $this->add_control(
            'dot_color',
            [
                'label'     => __('Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gommc__carousel .swiper-pagination .swiper-pagination-bullet' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .gommc__carousel.pagination_square_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .gommc__carousel.pagination_circle_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet:before' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_dots_height',
            [
                'label'      => __('Size', 'gommc-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 30,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .gommc__carousel .swiper-pagination .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'pag_type' => 'circle',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_dots_space',
            [
                'label'      => __('Space Between', 'gommc-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 30,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .gommc__carousel .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'cat_carousel_dots_position',
            [
                'label'      => __('Position', 'gommc-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => -300,
                        'max'  => 0,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => -60,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .gommc__carousel .swiper-pagination' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab(); // Normal tab end

        // Hover tab Start
        $this->start_controls_tab(
            'cat_carousel_dots_style_hover_tab',
            [
                'label' => __('Active', 'gommc-core'),
            ]
        );
        $this->add_control(
            'dot_hover_color',
            [
                'label'     => __('Active Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gommc__carousel .swiper-pagination .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .gommc__carousel.pagination_square_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .gommc__carousel.pagination_square_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .gommc__carousel.pagination_circle_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .gommc__carousel.pagination_circle_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab(); // Hover tab end

        $this->end_controls_tabs();

        $this->end_controls_section(); // Style cat box dots style end

    }

    protected function render()
    {
        $id = $this->get_id();
        $settings = $this->get_settings_for_display();


?>
 <div class="gommc__carousel pagination_<?php echo esc_attr($settings['pag_type']) ?>">   
    <div class="gommc_cat_carousel_id<?php echo $id; ?>">
        <div class="swiper-wrapper">
      <?php      
            foreach ($settings['list'] as $index => $item) {
           ?>
                <div class="swiper-slide">
                    <div class="cat-carousel__single">
                        <div class="cat-carousel__box">
                            <div class="cat-carousel__shape-1"></div>
                            <div class="cat-carousel__box-icon">
                                <?php if(!empty($item['cat_link']['url'])) : ?>
                                    <a href="<?php echo esc_url($item['cat_link']['url']); ?>">
                                <?php endif ?>
                                <?php
                                    if( !empty($item['thumbnail']['url']) ){
                                        echo '<div class="cat-carousel-image">'.Group_Control_Image_Size::get_attachment_image_html( $item, 'cat_imagesize', 'thumbnail' ).'</div>';
                                    } 
                                ?>
                                <?php if(!empty($item['cat_link']['url'])) : ?>
                                </a>
                                <?php endif ?>
                            </div>
                            <div class="cat-carousel__shape-2">
                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="74" height="72" viewBox="0 0 74 72">
                              <image class="cat-carousel_id" data-name="Dot" width="74" height="72" xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEoAAABICAYAAABRGGN6AAADVklEQVR4nO2cT0gUcRTHP7MKKbsSUZD0jwKzgsAO6ylBPURZBIFk1CUDO3SL8iJBRBFdOhZ7SAiCNOtW9NdAO+eloLK0iIxORVmKhyDjxVuYloJXvLnU+5x+y+j37X5mZlnmy0yyoKn7MHAGeAPsBF7gxwrgFrAOOA2cdMwWjgPHgOfAduCtY3YjcANYBfRVVddvGgFqgMVAAtx2HNYL7AaqgDbgLPDVKTsP3AOqgaXALDDilC2cADo0vy0HTKY2jjsOqsyTvT3nmD1XcQRl+d4nxdY24CDwGrjkPGwQmAc2ABeBb47ZktUKHACeAVccs4WSHqWrgQvyHeWc/2+S+98FWAlRRkKUkRBlJEQZCVFGQpSREGUkRBkJUUZClJEQZSREGQlRRkKUkRBlJEQZKYtaCyzKaEadtjBJBtmJZtdlkI06ETc/RJW0opoCWpwHNWnuuF4/92ZQs6d0lictmituSiKqR8Ol/tnnPKwLWKjrPUDBMbugmeiMLsds1EVe1z25ii7MsxcTRrWFEcaAGcfsGc1EZ4w6ZlPpRVoYKT93aFP80HkYeko0arHqKQo9qjr09HjknC00a1N8M+oqI/HzwEiIMhKijIQoIyHKSIgyEqKMhCgjIcpIiDISooyEKCMhykiIMhKijIQoIyHKSE7vg+nUy55Z0KT3w3gWC2UKmu3dwJRpVjc1covHdWCLbpAm45rjIMm9q/3bWAY7QwqAopYLW4Fhx2zZAVd1PSxHVHtqY/tv/ulvaU0Vn8UM6qqirhO9e8uTn7yIqH59ITfIDDgPk6NzWtdDGdRVQ7qeTu19LwbUidBfbmGkNn4PfHQehtbdy7RSmjf8/Z+QaBX2DviSwXuXSn0JMBF1lZH4eWAkRBkJUUZClJEQZSREGQlRRkKUkRBlJEQZCVFGQpSREGUkRBkJUUZClJEQZUQe3bYcOKoPlHrsfLlWLtXu1XZHHuT1yfn9rwGOAPXAE+dsOYj2A7vkUrDUVXeAjbpRbpI57zhMJF3WdbfuDK+nkskHeQCs1NeJczlyCDin604Z1pDauN5xUGWePEGx1jG7VjN/NcuDdF6DnHqz2om9AuRRkx8ch01oCSptxingvmO2PH1RviY2A0/1FPzsmP9SS9U80PcdBGKEEIjLcAoAAAAASUVORK5CYII="/>
                            </svg>
                            </div>      
                        </div>
                        <div class="cat-carousel__box-content">
                            <h4 class="cat-carousel__title">
                            <?php if(!empty($item['cat_link']['url'])) : ?>
                                <a href="<?php echo esc_url($item['cat_link']['url']); ?>">
                            <?php endif ?>
                                <?php echo $item['cat_name']; ?>
                            <?php if(!empty($item['cat_link']['url'])) : ?>
                                </a>
                            <?php endif ?>
                            </h4>
                        </div>
                    </div>
                </div>
            <?php

            } ?>
        </div>
        <?php if ($settings['use_prev_next']): ?>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        <?php endif ?>
       <?php if ($settings['use_pagination']): ?>
            <div class="swiper-pagination"></div>
        <?php endif ?>
    </div>
</div>   

<script>
jQuery(document).ready(function() {
    new Swiper('.gommc_cat_carousel_id<?php echo $id; ?>', {
        <?php if ($settings['infinite']): ?>
            loop: true,
        <?php endif ?>
          
        <?php if ($settings['autoplay']): ?>
          autoplay: {
            delay: <?php echo esc_attr($settings['autoplay_speed']); ?>,
          },
        <?php endif ?>
          pagination: {
            el: ".swiper-pagination",
            clickable: true,
          },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        },
        <?php if ($settings['coverflow_effect']): ?>   
            effect: 'coverflow',
            coverflowEffect: {
                rotate: 30,
                slideShadows: false,
            },
        <?php endif ?>
        breakpoints: {
            1200: {
                slidesPerView: <?php echo $settings['item_grid'] ?>,
                spaceBetween: <?php echo $settings['space_between'] ?>
            },
            <?php echo $settings['tablet_width'] ?>: {
                slidesPerView: <?php echo $settings['tablet_item'] ?>,
                spaceBetween: <?php echo $settings['space_between'] ?>
            },
            <?php echo $settings['mobile_width'] ?>: {
                slidesPerView: <?php echo $settings['mobile_item'] ?>,
                spaceBetween: <?php echo $settings['space_between'] ?>
            }
        }
    });
});
</script>

<?php

    }

}
