<?php

if (function_exists('tutor')) {

$_   = $this->get_settings_for_display();
?>

<?php if ($_['course_style'] == '3'): ?>

<article class="tpc-course">
    <?php if ($_['hover_popup_type'] == 'show_content_popup') : ?>
        <div class="course__popup-wrap">

                <?php if ($_['show_instructor_img'] && $_['show_instructor_name']): ?>
                    <div class="tpc-course-author-name">
                        <?php if ($_['show_instructor_img']): ?>
                            <?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
                         <?php endif; ?>
                        <?php if ($_['show_instructor_name']): ?>
                            <?php echo get_the_author(); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

              <div class="courses-content">

                <div class="course__top-meta">
                     <?php if ($_['show_popup_cat']): ?>
                        <div class="course__categories ">
                            <?php echo get_the_term_list(get_the_ID(), 'course-category'); ?>
                        </div>
                     <?php endif; ?>
                    <?php if ($_['show_popup_price']): ?>
                     <div class="price">
                          <?php get_template_part('templates/tutor/price_within_button_2'); ?>
                     </div>
                    <?php endif; ?>
                </div>

                <?php if ($_['show_popup_title']): ?>
                <h4 class="course__title">
                    <a href="<?php the_permalink(); ?>" class="course__title-link">
                        <?php the_title(); ?>
                    </a>
                </h4>
                <?php endif; ?>
             </div>
            <div class="course__content--meta"> 

                <?php if ($_['show_popup_lesson']): 

                 endif; ?>
                <?php if ($_['show_popup_duration']): ?>

                <?php endif; ?>

            </div>

            <?php if ($_['show_popup_excerpt']): ?>
             <div class="course__excerpt">
                <?php the_excerpt(); ?> 
            </div>
            <?php endif; ?>
            <?php if ($_['show_popup_btn']): ?>
            <div class="btn__wrap">
                <a class="btn__a" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Preview This Course', 'gommc-core' ); ?></a>
            </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="course__container">

            <?php 

             if ( $_['hover_popup_type'] == 'show_video_popup') {
        

                echo '<div class="tpc-video_popup with_image">';
                echo '<div class="videobox_content">';
            } 

            if ($_['show_media']): ?>
            <div class="course__media">

                <?php if ( has_post_thumbnail() ):?>
                  <a class="course__media-link" href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail($_['image_size']);?>
                  </a>
                 <?php endif; ?>

                <!-- Start video -->
                <?php       
                    $video = maybe_unserialize( get_post_meta( get_the_ID(), '_video', true ) );
                    $videoSource    = tutor_utils()->avalue_dot( 'source', $video );

                    if ($video["source_youtube"] && $videoSource == 'youtube') {
                        $tutor_intro_video =    $video["source_youtube"];
                    }
                    elseif($video["source_vimeo"] && $videoSource == 'vimeo'){
                        $tutor_intro_video =    $video["source_vimeo"];
                    }
                    elseif($video["source_external_url"] && $videoSource == 'external_url'){
                        $tutor_intro_video =    $video["source_external_url"];
                    }
                    // elseif($video["source_video_id"] && $videoSource == 'html5'){
                    //  $tutor_intro_video =    $video["source_video_id"];
                    // }
                    // elseif($video["source_embedded"] && $videoSource == 'embedded'){
                    //  $tutor_intro_video =    $video["source_embedded"];
                    // }
                    else{
                        $tutor_intro_video =    '';
                    }

             
            if ( $_['hover_popup_type'] == 'show_video_popup' && !empty($tutor_intro_video)) { ?>

                <div class="videobox_link_wrapper">

                    <div class="videobox_link popup-youtube popup-vimeo" data-lity="" href="<?php echo esc_url( $tutor_intro_video ); ?>">
                        <svg class="videobox_icon" width="33%" height="33%" viewBox="0 0 232 232"><path d="M203,99L49,2.3c-4.5-2.7-10.2-2.2-14.5-2.2 c-17.1,0-17,13-17,16.6v199c0,2.8-0.07,16.6,17,16.6c4.3,0,10,0.4,14.5-2.2 l154-97c12.7-7.5,10.5-16.5,10.5-16.5S216,107,204,100z"></path>
                        </svg>
                    </div>
                </div>
            <?php     
            } // End video popup ?>

            </div>
        <?php 
        
            endif; // End show_media

            if ( $_['hover_popup_type'] == 'show_video_popup') {

            echo '</div>';
            echo '</div>';

             } // End video popup

         ?>

        <div class="course__content">
            <div class="course__content--info">
                <div class="course__top-meta">

                    <?php if ($_['show_cat']): ?>
                        <div class="course__categories ">
                            <?php echo get_the_term_list(get_the_ID(), 'course-category'); ?>
                        </div>
                     <?php endif; ?>
                    <?php if ($_['show_price']): ?>
                     <div class="price">
                          <?php get_template_part('templates/tutor/price_within_button_2'); ?>
                     </div>
                    <?php endif; ?>
                </div>
                    <?php if ($_['show_instructor_img']): ?>
                    <?php         
                        // ob_start();
                        // learn_press_courses_loop_item_instructor();
                        // $author_name = ob_get_clean();
                    ?>
                <?php endif; ?>

                    <?php if ($_['show_instructor_img']): ?>
                <h4 class="course__title">
                    <a href="<?php the_permalink(); ?>" class="course__title-link">
                        <?php the_title(); ?>
                    </a>
                </h4>
                <?php endif; ?>
                <?php if ($_['show_instructor_img'] && $_['show_instructor_name']): ?>
                    <div class="tpc-course-author-name">
                        <?php if ($_['show_instructor_img']): ?>
                            <?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
                         <?php endif; ?>
                        <?php if ($_['show_instructor_name']): ?>
                            <?php echo get_the_author(); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="course__content--meta"> 
                <div class="course__meta-left">

                      <?php if ($_['show_enroll']): 
                         $disable_total_enrolled = get_tutor_option('disable_course_total_enrolled');
                        if( !$disable_total_enrolled){ ?>
                            <span class="course-enroll"><i class="tutor-icon-user"></i> <?php echo (int) tutor_utils()->count_enrolled_users_by_course(); ?></span>
                        <?php } 
                        endif; ?>

                    <?php if ($_['show_lesson']):  ?>
                        <span class="course-lessons">
                            <i class="flaticon-book-1"></i>
                            <?php
                                $tutor_lesson_count = tutor_utils()->get_lesson_count_by_course(get_the_ID());
                                if($tutor_lesson_count) {
                                    echo "<span> $tutor_lesson_count";
                                  
                                    echo "</span>";
                                }
                            ?>  
                        </span>
                    <?php endif; ?>

                </div>
                <?php if ($_['show_review']): ?>
                <div class="course__meta-right">
                    <?php if($_['show_review']): ?>

                        <div class="course__review">
                            <?php
                                $course_rating = tutor_utils()->get_course_rating();
                                tutor_utils()->star_rating_generator($course_rating->rating_avg);
                            ?>
                        </div>                         

                     <?php endif; ?>
                </div>
                 <?php endif; ?>
               
            </div>
        </div>
    </div>

</article>

<?php elseif ($_['course_style'] == '2'): ?>
<article class="tpc-course">
    <?php if ($_['hover_popup_type'] == 'show_content_popup') : ?>
        <div class="course__popup-wrap">

              <div class="courses-content">

                <div class="course__top-meta">
                     <?php if ($_['show_popup_cat']): ?>
                        <div class="course__categories ">
                            <?php echo get_the_term_list(get_the_ID(), 'course-category'); ?>
                        </div>
                     <?php endif; ?>
                     <div class="price">
                          <?php get_template_part('templates/tutor/price_within_button_2'); ?>
                     </div>
                </div>

                <?php if ($_['show_popup_title']): ?>
                <h4 class="course__title">
                    <a href="<?php the_permalink(); ?>" class="course__title-link">
                        <?php the_title(); ?>
                    </a>
                </h4>
                <?php endif; ?>
             </div>
            <div class="course__content--meta"> 

                <?php if ($_['show_lesson']):  ?>
                    <span class="course-lessons">
                        <i class="flaticon-book-1"></i>
                        <?php
                            $tutor_lesson_count = tutor_utils()->get_lesson_count_by_course(get_the_ID());
                            if($tutor_lesson_count) {
                                echo "<span> $tutor_lesson_count";
                                esc_html_e(' Lessons', 'gommc-core');
                                echo "</span>";
                            }
                        ?>  
                    </span>
                <?php endif; ?>

                <?php if ($_['show_popup_duration']): ?>

                <?php endif; ?>

            </div>
             <div class="course__excerpt">
                <?php the_excerpt(); ?> 
            </div>

            <div class="btn__wrap">
                <a class="btn__a" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Preview This Course', 'gommc-core' ); ?></a>
            </div>
        </div>
        <?php endif ?>
    <div class="course__container">

            <div class="course__media">

                <?php if ( has_post_thumbnail() ):?>
                  <a class="course__media-link" href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail($_['image_size']);?>
                  </a>
                 <?php endif; ?>

            </div>


        <div class="course__content">
            <div class="course__content--info">
                <div class="course__top-meta">

                     <?php if ($_['show_cat']): ?>
                        <div class="course__categories ">
                            <?php echo get_the_term_list(get_the_ID(), 'course-category'); ?>
                        </div>
                     <?php endif; ?>
                         <div class="price-round">
                             <?php get_template_part('templates/tutor/price_within_button'); ?>
                        </div>
                </div>

                <?php if ($_['show_title']): ?>
                <h4 class="course__title">
                    <a href="<?php the_permalink(); ?>" class="course__title-link">
                        <?php the_title(); ?>
                    </a>
                </h4>
                <?php endif; ?>
                <?php if ($_['show_instructor_img'] && $_['show_instructor_name']): ?>
                    <div class="tpc-course-author-name">
                        <?php if ($_['show_instructor_img']): ?>
                            <?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
                         <?php endif; ?>
                        <?php if ($_['show_instructor_name']): ?>
                            <?php echo get_the_author(); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="course__content--meta"> 
                <div class="course__meta-left">

                <?php if ($_['show_enroll']): 
                 $disable_total_enrolled = get_tutor_option('disable_course_total_enrolled');
                if( !$disable_total_enrolled){ ?>
                    <span class="course-enroll"><i class="tutor-icon-user"></i> <?php echo (int) tutor_utils()->count_enrolled_users_by_course(); ?></span>
                <?php } 
                endif; ?>

                <?php if ($_['show_lesson']):  ?>
                    <span class="course-lessons">
                        <i class="flaticon-book-1"></i>
                        <?php
                            $tutor_lesson_count = tutor_utils()->get_lesson_count_by_course(get_the_ID());
                            if($tutor_lesson_count) {
                                echo "<span> $tutor_lesson_count";
                                echo "</span>";
                            }
                        ?>  
                    </span>
                <?php endif; ?>

                </div>
                <?php if ($_['show_review']): ?>
                <div class="course__meta-right">
                    <div class="course__review">
                        <?php
                            $course_rating = tutor_utils()->get_course_rating();
                            tutor_utils()->star_rating_generator($course_rating->rating_avg);
                        ?>
                    </div>
                </div>
                 <?php endif; ?>
               
            </div>
        </div>
    </div>

</article>
<?php else : ?> 
<article class="tpc-course">

    <?php if ($_['hover_popup_type'] == 'show_content_popup') : ?>
        <div class="course__popup-wrap">

              <div class="courses-content">

                <div class="course__top-meta">
                     <?php if ($_['show_popup_cat']): ?>
                        <div class="course__categories ">
                            <?php echo get_the_term_list(get_the_ID(), 'course-category'); ?>
                        </div>
                     <?php endif; ?>
                     <div class="price">
                          <?php get_template_part('templates/tutor/price_within_button_2'); ?>
                     </div>
                </div>

                <?php if ($_['show_popup_title']): ?>
                <h4 class="course__title">
                    <a href="<?php the_permalink(); ?>" class="course__title-link">
                        <?php the_title(); ?>
                    </a>
                </h4>
                <?php endif; ?>
                <?php if ($_['show_review'] ): ?>
                    <div class="course__review">
                        <?php         
                            $course_rating = tutor_utils()->get_course_rating();
                            tutor_utils()->star_rating_generator($course_rating->rating_avg);
                         ?>
                    </div>
                 <?php endif; ?>
             </div>
            <div class="course__content--meta"> 

                <?php if ($_['show_lesson']):  ?>
                    <span class="course-lessons">
                        <i class="flaticon-book-1"></i>
                        <?php
                            $tutor_lesson_count = tutor_utils()->get_lesson_count_by_course(get_the_ID());
                            if($tutor_lesson_count) {
                                echo "<span> $tutor_lesson_count";
                                esc_html_e(' Lessons', 'gommc-core');
                                echo "</span>";
                            }
                        ?>  
                    </span>
                <?php endif; ?>

                <?php if ($_['show_duration']): ?>
                     <?php 
                         $course_duration = get_tutor_course_duration_context();
                    if (!empty($course_duration)): ?>
                        <span class="course-lessons">
                            <i class="flaticon-wall-clock"></i> 
                            <?php echo esc_attr( $course_duration ); ?>  
                        </span>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
             <div class="course__excerpt">
                <?php the_excerpt(); ?> 
            </div>

            <div class="btn__wrap">
                <a class="btn__a" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Preview This Course', 'gommc-core' ); ?></a>
            </div>
        </div>
        <?php endif ?>
    <div class="course__container">

            <?php 

             if ( $_['hover_popup_type'] == 'show_video_popup') {
        

                echo '<div class="tpc-video_popup with_image">';
                echo '<div class="videobox_content">';
            } 

            if ($_['show_media']): ?>
            <div class="course__media">

                <?php if ( has_post_thumbnail() ):?>
                  <a class="course__media-link" href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail($_['image_size']);?>
                  </a>
                 <?php endif; ?>

                <!-- Start video -->
                <?php       
                    $video = maybe_unserialize( get_post_meta( get_the_ID(), '_video', true ) );
                    $videoSource    = tutor_utils()->avalue_dot( 'source', $video );

                    if ($video["source_youtube"] && $videoSource == 'youtube') {
                        $tutor_intro_video =    $video["source_youtube"];
                    }
                    elseif($video["source_vimeo"] && $videoSource == 'vimeo'){
                        $tutor_intro_video =    $video["source_vimeo"];
                    }
                    elseif($video["source_external_url"] && $videoSource == 'external_url'){
                        $tutor_intro_video =    $video["source_external_url"];
                    }
                    // elseif($video["source_video_id"] && $videoSource == 'html5'){
                    //  $tutor_intro_video =    $video["source_video_id"];
                    // }
                    // elseif($video["source_embedded"] && $videoSource == 'embedded'){
                    //  $tutor_intro_video =    $video["source_embedded"];
                    // }
                    else{
                        $tutor_intro_video =    '';
                    }

             
            if ( $_['hover_popup_type'] == 'show_video_popup' && !empty($tutor_intro_video)) { ?>

                <div class="videobox_link_wrapper">

                    <div class="videobox_link popup-youtube popup-vimeo" data-lity="" href="<?php echo esc_url( $tutor_intro_video ); ?>">
                        <svg class="videobox_icon" width="33%" height="33%" viewBox="0 0 232 232"><path d="M203,99L49,2.3c-4.5-2.7-10.2-2.2-14.5-2.2 c-17.1,0-17,13-17,16.6v199c0,2.8-0.07,16.6,17,16.6c4.3,0,10,0.4,14.5-2.2 l154-97c12.7-7.5,10.5-16.5,10.5-16.5S216,107,204,100z"></path>
                        </svg>
                    </div>
                </div>
            <?php     
            } // End video popup ?>

            </div>
        <?php 
        
            endif; // End show_media

            if ( $_['hover_popup_type'] == 'show_video_popup') {

            echo '</div>';
            echo '</div>';

             } // End video popup

         ?>

        <div class="course__content">
            <div class="course__content--info">
                <div class="course__top-meta">

                     <?php if ($_['show_cat']): ?>
                        <div class="course__categories ">
                            <?php echo get_the_term_list(get_the_ID(), 'course-category'); ?>
                        </div>
                     <?php endif; ?>
                </div>

                <?php if ($_['show_title']): ?>
                <h4 class="course__title">
                    <a href="<?php the_permalink(); ?>" class="course__title-link">
                        <?php the_title(); ?>
                    </a>
                </h4>
                <?php endif; ?>
                <?php if ($_['show_instructor_img'] && $_['show_instructor_name']): ?>
                    <div class="tpc-course-author-name">
                        <?php if ($_['show_instructor_img']): ?>
                            <?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
                         <?php endif; ?>
                        <?php if ($_['show_instructor_name']): ?>
                            <?php echo get_the_author(); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="course__content--meta"> 
                <div class="course__meta-left">

                <?php if ($_['show_enroll']): 
                 $disable_total_enrolled = get_tutor_option('disable_course_total_enrolled');
                if( !$disable_total_enrolled){ ?>
                    <span class="course-enroll"><i class="tutor-icon-user"></i> <?php echo (int) tutor_utils()->count_enrolled_users_by_course(); ?></span>
                <?php } 
                endif; ?>

                <?php if ($_['show_lesson']): 
                    $tutor_lesson_count = tutor_utils()->get_lesson_count_by_course(get_the_ID());
                    if($tutor_lesson_count) {
                        echo "<span><i class='flaticon-book-1'></i> $tutor_lesson_count";
                        echo "</span>";
                    }
                    endif; ?>

                <?php if ($_['show_review'] ) : 
                    $course_rating = tutor_utils()->get_course_rating();
                    $total_reviews = apply_filters('tutor_course_rating_count', $course_rating->rating_count);

                    if ($course_rating->rating_avg > 0) { ?>
                        <span class="course-rating"><i class="flaticon-star-1"></i>
                            <?php echo $total_reviews; ?>
                        </span>
                    <?php }
                     endif; ?>
                </div>

                 <?php if ($_['show_enroll_btn']): ?>    
                    <div class="course__meta-right">
                         <div class="price">
                             <?php get_template_part('templates/tutor/price_within_button_2'); ?>
                        </div>
                     </div>
                 <?php endif ?>
            </div>
        </div>
    </div>

</article>
<?php endif ?>
<?php } //if class exist tutor ?>