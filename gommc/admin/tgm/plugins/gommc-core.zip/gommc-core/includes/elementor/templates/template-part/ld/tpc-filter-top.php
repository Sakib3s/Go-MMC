
<div class="course-top-bar">

      <?php if ($settings['show_filter_showing_results']): ?>
         <div class="course-top-text">
           <?php $count = 0;?>
            <p><?php echo esc_html($settings['filter_showing']); ?> <span><?php printf('%d - %d of %d', $count + 1, $count + $query->post_count, $query->found_posts ); ?></span> <?php echo esc_html($settings['filter_results']); ?></p>
         </div>
      <?php endif; ?>

     <div class="course-top-inner">
            <?php if ($settings['show_filter_grid_list']): ?>
               <div class="filter__top gommc-course-switch-layout switch-layout">
                  <span class="label">View</span>
                  <a href="javascript:void(0)" id="gommc_showdiv1" ><i class="fa fa-th-large"></i></a>
                  <a href="javascript:void(0)" id="gommc_showdiv2" ><i class="fa fa-list-ul"></i></a>
               </div>
            <?php endif; ?>
         <div class="course-collapse-btn">
             <button class="btn btn-primary btn__first" data-toggle="collapse" data-target=".collapse.first" data-text="Collapse">
                 <i class="fa fa-filter"></i>
                 Filters
                 <i class="fa fa-angle-down"></i>
             </button>
         </div>
     </div>
 </div>

<div class="collapse first">
     <form class="gommc-sidebar-filter is-top" action="<?php echo esc_url($finalurl); ?>" method="get">
          <input type="hidden" name="s" value="<?php echo get_search_query(); ?>">

              <!--  Filter by categories -->
              <?php if ($settings['show_filter_cat']): ?>
              <div class="single-filter widget">

              <?php if ($settings['filter_cat_text']) : ?>
                  <h4 class="widget-title"><?php echo esc_html($settings['filter_cat_text']); ?></h4>
              <?php endif;?>

              <?php $lp_filter_object = new \LP_Course_filter_Nasted_Cat();
                 $lp_filter_object->render_terms('category');
              ?>
              
              </div>
              <?php endif ?>
               <!--  //Filter by categories -->

              <!--  filter by tag -->
              <?php if ($settings['show_filter_tag']): ?>
              <div class="single-filter widget"> 
               <?php if ($settings['filter_tag_text']) { ?>  
                  <h4 class="widget-title"><?php echo esc_html($settings['filter_tag_text']); ?></h4>
              <?php } ?>
                  <div class="filter-content">
                 <?php
                 foreach ($course_terms_tag as $course_tag) {
                      ?>
                          <label for="tag-<?php echo esc_attr($course_tag->slug) ?>">
                              <input
                                  type="checkbox"
                                  name="course_tag[]"
                                  value="<?php echo esc_attr($course_tag->term_id) ?>"
                                  id="tag-<?php echo esc_attr($course_tag->slug) ?>"
                                  <?php echo in_array($course_tag->term_id, $selected_tag) ? 'checked="checked"' : ''; ?>
                              >
                              <span class="filter-checkbox"><?php echo esc_html($course_tag->name) ?></span>
                              <?php if ($settings['show_filter_tag_count']) { ?>
                                  <span class="filter-checkbox-count"><?php echo esc_attr('('. $course_tag->count .')');?></span>
                              <?php } ?>
                          </label>
                  <?php }?>
                  </div>
              </div>
              <?php endif ?>
              <!--  //End tag -->

              <!--  Filter by author -->
              <?php if ($settings['show_filter_author']): ?>
              <div class="single-filter widget">

              <?php if ($settings['filter_author_text']) { ?>
                  <h4 class="widget-title"><?php echo esc_html($settings['filter_author_text']); ?></h4>
              <?php } ?>

                  <div class="filter-content">
                      <?php
                      $course_authors = get_users();
                      foreach ($course_authors as $user) {
                          if ( gommc_count_user_posts_by_type( $user->ID, 'lp_course') ) {
                      ?>
                          <label for="<?php echo $user->ID; ?>">
                              <input
                                  type="checkbox"
                                  name="course_author[]"
                                  value="<?php echo $user->ID; ?>"
                                  id="<?php echo $user->ID; ?>"
                                  <?php echo in_array( $user->ID, $selected_author) ? 'checked="checked"' : ''; ?>
                              >
                          <span class="filter-checkbox"><?php echo $user->display_name; ?></span>
                          <?php $user_post_count = gommc_count_user_posts_by_type( $user->ID, 'lp_course'); ?>

                          <?php if ($settings['show_filter_author_count']) { ?>
                              <span class="filter-checkbox-count"><?php echo esc_attr('('. $user_post_count .')');?></span>
                          <?php } ?>

                          </label>
                      <?php
                          }
                      }
                      ?>
                  </div>
              </div>
              <?php endif ?>
              <!--  //End Filter by author -->

              <!-- Filter by language -->
              <?php if ($settings['show_filter_language']): ?>
                  <div class="single-filter widget">
                  <h4 class="widget-title"><?php echo esc_html($settings['filter_language_text']); ?></h4>
                      <div class="filter-content">
                      <?php
                          foreach ($course_terms_language as $course_language) {
                      ?>
                          <label for="tag-<?php echo esc_attr($course_language->slug) ?>">
                              <input
                                  type="checkbox"
                                  name="course_language[]"
                                  value="<?php echo esc_attr($course_language->term_id) ?>"
                                  id="tag-<?php echo esc_attr($course_language->slug) ?>"
                                  <?php echo in_array($course_language->term_id, $selected_language) ? 'checked="checked"' : ''; ?>
                              >
                              <span class="filter-checkbox"><?php echo esc_html($course_language->name) ?></span>

                              <?php if ($settings['show_filter_language_count']) { ?>
                                  <span class="filter-checkbox-count"><?php echo esc_attr('('. $course_language->count .')');?></span>
                              <?php } ?>

                          </label>
                      <?php } ?>
                      </div>
                  </div>
              <?php endif ?>
              <!--  //End Filter by language -->

              <!--  Filter by level -->
              <?php if ($settings['show_filter_level']): ?>
                  <div class="single-filter widget">
                      <?php if ($settings['filter_level_text']) { ?>
                          <h4 class="widget-title"><?php echo esc_html($settings['filter_level_text']); ?></h4>
                     <?php } ?>
                      <div class="filter-content">
                      <?php
                      foreach ($course_levels as $key => $course_level) {
                          if ($key == 'all_levels') {
                              continue;
                          }
                      ?>
                          <label for="<?php echo esc_attr($key); ?>">
                              <input
                                  type="checkbox"
                                  name="course_level[]"
                                  value="<?php echo esc_attr($key); ?>"
                                  id="<?php echo esc_attr($key); ?>"
                                  <?php echo in_array($key, $selected_level) ? 'checked="checked"' : ''; ?>
                              >
                              <span class="filter-checkbox"></span>
                              <?php echo esc_html($course_level); ?>
                          </label>
                          <?php
                      }?>
                      </div>
                  </div>
              <?php endif ?>
          <!--  //End level -->

      </form>
</div> 