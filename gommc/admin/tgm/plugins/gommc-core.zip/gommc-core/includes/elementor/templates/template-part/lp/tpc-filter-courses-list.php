<?php

if (class_exists('LearnPress')) {

    $_   = $this->get_settings_for_display();

    $course    = LP()->global['course'];
    $course_id = get_the_ID();
    $count = $course->get_users_enrolled();
?>

<div class="col-lg-12">
  <div class="gommc-course gommc-course-list">
    <div class="row">

        <?php if ( has_post_thumbnail() && $_['show_media']) : ?>
        <div class="col-md-4">
            <div class="course__media">
                <a class="course__media-link" href="<?php the_permalink(); ?>">
                 <?php the_post_thumbnail($_['image_size']);?>
                </a>
            </div>
        </div>
        <?php endif; ?>

        <div class="col-md-<?php if($_['show_media']) : echo '8'; else : echo '12'; endif; ?>">
         <div class="course-content">

            <?php if ($_['show_cat'] || $_['show_price'] ): ?>
              <div class="course__top-meta">
                   <?php if ($_['show_cat'] ): ?>
                      <div class="course__categories ">
                          <?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
                      </div>
                   <?php endif; ?>
                   <?php if ($_['show_price']): ?>
                       <div class="price">
                            <?php get_template_part('templates/learnpress/price_within_button_2'); ?>
                       </div>
                   <?php endif; ?>
              </div>
            <?php endif; ?>

            <?php
              the_title(sprintf('<h4 class="course__title"><a href="%s" rel="bookmark">', esc_url(get_permalink())), '</a></h4>');
              do_action('learn_press_after_the_title');
            ?>
            <div class="course__content--meta"> 
                <div class="course__meta-left">
                <?php if ($_['show_lesson']): 
                        $course = \LP_Global::course();
                        $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
                        $lessons_text = ('1' == $lessons) ? esc_html__('Lesson', 'gommc-core') : esc_html__('Lessons', 'gommc-core');
                        printf('<span class="course-lessons is__icon"> <i class="flaticon-book-1"></i>  %s %s</span>', $lessons, $lessons_text);
                 endif; ?>
                <?php if ($_['show_duration']): ?>
                    <span class="course-duration is__icon">
                    <i class="flaticon-wall-clock"> </i> <?php echo learn_press_get_post_translated_duration( get_the_ID(), esc_html__( ' Lifetime access', 'gommc-core' ) ); ?>
                    </span>
                <?php  endif; ?>
             <?php if ( class_exists('LP_Addon_Course_Review_Preload') && $_['show_review']): ?>

                    <div class="course__review">
                
                        <?php
                            $course_id       = get_the_ID();
                            $course_rate_res = learn_press_get_course_rate( $course_id, false );
                            $course_rate     = $course_rate_res['rated'];
                            $total           = $course_rate_res['total'];
                            learn_press_course_review_template( 'rating-stars.php', array( 'rated' => $course_rate ) );
                        ?>
                    </div> <span class="review__count"><?php echo esc_attr('('); ?><?php echo $course_rate; ?><?php echo esc_attr(')'); ?></span>
 
                 <?php endif; ?>
                </div>
            </div>


            <?php the_excerpt();?>

              </div>
            </div>
          </div> <!--  row  -->
        </div> <!-- single course -->
      </div>
<?php } //if class exist learnpress ?>