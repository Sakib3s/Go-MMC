<?php
/*
 * This template can be overridden by copying it to yourtheme/gommc-core/elementor/widgets/tpc-info-box.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\{Widget_Base, Controls_Manager};
use Elementor\{Group_Control_Typography, Group_Control_Background, Group_Control_Box_Shadow};
use TPCAddons\GoMMC_Global_Variables as GoMMC_Globals;
use TPCAddons\Includes\{TPC_Loop_Settings};
use TPCAddons\Templates\TPC_Courses_LearnDash;
use TPCAddons\Templates\TPC_Courses_LearnDash_2;
use TPCAddons\Templates\TPC_Courses_LearnDash_3;

class TPC_Courses_LD extends Widget_Base
{
    public function get_name()
    {
        return 'tpc-ld-courses';
    }

    public function get_title()
    {
        return esc_html__('LearnDash Courses', 'gommc-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-posts-grid';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }


    protected function register_controls()
    {
        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_general',
            [ 'label' => esc_html__('General', 'gommc-core') ]
        );

        $this->add_control(
            'course_layout',
            [
                'type' => 'tpc-radio-image',
                'options' => [
                    'grid' => [
                        'title' => esc_html__('Grid', 'gommc-core'),
                        'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/layout_grid.png',
                    ],
                    'masonry' => [
                        'title' => esc_html__('Masonry', 'gommc-core'),
                        'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/layout_masonry.png',
                    ],
                    'carousel' => [
                        'title' => esc_html__('Carousel', 'gommc-core'),
                        'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/layout_carousel.png',
                    ],
                ],
                'default' => 'grid',
            ]
        );

        $this->add_control(
            'layout',
            [
                'label' => esc_html__('Layout', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('Layout 1', 'gommc-core'),
                    '2' => esc_html__('Layout 2', 'gommc-core'),
                    '3' => esc_html__('Layout 3', 'gommc-core'),
                ],
                'default' => '1',
            ]
        );   

        $this->add_control(
            'grid_columns',
            [
                'label' => esc_html__('Grid Columns Amount', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('1 / One', 'gommc-core'),
                    '2' => esc_html__('2 / Two', 'gommc-core'),
                    '3' => esc_html__('3 / Three', 'gommc-core'),
                    '4' => esc_html__('4 / Four', 'gommc-core'),
                    '5' => esc_html__('5 / Five', 'gommc-core'),
                ],
                'default' => '3',
            ]
        );

        $this->add_control(
            'img_size_string',
            [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Image Size', 'gommc-core'),
                'options' => [
                    '150' => 'Thumbnail - 150x150',
                    '300' => 'Medium - 300x300',
                    '768' => 'Medium Large - 768x768',
                    '1024' => 'Large - 1024x1024',
                    '740x540' => '740x540', // 3col
                    'full' => 'Full',
                    'custom' => 'Custom',
                ],
                'default' => '740x540', // 3col
            ]
        );

        $this->add_control(
            'img_size_array',
            [
                'label' => esc_html__('Image Dimension', 'gommc-core'),
                'type' => Controls_Manager::IMAGE_DIMENSIONS,
                'description' => esc_html__('You can crop the original image size to any custom size. You can also set a single value for height or width in order to keep the original size ratio.', 'gommc-core'),
                'condition' => [
                    'img_size_string' => 'custom',
                ],
                'default' => [
                    'width' => '740',
                    'height' => '540',
                ]
            ]
        );

        $this->add_control(
            'img_aspect_ratio',
            [
                'type' => Controls_Manager::SELECT,
                'label' => esc_html__('Image Aspect Ratio', 'gommc-core'),
                'options' => [
                    '1:1' => '1:1',
                    '3:2' => '3:2',
                    '4:3' => '4:3',
                    '6:5' => '6:5',
                    '9:16' => '9:16',
                    '16:9' => '16:9',
                    '21:9' => '21:9',
                    '' => 'Not Crop',
                ],
                'default' => '',
            ]
        );

        $this->add_control(
            'isotope_filter',
            [
                'label' => esc_html__('Use Filter?', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [ 'course_layout!' => 'carousel' ],
            ]
        );

        $this->add_control(
            'pagination',
            [
                'label' => esc_html__('Add Pagination', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 'course_layout!' => 'carousel' ],
            ]
        );

        $this->add_control(
            'single_link_image',
            [
                'label' => esc_html__('Add Link on Image', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [ 'hide_media!' => 'yes' ],
            ]
        );

        $this->add_control(
            'single_link_title',
            [
                'label' => esc_html__('Add Link on Title', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [ 'hide_title!' => 'yes' ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> APPEARANCE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_appearance',
            [ 'label' => esc_html__('Appearance', 'gommc-core') ]
        );

        $this->add_control(
            'hide_media',
            [
                'label' => esc_html__('Hide Media', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'hide_tax',
            [
                'label' => esc_html__('Hide Categories', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'hide_price',
            [
                'label' => esc_html__('Hide Price', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'hide_title',
            [
                'label' => esc_html__('Hide Title', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'hide_instructor',
            [
                'label' => esc_html__('Hide Instructor', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'hide_lessons',
            [
                'label' => esc_html__('Hide Lessons', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );
        $this->add_control(
            'hide_lessons_text',
            [
                'label' => esc_html__('Hide Lessons Text', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 'hide_lessons!' => 'yes' ],
            ]
        );
        $this->add_control(
            'lesson_text',
            [
                'label'   => __( 'Custom Lessons Text', 'gommc-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Lesson','gommc-core'),
                'condition' => [ 'hide_lessons!' => 'yes' ],

            ]    
        );
        $this->add_control(
            'lessons_text',
            [
                'label'   => __( 'Custom Lessons Text', 'gommc-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Lessons','gommc-core'),
                'condition' => [ 'hide_lessons!' => 'yes' ],
            ]    
        );
        $this->add_control(
            'hide_topic',
            [
                'label' => esc_html__('Hide Topic', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'hide_topic_text',
            [
                'label' => esc_html__('Hide Topic Text', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 'hide_topic!' => 'yes' ],
            ]
        );
        $this->add_control(
            'topic_text',
            [
                'label'   => __( 'Custom Topic Text', 'gommc-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Topic','gommc-core'),
                'condition' => [ 'hide_topic!' => 'yes' ],

            ]    
        );
        $this->add_control(
            'topics_text',
            [
                'label'   => __( 'Custom Topics Text', 'gommc-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Topics','gommc-core'),
                'condition' => [ 'hide_topic!' => 'yes' ],
            ]    
        );
        // $this->add_control(
        //     'hide_quiz',
        //     [
        //         'label' => esc_html__('Hide Quiz', 'gommc-core'),
        //         'type' => Controls_Manager::SWITCHER,
        //         'default' => 'yes',
        //     ]
        // );
        // $this->add_control(
        //     'hide_quiz_text',
        //     [
        //         'label' => esc_html__('Hide Quiz Text', 'gommc-core'),
        //         'type' => Controls_Manager::SWITCHER,
        //         'condition' => [ 'hide_quiz!' => 'yes' ],
        //     ]
        // );
        // $this->add_control(
        //     'quiz_text',
        //     [
        //         'label'   => __( 'Custom Quiz Text', 'gommc-core' ),
        //         'type'    => Controls_Manager::TEXT,
        //         'label_block' => true,
        //         'default' => __('Quiz','gommc-core'),
        //         'condition' => [ 'hide_quiz!' => 'yes' ],

        //     ]    
        // );
        // $this->add_control(
        //     'quizzes_text',
        //     [
        //         'label'   => __( 'Custom Quizzes Text', 'gommc-core' ),
        //         'type'    => Controls_Manager::TEXT,
        //         'label_block' => true,
        //         'default' => __('Quizzes','gommc-core'),
        //         'condition' => [ 'hide_quiz!' => 'yes' ],
        //     ]    
        // );
        $this->add_control(
            'hide_enroll',
            [
                'label' => esc_html__('Hide Enroll', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                // 'default' => 'yes',
            ]
        );

        $this->add_control(
            'enroll_now_text',
            [
                'label'   => __( 'Enroll Now', 'gommc-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Enroll Now','gommc-core'),

            ]    
        );
        $this->add_control(
            'hide_enroll_now_text',
            [
                'label' => esc_html__('See More/Arrow Icon', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'hide_excerpt',
            [
                'label' => esc_html__('Hide Excerpt/Content', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'excerpt_chars',
            [
                'label' => esc_html__('Limit the Excerpt/Content letters', 'gommc-core'),
                'type' => Controls_Manager::NUMBER,
                'condition' => [ 'hide_excerpt!' => 'yes' ],
                'min' => 1,
                'default' => '100',
            ]
        );

        $this->add_control(
            'enrolled_text',
            [
                'label'   => __( 'Enrolled Text', 'gommc-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Enrolled','gommc-core'),

            ]    
        );
        $this->add_control(
            'completed_text',
            [
                'label'   => __( 'Completed Text', 'gommc-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Completed','gommc-core'),

            ]    
        );
        $this->end_controls_section();


        // Popup
        $this->start_controls_section(
            'course_popup_option',
            [
                'label' => __( 'Hover Popup', 'gommc-core' ),
            ]
        );
        $this->add_control(
            'hover_popup_type',
            [
                'label' => esc_html__('Hover Popup Type', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => 'None',
                    'show_content_popup' => 'Popup Content',
                    'show_video_popup' => 'Popup Video',
                ],
                'default' => 'none',
            ]
        );

        $this->add_control(
            'show_popup_instructor',
            [
                'label' => esc_html__( 'Instructor', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => ['hover_popup_type' => 'show_content_popup']
            ]
        ); 
        $this->add_control(
            'show_popup_cat',
            [
                'label' => esc_html__( 'Category', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => ['hover_popup_type' => 'show_content_popup']
            ]
        );
        $this->add_control(
            'show_popup_price',
            [
                'label' => esc_html__( 'Price', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => ['hover_popup_type' => 'show_content_popup']
            ]
        ); 
        $this->add_control(
            'show_popup_title',
            [
                'label' => esc_html__( 'Title', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => ['hover_popup_type' => 'show_content_popup']
            ]
        ); 
        $this->add_control(
            'show_popup_lesson',
            [
                'label' => esc_html__( 'Lesson', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => ['hover_popup_type' => 'show_content_popup']
            ]
        ); 

        $this->add_control(
            'show_popup_duration',
            [
                'label' => esc_html__( 'Duration', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => ['hover_popup_type' => 'show_content_popup']
            ]
        ); 
        $this->add_control(
            'show_popup_excerpt',
            [
                'label' => esc_html__( 'Excerpt', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => ['hover_popup_type' => 'show_content_popup']
            ]
        ); 
        $this->add_control(
            'show_popup_btn',
            [
                'label' => esc_html__( 'Button', 'gommc-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => ['hover_popup_type' => 'show_content_popup']
            ]
        ); 
        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> CAROUSEL OPTIONS
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_carousel',
            [
                'label' => esc_html__('Carousel Options', 'gommc-core'),
                'condition' => ['course_layout' => 'carousel']
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => esc_html__('Autoplay', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'gommc-core'),
                'label_off' => esc_html__('Off', 'gommc-core'),
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => esc_html__('Autoplay Speed', 'gommc-core'),
                'type' => Controls_Manager::NUMBER,
                'condition' => ['autoplay!' => ''],
                'min' => 1,
                'default' => '3000',
            ]
        );

        $this->add_control(
            'infinity_on_the_right',
            [
                'label' => esc_html__('Infinity on the Right', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('On', 'gommc-core'),
                'label_off' => esc_html__('Off', 'gommc-core'),
                'prefix_class' => 'infinity_',
            ]
        );

        $this->add_control(
            'infinite_loop',
            [
                'label' => esc_html__('Infinite Loop', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'slide_single',
            [
                'label' => esc_html__('Slide One Item per time', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'pag_divider_before',
            [
                'type' => Controls_Manager::DIVIDER,
                'condition' => ['use_pagination!' => ''],
            ]
        );

        $this->add_control(
            'use_pagination',
            [
                'label' => esc_html__('Add Pagination controls', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'pag_type',
            [
                'label' => esc_html__('Pagination Type', 'gommc-core'),
                'type' => 'tpc-radio-image',
                'condition' => ['use_pagination!' => ''],
                'options' => [
                    'circle' => [
                        'title' => esc_html__('Circle', 'gommc-core'),
                        'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_circle.png',
                    ],
                    'circle_border' => [
                        'title' => esc_html__('Empty Circle', 'gommc-core'),
                        'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_circle_border.png',
                    ],
                    'square' => [
                        'title' => esc_html__('Square', 'gommc-core'),
                        'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_square.png',
                    ],
                    'square_border' => [
                        'title' => esc_html__('Empty Square', 'gommc-core'),
                        'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_square_border.png',
                    ],
                    'line' => [
                        'title' => esc_html__('Line', 'gommc-core'),
                        'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_line.png',
                    ],
                    'line_circle' => [
                        'title' => esc_html__('Line - Circle', 'gommc-core'),
                        'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_line_circle.png',
                    ],
                ],
                'default' => 'line_circle',
            ]
        );

        $this->add_responsive_control(
            'pag_align',
            [
                'label' => esc_html__('Pagination Aligning', 'gommc-core'),
                'type' => Controls_Manager::SLIDER,
                'condition' => ['use_pagination!' => ''],
                'size_units' => ['%'],
                'range' => [
                    '%' => ['min' => 0, 'max' => 100],
                ],
                'default' => ['size' => 50, 'unit' => '%'],
                'selectors' => [
                    '{{WRAPPER}} .slick-dots' => 'margin-left: {{SIZE}}%; transform: translateX(-{{SIZE}}%);',
                ],
            ]
        );

        $this->add_control(
            'pag_offset',
            [
                'label' => esc_html__('Top Offset', 'gommc-core'),
                'type' => Controls_Manager::NUMBER,
                'condition' => ['use_pagination!' => ''],
                'min' => -50,
                'max' => 150,
                'selectors' => [
                    '{{WRAPPER}} .tpc-carousel .slick-dots' => 'margin-top: {{VALUE}}px;',
                ],
            ]
        );

        $this->add_control(
            'custom_pag_color',
            [
                'label' => esc_html__('Customize Color', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => ['use_pagination!' => ''],
            ]
        );

        $this->add_control(
            'pag_color',
            [
                'label' => esc_html__('Pagination Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'use_pagination!' => '',
                    'custom_pag_color!' => '',
                ],
                'dynamic' => ['active' => true],
                'default' => gommc_Globals::get_primary_color(),
            ]
        );

        $this->add_control(
            'pag_divider_after',
            [
                'type' => Controls_Manager::DIVIDER,
                'condition' => ['use_pagination!' => ''],
            ]
        );

        $this->add_control(
            'use_navigation',
            [
                'label' => esc_html__('Add Navigation controls', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'resp_divider',
            [
                'type' => Controls_Manager::DIVIDER,
                'condition' => ['custom_resp!' => ''],
            ]
        );

        $this->add_control(
            'custom_resp',
            [
                'label' => esc_html__('Customize Responsive', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->add_control(
            'heading_desktop',
            [
                'label' => esc_html__('Desktop Settings', 'gommc-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => ['custom_resp!' => ''],
            ]
        );

        $this->add_control(
            'resp_medium',
            [
                'label' => esc_html__('Desktop Screen Breakpoint', 'gommc-core'),
                'type' => Controls_Manager::NUMBER,
                'condition' => ['custom_resp!' => ''],
                'min' => 1,
                'default' => '1025',
            ]
        );

        $this->add_control(
            'resp_medium_slides',
            [
                'label' => esc_html__('Slides to show', 'gommc-core'),
                'type' => Controls_Manager::NUMBER,
                'condition' => ['custom_resp!' => ''],
                'min' => 1,
            ]
        );

        $this->add_control(
            'heading_tablet',
            [
                'label' => esc_html__('Tablet Settings', 'gommc-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => ['custom_resp!' => ''],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'resp_tablets',
            [
                'label' => esc_html__('Tablet Screen Breakpoint', 'gommc-core'),
                'type' => Controls_Manager::NUMBER,
                'condition' => ['custom_resp!' => ''],
                'min' => 1,
                'default' => '800',
            ]
        );

        $this->add_control(
            'resp_tablets_slides',
            [
                'label' => esc_html__('Slides to show', 'gommc-core'),
                'type' => Controls_Manager::NUMBER,
                'condition' => ['custom_resp!' => ''],
                'min' => 1,
            ]
        );

        $this->add_control(
            'heading_mobile',
            [
                'label' => esc_html__('Mobile Settings', 'gommc-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => ['custom_resp!' => ''],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'resp_mobile',
            [
                'label' => esc_html__('Mobile Screen Breakpoint', 'gommc-core'),
                'type' => Controls_Manager::NUMBER,
                'condition' => ['custom_resp!' => ''],
                'min' => 1,
                'default' => '480',
            ]
        );

        $this->add_control(
            'resp_mobile_slides',
            [
                'label' => esc_html__('Slides to show', 'gommc-core'),
                'type' => Controls_Manager::NUMBER,
                'condition' => ['custom_resp!' => ''],
                'min' => 1,
            ]
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  SETTINGS -> QUERY
        /*-----------------------------------------------------------------------------------*/

        TPC_Loop_Settings::init(
            $this,
            [
                'post_type' => 'sfwd-courses',
                'hide_cats' => true,
                'hide_tags' => true
            ]
        );

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_item',
            [
                'label' => esc_html__('General', 'gommc-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'item_content_padding',
            [
                'label' => esc_html__('Content Padding', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '20',
                    'right' => '30',
                    'bottom' => '20',
                    'left' => '30',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .course__content--info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'item_meta_padding',
            [
                'label' => esc_html__('Meta Padding', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                // 'default' => [
                //     'top' => '10',
                //     'right' => '30',
                //     'bottom' => '10',
                //     'left' => '30',
                //     'unit' => 'px',
                //     'isLinked' => false,
                // ],
                'selectors' => [
                    '{{WRAPPER}} .course__content--meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'bg_content_color_idle',
            [
                'label' => esc_html__('Background Content Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .course__container' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
   /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> Filter
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_filter',
            [
                'label' => esc_html__('Filter', 'gommc-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'filter_title_align',
            [
                'label' => __( 'Alignment', 'gommc-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'gommc-core' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'gommc-core' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'gommc-core' ),
                        'icon' => 'fa fa-align-right',
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .course__filter, .tpc-courses .course__filter' => 'text-align: {{VALUE}};',
                ],
                'default' => 'center',
            ]
        );
        $this->add_responsive_control(
            'filter_position',
            [
                'label' => __( 'Position', 'gommc-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -150,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .course__filter, .tpc-courses .course__filter' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'filter_padding',
            [
                'label' => esc_html__('Padding', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .course__filter, .tpc-courses .course__filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'filter_margin',
            [
                'label' => esc_html__('Margin', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .course__filter, .tpc-courses .course__filter' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

         $this->end_controls_section();
        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> TITLE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_title',
            [
                'label' => esc_html__('Heading', 'gommc-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['hide_title' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_title',
                'separator' => 'before',
                'selector' => '{{WRAPPER}} .course__title,
                                {{WRAPPER}} .course__title > a',
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__('HTML tag', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                ],
                'default' => 'h4',
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__('Margin', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .course__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('tabs_title');

        $this->start_controls_tab(
            'tab_title_idle',
            ['label' => esc_html__('Idle', 'gommc-core') ]
        );

        $this->add_control(
            'title_color_idle',
            [
                'label' => esc_html__('Text Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'default' => GoMMC_Globals::get_h_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .course__title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_title_hover',
            ['label' => esc_html__('Hover', 'gommc-core') ]
        );

        $this->add_control(
            'title_color_hover',
            [
                'label' => esc_html__('Text Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'default' => GoMMC_Globals::get_primary_color(),
                'selectors' => [
                    '{{WRAPPER}} .course__title:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> CONTENT
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_content',
            [
                'label' => esc_html__('Content', 'gommc-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['hide_excerpt' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content',
                'selector' => '{{WRAPPER}} .course__excerpt',
            ]
        );

        $this->add_responsive_control(
            'content_margin',
            [
                'label' => esc_html__('Margin', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .course__excerpt' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__('Text Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'default' => GoMMC_Globals::get_main_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .course__excerpt' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> META
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_meta',
            [
                'label' => esc_html__('Meta Data', 'gommc-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'meta',
                'selector' => '{{WRAPPER}} .tpc-courses .course__content--meta > span',
            ]
        );

        $this->add_control(
            'meta_color',
            [
                'label' => esc_html__('Text Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'default' => GoMMC_Globals::get_main_font_color(),
                'selectors' => [
                    '{{WRAPPER}} .tpc-courses .course__content--meta > span' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_icon_color',
            [
                'label' => esc_html__('Icon Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'default' => GoMMC_Globals::get_primary_color(),
                'selectors' => [
                    '{{WRAPPER}} .tpc-courses .course__content--meta > span:before,
                    {{WRAPPER}} .tpc-courses .course__content--meta .course-wishlist:before' => 'color: {{VALUE}};',
                ],
            ]
        );        
        $this->add_control(
            'meta_cat_color',
            [
                'label' => esc_html__('Category Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'separator' => 'before',
                'dynamic' => ['active' => true],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .course__categories a, .course__categories a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_cat_bg_color',
            [
                'label' => esc_html__('Category Background Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .course__categories a, .course__categories a' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> PRICE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_price',
            [
                'label' => esc_html__('Price', 'gommc-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['hide_price' => '', 'hide_media' => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'price',
                'selector' => '{{WRAPPER}} .tpc-courses .course-price',
            ]
        );

        $this->add_responsive_control(
            'item_price_padding',
            [
                'label' => esc_html__('Price Padding', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .tpc-courses .course-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'item_price_margin',
            [
                'label' => esc_html__('Price Margin', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .tpc-courses .course-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'price_color',
            [
                'label' => esc_html__('Text Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .tpc-courses .course-price' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'price_bg_color',
            [
                'label' => esc_html__('Background Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'default' => GoMMC_Globals::get_primary_color(),
                'selectors' => [
                    '{{WRAPPER}} .tpc-courses .course-price' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }


    protected function render()
    {
        $atts = $this->get_settings_for_display();

          if (class_exists('SFWD_LMS')) {
                if ($atts['layout'] == '3') {
                   $courses = new TPC_Courses_LearnDash_3();
                   echo $courses->render($atts, $this);
                }
                elseif ($atts['layout'] == '2') {
                   $courses = new TPC_Courses_LearnDash_2();
                   echo $courses->render($atts, $this);
                } else {
                   $courses = new TPC_Courses_LearnDash();
                   echo $courses->render($atts, $this);
                }
          
            }
           else{
                echo '<span style="text-align:center; display: inherit; color:#072f60;">LearnDas LMS plugin is not activated <br> Note: Don\'t activate more than 1 LMS plugin on the same site</span>';
            }
    }

}
