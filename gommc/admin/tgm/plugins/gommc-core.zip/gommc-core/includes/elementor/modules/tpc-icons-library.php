<?php

namespace TPCAddons\Modules;

defined('ABSPATH') || exit;

use TPCAddons\Includes\TPC_Elementor_Helper;

/**
 * RT Elementor Custom Icon Control
 *
 *
 * @package gommc-core\includes\elementor
 * @author MMC 
 * @since 1.0.0
 */
class TPC_Icons_Library
{
    public function __construct()
    {
        add_filter('elementor/icons_manager/additional_tabs', [$this, 'extended_icons_library']);
    }

    public function extended_icons_library()
    {
        // global $wp_version;

        return [
            'tpc_icons' => [
                'name' => 'tpc_icons',
                'label' => esc_html__('GoMMC Icons Library', 'gommc-core'),
                // 'url' => get_template_directory_uri() . '/fonts/flaticon/flaticon.css',
                // 'enqueue' => [get_template_directory_uri() . '/fonts/flaticon/flaticon.css'],
                'prefix' => 'flaticon-',
                'displayPrefix' => 'flaticon',
                'labelIcon' => 'flaticon',
                // 'ver' => $wp_version,
                'icons' => TPC_Elementor_Helper::get_instance()->get_tpc_icons(),
                'native' => true,
            ]
        ];
    }
}
