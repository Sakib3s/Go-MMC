<?php
/*
 * This template can be overridden by copying it to yourtheme/gommc-core/elementor/widgets/tpc-hero-section.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\{
    Widget_Base,
    Controls_Manager,
    Group_Control_Border,
    Group_Control_Typography,
    Group_Control_Image_Size,
    Group_Control_Background,
    Group_Control_Box_Shadow
};
use TPCAddons\{
    GoMMC_Global_Variables as GoMMC_Globals,
};

class TPC_Hero_Section extends Widget_Base
{
    public function get_name()
    {
        return 'tpc-here-section-2';
    }

    public function get_title()
    {
        return esc_html__('Hero Section 2', 'gommc-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-slider-push';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }

    protected function register_controls() {
       
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'gommc-core'),
            ]
        );
        $this->add_control(
            'title',
            [
                'label'       => __('Title', 'gommc-core'),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __('Over <span>20,000+</span> online courses &amp; <span>1000+</span> Quizes from best instructor', 'gommc-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'description',
            [
                'label'     => __('Description', 'gommc-core'),
                'type'      => Controls_Manager::TEXTAREA,
                'default'   => __('World-class training and development programs', 'gommc-core'),
                'separator' =>'before',
            ]
        );
        $this->add_control(
            'show_animation',
            [
                'label' => esc_html__('Animation', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_shape_image',
            [
                'label' => __( 'Shape Images', 'gommc-core' ),
            ]
        );
        $this->add_control(
            'dot_shape',
            [
                'label' => __( 'Dot Shape', 'gommc-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => plugins_url('/gommc-core/includes/elementor/assets/img/dot_shape.png'),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'dot_shape',
                'default' => 'full',
                'separator' => 'none',
            ]
        );      
        $this->add_responsive_control(
            'dot_shape_width',
            [
                'label'     => __('Dot Shape Width', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 5,
                        'max' => 150,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-wrap .hero-2-shape-01 img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .gommc-hero-wrap .hero-2-shape-01 img' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );     
        $this->add_responsive_control(
            'dot_shape_position',
            [
                'label'     => __('Image Position', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => -50,
                        'max' => 490,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .hero-2-shape-01' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        ); 
        $this->add_control(
            'dot_shape_animation',
            [
                'label' => esc_html__('Animation', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => esc_html__('None', 'gommc-core'),
                    '1' => esc_html__('Animation 1', 'gommc-core'),
                    '2' => esc_html__('Animation 2', 'gommc-core'),
                    '3' => esc_html__('Animation 3', 'gommc-core'),
                    '4' => esc_html__('Animation 4', 'gommc-core'),
                    '5' => esc_html__('Animation 5', 'gommc-core'),
                ],
                'default' => 'none',
            ]
        );   


        $this->add_control(
            'shape_a',
            [
                'label' => __( 'Shape Top', 'gommc-core' ),
                'type' => Controls_Manager::MEDIA,
                'separator'  => 'before',
                'default' => [
                    'url' => plugins_url('/gommc-core/includes/elementor/assets/img/shape_a.png'),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'shape_a',
                'default' => 'full',
                'separator' => 'none',
            ]
        );      
        $this->add_responsive_control(
            'shape_a_width',
            [
                'label'     => __('Shape Width', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 10,
                        'max' => 400,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-wrap .hero-2-shape-02 img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .gommc-hero-wrap .hero-2-shape-02 img' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );     
        $this->add_responsive_control(
            'shape_a_position',
            [
                'label'     => __('Shape Position', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => -430,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .hero-2-shape-02' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        ); 

        $this->add_control(
            'shape_b',
            [
                'label' => __( 'Shape Bottom', 'gommc-core' ),
                'type' => Controls_Manager::MEDIA,
                'separator'  => 'before',
                'default' => [
                    'url' => plugins_url('/gommc-core/includes/elementor/assets/img/shape_b.png'),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'shape_b',
                'default' => 'full',
                'separator' => 'none',
            ]
        );      
        $this->add_responsive_control(
            'shape_b_width',
            [
                'label'     => __('Shape Width', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 10,
                        'max' => 400,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-wrap .hero-2-shape-03 img' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .gommc-hero-wrap .hero-2-shape-03 img' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );     
        $this->add_responsive_control(
            'shape_b_position',
            [
                'label'     => __('Shape Position', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => -430,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .hero-2-shape-03' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        ); 

    
        $this->end_controls_section();

        $this->start_controls_section(
            'section_btn',
            [
                'label' => __( 'Button', 'gommc-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'show_btn',
            [
                'label' => esc_html__('Button', 'gommc-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes'
            ]
        );
        $this->add_control(
            'btn_text',
            [
                'label'       => __('Button Text', 'gommc-core'),
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Explore All Courses',
                'label_block' => true,
            ]
        );
         $this->add_control(
            'link',
            [
                'label' => esc_html__('Button Link', 'gommc-core'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_attr__('https://your-link.com', 'gommc-core'),
                'default' => ['url' => '#'],
            ]
        );
        $this->add_control(
            'btn_icon',
            [
                'label' => __( 'Button Arrow', 'gommc-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => plugins_url('/gommc-core/includes/elementor/assets/img/btn_icon.png'),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'btn_icon',
                'default' => 'full',
                'separator' => 'none',
            ]
        );  
        $this->add_responsive_control(
            'btn_icon_position',
            [
                'label'     => __('Icon Position', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => -250,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-content .here-2-btn .here-2-btn-shape' => 'right: {{SIZE}}{{UNIT}};',
                ],
            ]
        ); 
        $this->end_controls_section();
 
         $this->start_controls_section(
            'content_style_section',
            [
                'label' => __('Style', 'gommc-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'section_background_a',
                'label' => __( 'Background A', 'gommc-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .gommc-hero-wrap',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'section_background_b',
                'label' => __( 'Background B', 'gommc-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .gommc-hero-wrap',
            ]
        );

         $this->add_responsive_control(
            'content_padding',
            [
                'label'      => __('Padding', 'gommc-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .gommc-hero-2-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'section_height',
            [
                'label'     => __('Section Height', 'gommc-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 100,
                        'max' => 1200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-content' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .gommc-hero-2-content' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );  
        $this->end_controls_section();

        $this->start_controls_section(
            'title_style_section',
            [
                'label' => __('Title', 'gommc-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'label'    => __('Title Typography', 'gommc-core'),
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
                'selector' => '{{WRAPPER}} .title',
            ]
        );
        $this->add_control(
            'title_color',
            [
                'label'     => __('Title Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}}  .title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'title_span_color',
            [
                'label'     => __('Span Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffe347',
                'selectors' => [
                    '{{WRAPPER}}  .title span' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // ==== Content Style Section ====

        $this->start_controls_section(
            'desc_style_section',
            [
                'label' => __('Description', 'gommc-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'desc_typography',
                'label'    => __('Typography', 'gommc-core'),
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_TEXT,
                ],
                'selector' => '{{WRAPPER}} .gommc-hero-2-content p',
            ]
        );
        $this->add_control(
            'desc_color',
            [
                'label'     => __('Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}}  .gommc-hero-2-content p' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'desc_padding',
            [
                'label'      => __('Padding', 'gommc-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors'  => [
                    '{{WRAPPER}} .gommc-hero-2-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> Button
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_btn',
            [
                'label' => esc_html__('Button', 'gommc-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'icon_typography',
                'selector' => '{{WRAPPER}} .gommc-hero-2-content .here-2-btn a.btn__a',
            ]
        );

        $this->start_controls_tabs('text_color_tabs');

        $this->start_controls_tab(
            'tab_text_idle',
            ['label' => esc_html__('Idle', 'gommc-core')]
        );

        $this->add_control(
            'text_color_idle',
            [
                'label' => esc_html__('Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-content .here-2-btn a.btn__a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_bg_color',
            [
                'label' => esc_html__('Background Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-content .here-2-btn a.btn__a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_text_hover',
            ['label' => esc_html__('Hover', 'gommc-core')]
        );

        $this->add_control(
            'btn_color_hover',
            [
                'label' => esc_html__('Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-content .here-2-btn a.btn__a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'btn_bg_color_hover',
            [
                'label' => esc_html__('background Color', 'gommc-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .gommc-hero-2-content .here-2-btn a.btn__a:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();
    } // End options

    protected function render( $instance = [] ) {

    $settings = $this->get_settings_for_display();

    ?>

    <div class="gommc-hero-wrap">
        <div class="here-2-bg"></div>
        <div class="hero-2-shape-01 tpc-animate-0<?php echo $settings['dot_shape_animation']; ?>">
            <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'dot_shape_size', 'dot_shape' );?>
       </div>
        <div class="hero-2-shape-02">
            <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'shape_a_size', 'shape_a' );?>
       </div>
        <div class="hero-2-shape-03">
            <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'shape_a_size', 'shape_b' );?>
       </div>

        <div class="gommc-container <?php echo ($settings['show_animation']) ? 'tpc_ani_wrap' : ''; ?>">
            <!-- Slider Content Start -->
            <div class="gommc-hero-2-content <?php echo ($settings['show_animation']) ? 'start_tpc_ani' : ''; ?>">

                 <?php if ($settings['title']): ?>
                    <h1 class="title"><?php echo $settings['title'] ?></h1>
                 <?php endif;?>

                 <?php if ($settings['description']): ?>
                    <p class="description"><?php echo $settings['description'] ?></p>
                 <?php endif;?>

                <?php if ($settings['show_btn']): ?>
                <div class="here-2-btn">
                    <a href="<?php echo esc_url($settings['link']['url']); ?>" class="btn__a"><?php echo $settings['btn_text'] ?></a>
                    <div class="here-2-btn-shape">
                        <?php echo Group_Control_Image_Size::get_attachment_image_html( $settings, 'btn_icon_size', 'btn_icon' );?>
                    </div>
                </div>
                <?php endif;?>

            </div>
            <!-- Slider Content End -->
        </div>
    </div>

<?php

    }

}

