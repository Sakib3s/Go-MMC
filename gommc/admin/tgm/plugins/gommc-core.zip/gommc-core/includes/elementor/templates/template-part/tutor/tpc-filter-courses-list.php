<?php

if (function_exists('tutor')) {

    $_   = $this->get_settings_for_display();

?>

<div class="col-lg-12">
  <div class="gommc-course gommc-course-list">
    <div class="row">

        <?php if ( has_post_thumbnail() && $_['show_media']) : ?>
        <div class="col-md-4">

            <?php 

             if (class_exists('RWMB_Loader') && $_['hover_popup_type'] == 'show_video_popup') {
                $ld_intro_video = rwmb_meta('ld_intro_video');

                echo '<div class="tpc-video_popup with_image">';
                echo '<div class="videobox_content">';
            } 

            if ($_['show_media']): ?>
            <div class="course__media">

                <?php if ( has_post_thumbnail() ):?>
                  <a class="course__media-link" href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail($_['image_size']);?>
                  </a>
                 <?php endif; ?>

                <!-- Start video -->
                <?php       
                    $video = maybe_unserialize( get_post_meta( get_the_ID(), '_video', true ) );
                    $videoSource    = tutor_utils()->avalue_dot( 'source', $video );

                    if ($video["source_youtube"] && $videoSource == 'youtube') {
                        $tutor_intro_video =    $video["source_youtube"];
                    }
                    elseif($video["source_vimeo"] && $videoSource == 'vimeo'){
                        $tutor_intro_video =    $video["source_vimeo"];
                    }
                    elseif($video["source_external_url"] && $videoSource == 'external_url'){
                        $tutor_intro_video =    $video["source_external_url"];
                    }
                    // elseif($video["source_video_id"] && $videoSource == 'html5'){
                    //  $tutor_intro_video =    $video["source_video_id"];
                    // }
                    // elseif($video["source_embedded"] && $videoSource == 'embedded'){
                    //  $tutor_intro_video =    $video["source_embedded"];
                    // }
                    else{
                        $tutor_intro_video =    '';
                    }

             
            if ( $_['hover_popup_type'] == 'show_video_popup' && !empty($tutor_intro_video)) { ?>

                <div class="videobox_link_wrapper">

                    <div class="videobox_link popup-youtube popup-vimeo" data-lity="" href="<?php echo esc_url( $tutor_intro_video ); ?>">
                        <svg class="videobox_icon" width="33%" height="33%" viewBox="0 0 232 232"><path d="M203,99L49,2.3c-4.5-2.7-10.2-2.2-14.5-2.2 c-17.1,0-17,13-17,16.6v199c0,2.8-0.07,16.6,17,16.6c4.3,0,10,0.4,14.5-2.2 l154-97c12.7-7.5,10.5-16.5,10.5-16.5S216,107,204,100z"></path>
                        </svg>
                    </div>
                </div>
            <?php     
            } // End video popup ?>

            </div>
        <?php 
        
            endif; // End show_media

            if (class_exists('RWMB_Loader') && $_['hover_popup_type'] == 'show_video_popup') {

            echo '</div>';
            echo '</div>';

             } // End video popup

         ?>
        </div>
        <?php endif; ?>

        <div class="col-md-<?php if($_['show_media']) : echo '8'; else : echo '12'; endif; ?>">
         <div class="course-content">

            <?php if ($_['show_cat'] || $_['show_price'] ): ?>

              <div class="course__top-meta">
                   <?php if ($_['show_cat'] ): ?>
                      <div class="course__categories ">
                          <?php echo get_the_term_list(get_the_ID(), 'course-category'); ?>
                      </div>
                   <?php endif; ?>
                   
                   <?php if ($_['show_price']): ?>
                        <div class="price">
                          <?php get_template_part('templates/tutor/price_within_button_2'); ?>
                        </div>
                   <?php endif; ?>
              </div>
            <?php endif; ?>

            <?php
              the_title(sprintf('<h4 class="course__title"><a href="%s" rel="bookmark">', esc_url(get_permalink())), '</a></h4>');
              do_action('learn_press_after_the_title');
            ?>
            <div class="course__content--meta"> 
                <div class="course__meta-left">
                <?php if ($_['show_lesson']):  ?>
                    <span class="course-lessons is__icon">
                        <i class="flaticon-book-1"></i>
                        <?php
                            $tutor_lesson_count = tutor_utils()->get_lesson_count_by_course(get_the_ID());
                            if($tutor_lesson_count) {
                                echo "<span> $tutor_lesson_count";
                                esc_html_e(' Lessons', 'gommc-core');
                                echo "</span>";
                            }
                        ?>  
                    </span>
                <?php endif; ?>
                <?php if ($_['show_duration']): ?>

                    <?php 
                         $course_duration = get_tutor_course_duration_context();
                    if (!empty($course_duration)): ?>
                        <span class="course-duration is__icon">
                            <i class="flaticon-wall-clock"></i> 
                            <?php echo wp_kses_post( $course_duration ); ?>  
                        </span>
                    <?php endif; ?>

                <?php  endif; ?>
             <?php if($_['show_review']): ?>

                    <div class="course__review">
                        <?php
                            $course_rating = tutor_utils()->get_course_rating();
                            tutor_utils()->star_rating_generator($course_rating->rating_avg);
                        ?>
                        <span class="tutor-single-rating-count">
                            <?php
                                echo esc_attr( $course_rating->rating_avg );
                                echo '<i>('.$course_rating->rating_count.')</i>';
                            ?>
                        </span>
                    </div>                         
        
                 <?php endif; ?>
                </div>
            </div>

            <?php the_excerpt();?>

              </div>
            </div>
          </div> <!--  row  -->
        </div> <!-- single course -->
      </div>
<?php } //if class exist tutor ?>