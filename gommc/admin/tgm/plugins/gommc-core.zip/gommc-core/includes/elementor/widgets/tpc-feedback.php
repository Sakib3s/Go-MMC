<?php
/*
 * This template can be overridden by copying it to yourtheme/gommc-core/elementor/widgets/tpc-feedback.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\{Widget_Base, Controls_Manager, Control_Media};
use Elementor\{Group_Control_Border, Group_Control_Box_Shadow, Group_Control_Background, Group_Control_Image_Size, Group_Control_Typography};
use Elementor\{Repeater, Utils};
use TPCAddons\GoMMC_Global_Variables as GoMMC_Globals;
use TPCAddons\Includes\{TPC_Feedback_Settings, TPC_Elementor_Helper};

class TPC_Feedback extends Widget_Base
{
    public function get_name() {
        return 'tpc-testimonial';
    }

    public function get_title() {
        return esc_html__('Testimonials', 'gommc-core');
    }

    public function get_icon() {
        return 'tpc-icon eicon-testimonial';
    }

    public function get_script_depends() {
        return [ 'slick' ];
    }

    public function get_categories() {
        return [ 'tpc-extensions' ];
    }

    protected function register_controls()
    {
        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_general',
            [ 'label' => esc_html__('General', 'gommc-core') ]
        );

        $this->add_control(
            'testi_style',
            [
                'label' => __( 'Style', 'gommc-core' ),
                'type' => Controls_Manager::SELECT,
                'default' => '1',
                'options' => [
                    '1' => esc_html__('1 / One', 'gommc-core'),
                    '2' => esc_html__('2 / Two', 'gommc-core'),
                    '3' => esc_html__('3 / Three', 'gommc-core'),
                    '4' => esc_html__('4 / Four', 'gommc-core'),
                    '5' => esc_html__('5 / Five', 'gommc-core'),
                    '6' => esc_html__('6 / Six', 'gommc-core'),
                ],
            ]
        );
        $this->add_control(
            'item_grid',
            [
                'label' => esc_html__('Grid Columns Amount', 'gommc-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('1 / One', 'gommc-core'),
                    '2' => esc_html__('2 / Two', 'gommc-core'),
                    '3' => esc_html__('3 / Three', 'gommc-core'),
                    '4' => esc_html__('4 / Four', 'gommc-core'),
                    '5' => esc_html__('5 / Five', 'gommc-core'),
                    '6' => esc_html__('6 / Six', 'gommc-core'),
                ],
                'default' => '1',
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'thumbnail',
            [
                'label' => esc_html__('Thumbnail', 'gommc-core'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [ 'url' => Utils::get_placeholder_image_src() ],
            ]
        );
        $repeater->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'client_imagesize',
                'default' => 'large',
                'separator' => 'none',
            ]
        );

        $repeater->add_control(
            'client_name',
            [
                'label'   => __( 'Name', 'gommc-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Johan Doe','gommc-core'),

            ]    
        );
        $repeater->add_control(
            'client_designation',
            [
                'label'   => __( 'Designation', 'gommc-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Managing Director','gommc-core'),
            ]
        );
        $repeater->add_control(
            'client_say',
            [
                'label'   => __( 'Client Say', 'gommc-core' ),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => __('I believe in lifelong learning and they are a great place to learn from experts. I have learned a lot and recommend it','gommc-core'),
            ]
        );
        $repeater->add_control(
            'client_link',
            [
                'label' => esc_html__('Add Link', 'gommc-core'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'list',
            [
                'label' => esc_html__('Items', 'gommc-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                    'default' => [

                        [
                            'client_name'           => __('James Smith','gommc-core'),
                            'client_designation'    => __( 'CFO Apple Corp','gommc-core' ),
                            'client_say'            => __( 'I believe in lifelong learning and they are a great place to learn from experts. I have learned a lot and recommend it', 'gommc-core' ),
                        ],

                        [
                            'client_name'           => __('Mark Donald','gommc-core'),
                            'client_designation'    => __( 'Manager','gommc-core' ),
                            'client_say'            => __( 'Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod tempor incididunt labore Lorem ipsum', 'gommc-core' ),
                        ],

                        [
                            'client_name'           => __('John Dowson','gommc-core'),
                            'client_designation'    => __( 'Developer','gommc-core' ),
                            'client_say'            => __( 'I believe in lifelong learning and they are a great place to learn from experts. I have learned a lot and recommend it', 'gommc-core' ),
                        ],
                    ],
                    'title_field' => '{{{ client_name }}}',
            ]
        );


        $this->end_controls_section();


       
        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> CAROUSEL OPTIONS
        /*-----------------------------------------------------------------------------------*/
            $this->start_controls_section(
                'tpc_carousel_section',
                ['label' => esc_html__('Carousel Options', 'gommc-core')]
            );

            $this->add_control(
                'autoplay',
                [
                    'label' => esc_html__('Autoplay', 'gommc-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'gommc-core'),
                    'label_off' => esc_html__('Off', 'gommc-core'),
                ]
            );

            $this->add_control(
                'autoplay_speed',
                [
                    'label' => esc_html__('Autoplay Speed', 'gommc-core'),
                    'type' => Controls_Manager::NUMBER,
                    'min' => 1,
                    'step' => 1,
                    'default' => '5000',
                    'condition' => [
                        'autoplay' => 'yes',
                    ],
                ]
            );
            $this->add_control(
                'infinite',
                [
                    'label' => esc_html__('Infinite Loop Sliding', 'gommc-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'gommc-core'),
                    'label_off' => esc_html__('Off', 'gommc-core'),
                    'return_value' => 'yes',
                    'default' => 'yes'
                ]
            );
            $this->add_control(
                'coverflow_effect',
                [
                    'label' => esc_html__('Coverflow Effect', 'gommc-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'gommc-core'),
                    'label_off' => esc_html__('Off', 'gommc-core'),
                ]
            );

            $this->add_control(
                'tablet_item',
                [
                    'label' => esc_html__('Tablet Device Item', 'gommc-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '2',
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'tablet_width',
                [
                    'label' => esc_html__('Tablet Device Width', 'gommc-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '768',
                ]
            );
            $this->add_control(
                'mobile_item',
                [
                    'label' => esc_html__('Mobile Device Item', 'gommc-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '1',
                    'separator' => 'before',
                ]
            );      
            $this->add_control(
                'mobile_width',
                [
                    'label' => esc_html__('Mobile Device Width', 'gommc-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '480',
                ]
            );    
            $this->add_responsive_control(
                'space_between',
                [
                    'label' => esc_html__('Space Between', 'gommc-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '20',
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'use_prev_next',
                [
                    'label' => esc_html__('Add Prev/Next buttons', 'gommc-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'gommc-core'),
                    'label_off' => esc_html__('Off', 'gommc-core'),
                    'separator' => 'before',
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );
         
            $this->add_control(
                'use_pagination',
                [
                    'label' => esc_html__('Add Pagination', 'gommc-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'gommc-core'),
                    'label_off' => esc_html__('Off', 'gommc-core'),
                    'separator' => 'before',
                    'return_value' => 'yes',
                    'default' => 'yes',
                    ]
            );
          $this->add_control(
                'pag_type',
                [
                    'label' => esc_html__('Pagination Type', 'gommc-core'),
                    'type' => 'tpc-radio-image',
                    'condition' => [
                        'use_pagination' => 'yes',
                        'testi_style' => ['1', '2', '3']
                    ],
                    'options' => [
                        'circle' => [
                            'title' => esc_html__('Circle', 'gommc-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_circle.png',
                        ],
                        'circle_border' => [
                            'title' => esc_html__('Empty Circle', 'gommc-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_circle_border.png',
                        ],
                        'square' => [
                            'title' => esc_html__('Square', 'gommc-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_square.png',
                        ],
                        'square_border' => [
                            'title' => esc_html__('Empty Square', 'gommc-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_square_border.png',
                        ],
                        'line' => [
                            'title' => esc_html__('Line', 'gommc-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_line.png',
                        ],
                        'line_circle' => [
                            'title' => esc_html__('Line - Circle', 'gommc-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_line_circle.png',
                        ],
                    ],
                    'default' => 'circle',
                ]
            );
            $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLES -> ITEMS
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_items',
            [
                'label' => esc_html__('Items', 'gommc-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'image_margin',
            [
                'label' => esc_html__('Image Margin', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .clients_image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_padding',
            [
                'label' => esc_html__('Image Padding', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .clients_image' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'image_border_radius',
            [
                'label' => esc_html__('Image Border Radius', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .clients_image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs(
            'tabs_items',
            [ 'separator' => 'before' ]
        );

        $this->start_controls_tab(
            'tab_item_idle',
            [ 'label' => esc_html__('Idle', 'gommc-core') ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_idle',
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .clients_image',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_idle',
                'selector' => '{{WRAPPER}} .clients_image',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_item_hover',
            [ 'label' => esc_html__('Hover', 'gommc-core') ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_hover',
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .clients_image:hover',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_hover',
                'selector' => '{{WRAPPER}} .clients_image:hover',
            ]
        );

        $this->add_control(
            'item_transition',
            [
                'label' => esc_html__('Transition Duration', 'gommc-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 's' ],
                'range' => [
                    's' => [ 'min' => 0, 'max' => 2, 'step' => 0.1 ],
                ],
                'default' => [ 'size' => 0.4, 'unit' => 's' ],
                'selectors' => [
                    '{{WRAPPER}} .clients_image' => 'transition: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'image_height',
            [
                'label'      => __('Image Height', 'gommc-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 150,
                        'max'  => 800,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .feedback-img-wrapper .feedback-image' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .feedback-img-wrapper .feedback-image img' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'item_padding',
            [
                'label' => esc_html__('Item Padding', 'gommc-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .feedback-content-wrapper .feedback-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'item_height',
            [
                'label'      => __('Item Height', 'gommc-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 150,
                        'max'  => 800,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .feedback-content-wrapper .feedback-content' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLES -> IMAGES
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_images',
            [
                'label' => esc_html__('Images', 'gommc-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs( 'tabs_images' );

        $this->start_controls_tab(
            'tab_image_idle',
            [ 'label' => esc_html__('Idle', 'gommc-core') ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_idle',
                'selector' => '{{WRAPPER}} .image_wrapper > img, .feedback-image',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'image_idle',
                'selector' => '{{WRAPPER}} .image_wrapper > img, .feedback-image',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_image_hover',
            [ 'label' => esc_html__('Hover', 'gommc-core') ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_hover',
                'selector' => '{{WRAPPER}} .image_wrapper:hover > img',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'image_hover',
                'selector' => '{{WRAPPER}} .image_wrapper:hover > img',
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();



        // Style Testimonial area tab section
        $this->start_controls_section(
            'testi_style_area',
            [
                'label' => __( 'Style', 'gommc-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'feedback_height',
            [
                'label' => __( 'Height', 'gommc-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'default' => [
                    'size' => '',
                ],
                'range' => [
                    'px' => [
                        'min' => 200,
                        'max' => 800,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-feedback-style-1 .feedback-single' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .gommc-feedback-style-1 .feedback-img-wrapper .feedback-image' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .gommc-feedback-style-1 .feedback-img-wrapper .feedback-image img' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .gommc-feedback-style-1 .feedback-content-wrapper .feedback-content' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'testi_style' => '1',
                ],
            ]
        );
        $this->add_responsive_control(
            'feedback_position_x',
            [
                'label' => __( 'Position X', 'gommc-core' ),
                'description' => __('Keep blank for the default value', 'gommc-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'default' => [
                    'size' => '',
                ],
                'range' => [
                    'px' => [
                        'min' => -295,
                        'max' => 295,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-feedback-style-2 .feedback-content-wrapper' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );        
        $this->add_responsive_control(
            'feedback_position_y',
            [
                'label' => __( 'Position Y', 'gommc-core' ),
                'description' => __('Keep blank for the default value', 'gommc-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'default' => [
                    'size' => '',
                ],
                'range' => [
                    'px' => [
                        'min' => -195,
                        'max' => 195,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-feedback-style-2 .feedback-content-wrapper' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'bg_color',
            [
                'label' => __( 'Background', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .feedback-content-wrapper .feedback-content' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'bg_color_style_1',
            [
                'label' => __( 'Background A', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
            ]
        );
        $this->add_control(
            'bg_color_style_2',
            [
                'label' => __( 'Background B', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
            ]
        );
        $this->add_responsive_control(
            'gommc_feedback_name_align',
            [
                'label' => __( 'Alignment', 'gommc-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'gommc-core' ),
                        'icon' => 'fa fa-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'gommc-core' ),
                        'icon' => 'fa fa-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'gommc-core' ),
                        'icon' => 'fa fa-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-feedback-style-1 .feedback-content' => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .gommc-feedback-style-2 .feedback-content' => 'text-align: {{VALUE}};',
                ],
                'default' => 'left',
                'separator' =>'before',
            ]
        );
        $this->add_responsive_control(
            'gommc_feedback_section_padding',
            [
                'label' => __( 'Padding', 'gommc-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .gommc-feedback-style-1 .feedback-content-wrapper .feedback-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .gommc-feedback-style-2 .feedback-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .gommc-feedback-style-3 .feedback-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',

                ]
            ]
        );
        $this->add_responsive_control(
            'gommc_feedback_image_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'gommc-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .gommc-feedback-style-1 .feedback-single' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                    '{{WRAPPER}} .gommc-feedback-style-2 .feedback-content-wrapper' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
                'condition' => [
                    'testi_style' => '1',
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'testi_quote_style',
            [
                'label'     => __( 'Quote', 'gommc-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'quote_icon_color',
            [
                'label' => __( 'Icon Color', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .gommc-feedback-style-3 .flaticon-quote-left' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section(); // Style Testimonial image style end

        $this->start_controls_section(
            'gommc_feedback_name_style',
            [
                'label'     => __( 'Name', 'gommc-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'feedback_name_color',
            [
                'label' => __( 'Color', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .gommc-feedback-style-1 .feedback-content-wrapper .feedback-name' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .gommc-feedback-style-2 .feedback-content-wrapper .feedback-name' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .gommc-feedback-style-3 .feedback-content-wrapper .feedback-name' => 'color: {{VALUE}};',
                ],
            ]
        );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'gommc_feedback_name_typography',
                    'global' => [
                        'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                    ],
                    'selector' => '{{WRAPPER}} .gommc-feedback-style-1 .feedback-content-wrapper .feedback-name, .gommc-feedback-style-2 .feedback-content-wrapper .feedback-name, .gommc-feedback-style-3 .feedback-content-wrapper .feedback-name',
                ]
            );

            $this->add_responsive_control(
                'gommc_feedback_name_padding',
                [
                    'label' => __( 'Padding', 'gommc-core' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .gommc-feedback-style-1 .feedback-content-wrapper .feedback-name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .gommc-feedback-style-2 .feedback-content-wrapper .feedback-name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .gommc-feedback-style-3 .feedback-content-wrapper .feedback-name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

        $this->end_controls_section(); // Style Testimonial name style end

        // Style Testimonial designation style start
        $this->start_controls_section(
            'gommc_feedback_designation_style',
            [
                'label'     => __( 'Degree', 'gommc-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );
            
            $this->add_control(
                'gommc_feedback_degree_color',
                [
                    'label' => __( 'Color', 'gommc-core' ),
                    'type' => Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .gommc-feedback-style-1 .feedback-content-wrapper .feedback-degree' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .gommc-feedback-style-2 .feedback-content-wrapper .feedback-degree' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .gommc-feedback-style-3 .feedback-content-wrapper .feedback-degree' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'gommc_feedback_degree_typography',
                    'global' => [
                        'default' => Global_Typography::TYPOGRAPHY_TEXT,
                    ],
                    'selector' => '{{WRAPPER}} .gommc-feedback-style-1 .feedback-content-wrapper .feedback-degree, .gommc-feedback-style-2 .feedback-content-wrapper .feedback-degree, .gommc-feedback-style-3 .feedback-content-wrapper .feedback-degree',
                ]
            );

            $this->add_responsive_control(
                'gommc_feedback_degree_padding',
                [
                    'label' => __( 'Padding', 'gommc-core' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .gommc-feedback-style-1 .feedback-content-wrapper .feedback-degree' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .gommc-feedback-style-2 .feedback-content-wrapper .feedback-degree' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .gommc-feedback-style-3 .feedback-content-wrapper .feedback-degree' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

        $this->end_controls_section(); // Style Testimonial designation style end


        // Style Testimonial designation style start
        $this->start_controls_section(
            'gommc_feedback_clientsay_style',
            [
                'label'     => __( 'Client say', 'gommc-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );
          
        $this->add_control(
            'gommc_feedback_clientsay_color',
            [
                'label' => __( 'Color', 'gommc-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .gommc-feedback-style-1 .feedback-content-wrapper .feedback-text' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .gommc-feedback-style-2 .feedback-content-wrapper .feedback-text' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .gommc-feedback-style-3 .feedback-content-wrapper .feedback-text' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .gommc-feedback-style-6 .feedback-text' => 'color: {{VALUE}};',
                ],
            ]
        );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'gommc_feedback_clientsay_typography',
                    'global' => [
                        'default' => Global_Typography::TYPOGRAPHY_TEXT,
                    ],
                    'selector' => '{{WRAPPER}} .gommc-feedback-style-1 .feedback-text, .gommc-feedback-style-2 .feedback-text, .gommc-feedback-style-3 .feedback-content-wrapper .feedback-text, .gommc-dubble-feedback .single-feedback-content p',
                ]
            );

            $this->add_responsive_control(
                'gommc_feedback_clientsay_padding',
                [
                    'label' => __( 'Padding', 'gommc-core' ),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%', 'em' ],
                    'selectors' => [
                        '{{WRAPPER}} .gommc-feedback-style-1 .feedback-content-wrapper .feedback-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .gommc-feedback-style-2 .feedback-content-wrapper .feedback-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .gommc-feedback-style-4 .swiper-slide.single-feedback-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        '{{WRAPPER}} .gommc-feedback-style-5 .swiper-slide.single-feedback-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' =>'before',
                ]
            );

        $this->end_controls_section(); // Style Testimonial designation style end



        // Style arrow style start
        $this->start_controls_section(
            'cat_carousel_arrow_style',
            [
                'label'     => __('Prev/Next buttons', 'gommc-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'use_prev_next' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'cat_carousel_arrow_color',
            [
                'label'     => __('Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#5A5A5A',
                'selectors' => [
                    '{{WRAPPER}} .gommc__carousel .swiper-button-next:after, .gommc__carousel .swiper-button-prev:after' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_arrow_fontsize',
            [
                'label'      => __('Arrow Size', 'gommc-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 50,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .gommc__carousel .swiper-button-next:after, .gommc__carousel .swiper-button-prev:after' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'arrow_bg_color',
            [
                'label'     => __('Background Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gommc__carousel .swiper-button-next, .gommc__carousel .swiper-button-prev' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'cat_carousel_arrow_border',
                'label'    => __('Border', 'gommc-core'),
                'selector' => '{{WRAPPER}} .gommc__carousel .swiper-button-next, .gommc__carousel .swiper-button-prev',
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_arrow_border_radius',
            [
                'label'     => __('Border Radius', 'gommc-core'),
                'type'      => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .gommc__carousel .swiper-button-next, .gommc__carousel .swiper-button-prev' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'arrow_box_shadow',
                'selector' => '{{WRAPPER}} .gommc__carousel .swiper-button-next, .gommc__carousel .swiper-button-prev',
            ]
        );


        $this->end_controls_section(); // Style cat box arrow style end

        // Style cat box Dots style start
        $this->start_controls_section(
            'cat_carousel_dots_style',
            [
                'label'     => __('Pagination', 'gommc-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'use_pagination' => 'yes',
                ],
            ]
        );

        $this->start_controls_tabs('cat_carousel_dots_style_tabs');

        // Normal tab Start
        $this->start_controls_tab(
            'cat_carousel_dots_style_normal_tab',
            [
                'label' => __('Normal', 'gommc-core'),
            ]
        );

        $this->add_control(
            'dot_color',
            [
                'label'     => __('Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gommc__carousel .swiper-pagination .swiper-pagination-bullet' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .gommc__carousel.pagination_square_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .gommc__carousel.pagination_circle_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet:before' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_dots_height',
            [
                'label'      => __('Size', 'gommc-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 30,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .gommc__carousel .swiper-pagination .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'pag_type' => 'circle',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_dots_space',
            [
                'label'      => __('Space Between', 'gommc-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 30,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .gommc__carousel .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'cat_carousel_dots_position',
            [
                'label'      => __('Position X', 'gommc-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => -300,
                        'max'  => 300,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => -60,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .gommc__carousel .swiper-pagination' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'cat_carousel_dots_position_y',
            [
                'label'      => __('Position Y', 'gommc-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => -700,
                        'max'  => 700,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .gommc__carousel .swiper-pagination' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab(); // Normal tab end

        // Hover tab Start
        $this->start_controls_tab(
            'cat_carousel_dots_style_hover_tab',
            [
                'label' => __('Active', 'gommc-core'),
            ]
        );
        $this->add_control(
            'dot_hover_color',
            [
                'label'     => __('Active Color', 'gommc-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .gommc__carousel .swiper-pagination .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .gommc__carousel.pagination_square_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .gommc__carousel.pagination_square_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .gommc__carousel.pagination_circle_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .gommc__carousel.pagination_circle_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab(); // Hover tab end

        $this->end_controls_tabs();

        $this->end_controls_section(); // Style cat box dots style end

    }

    protected function render()
    {
        $id = $this->get_id();
        $settings = $this->get_settings_for_display();
?>
<?php if ($settings['testi_style'] == '1' || $settings['testi_style'] == '2' || $settings['testi_style'] == '3' || $settings['testi_style'] == '6'): ?>
 <div class="gommc__carousel pagination_<?php echo esc_attr($settings['pag_type']) ?> gommc-feedback-style-<?php echo $settings['testi_style']; ?>">   
    <div class="lmsmaer_feedback_id<?php echo $id; ?>">
        <div class="swiper-wrapper">
      <?php      
            foreach ($settings['list'] as $index => $item) {
           ?>
           <?php if ($settings['testi_style'] == '1'): ?>
                <div class="swiper-slide">
                    <!-- Testimonial Start -->
                    <div class="testimonial-content">
                        <div class="quotes-icon-wrap">
                            
                        <span><svg 
                         xmlns="http://www.w3.org/2000/svg"
                         xmlns:xlink="http://www.w3.org/1999/xlink"
                         width="42px" height="37px">
                        <path fill-rule="evenodd"  fill="rgb(255, 255, 255)"
                         d="M42.000,26.804 C42.000,32.435 37.524,36.999 32.002,36.999 C26.480,36.999 22.004,32.435 22.004,26.804 C22.004,26.799 22.005,26.796 22.005,26.791 C21.993,26.493 21.405,10.252 31.749,2.508 C41.077,-4.476 31.014,4.009 28.764,17.167 C29.781,16.811 30.867,16.610 32.002,16.610 C37.524,16.610 42.000,21.174 42.000,26.804 ZM10.007,36.999 C4.485,36.999 0.009,32.435 0.009,26.804 C0.009,26.799 0.010,26.796 0.010,26.791 C-0.002,26.493 -0.590,10.252 9.753,2.508 C19.081,-4.476 9.019,4.009 6.769,17.167 C7.786,16.811 8.872,16.610 10.007,16.610 C15.529,16.610 20.005,21.174 20.005,26.804 C20.005,32.435 15.529,36.999 10.007,36.999 Z"/>
                        </svg></span>

                        </div>
                            <?php                             
                                if( !empty($item['client_say']) ){
                                    echo '<p class="feedback-text">'.esc_html__( $item['client_say'], 'gommc-core' ).'</p>';
                                }
                            ?>
                        <div class="name-degree">
                            <?php                             
                                if( !empty($item['client_name']) ){
                                    echo '<p class="feedback-name">'.esc_html__( $item['client_name'], 'gommc-core' ).'</p>';
                                }
                            ?>
                            <?php                             
                                if( !empty($item['client_designation']) ){
                                    echo '<p class="feedback-degree">'.esc_html__( $item['client_designation'], 'gommc-core' ).'</p>';
                                }
                            ?>
                        </div>
                    </div>
                    <!-- Testimonial End -->
                </div>

            <?php elseif ($settings['testi_style'] == '2'): ?>
                <div class="swiper-slide">
                    <!-- Testimonial Start -->
                    <div class="testimonial-content">
                        <div class="quotes-icon-wrap">
                            
                        <span><svg 
                         xmlns="http://www.w3.org/2000/svg"
                         xmlns:xlink="http://www.w3.org/1999/xlink"
                         width="42px" height="37px">
                        <path fill-rule="evenodd"  fill="rgb(255, 255, 255)"
                         d="M42.000,26.804 C42.000,32.435 37.524,36.999 32.002,36.999 C26.480,36.999 22.004,32.435 22.004,26.804 C22.004,26.799 22.005,26.796 22.005,26.791 C21.993,26.493 21.405,10.252 31.749,2.508 C41.077,-4.476 31.014,4.009 28.764,17.167 C29.781,16.811 30.867,16.610 32.002,16.610 C37.524,16.610 42.000,21.174 42.000,26.804 ZM10.007,36.999 C4.485,36.999 0.009,32.435 0.009,26.804 C0.009,26.799 0.010,26.796 0.010,26.791 C-0.002,26.493 -0.590,10.252 9.753,2.508 C19.081,-4.476 9.019,4.009 6.769,17.167 C7.786,16.811 8.872,16.610 10.007,16.610 C15.529,16.610 20.005,21.174 20.005,26.804 C20.005,32.435 15.529,36.999 10.007,36.999 Z"/>
                        </svg></span>
                        </div>
                            <?php                             
                                if( !empty($item['client_say']) ){
                                    echo '<p class="feedback-text">'.esc_html__( $item['client_say'], 'gommc-core' ).'</p>';
                                }
                            ?>

                        <div class="name-degree">
                           <?php
                                if( !empty($item['thumbnail']['url']) ){
                                    echo '<div class="feedback-image">'.Group_Control_Image_Size::get_attachment_image_html( $item, 'client_imagesize', 'thumbnail' ).'</div>';
                                } 
                            ?>
                            <?php                             
                                if( !empty($item['client_name']) ){
                                    echo '<p class="feedback-name">'.esc_html__( $item['client_name'], 'gommc-core' ).'</p>';
                                }
                            ?>
                            <?php                             
                                if( !empty($item['client_designation']) ){
                                    echo '<p class="feedback-degree">'.esc_html__( $item['client_designation'], 'gommc-core' ).'</p>';
                                }
                            ?>
                        </div>
                    </div>
                    <!-- Testimonial End -->
                </div>
            <?php elseif ($settings['testi_style'] == '6'): ?>
                <div class="swiper-slide">
                    <!-- Testimonial Start -->
                    <div class="testimonial-content">

                            <?php
                                if( !empty($item['thumbnail']['url']) ){
                                    echo '<div class="feedback-image">'.Group_Control_Image_Size::get_attachment_image_html( $item, 'client_imagesize', 'thumbnail' ).'</div>';
                                } 
                            ?>
                        <div class="quotes-icon-wrap">
                            
                        <span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="240" height="211" viewBox="0 0 240 211">
                              <image id="Forma_1" data-name="Forma 1" width="240" height="211" xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPAAAADTCAYAAAC/bZ4KAAASaElEQVR4nO2dh3IbORKGm0mUJVGSZdmWg7zefFf32PtKV5f2wvrWQVa2lSlSvILd8I05gZOARvi/KpZcQ8oip/k3Go1GozP7hUA5OkT0gIgeElGPiP6M+xYFAyJ6RERbRHRKRL+79KH7qSsgi00iek5EQ37uJuM1ICy6RPSYiHb434qZa58QAi5Ged8XLOAkp4W/BXxnRETfJBy25sS1zwUB57PNo25v7hXKC+/n/hbwmS7b/GHGZ7jgh1NAwGkG7H03Us98Rnnhceoq8J1VIvo2Y9TVvE9dcQAI+Gs2Wbx590WNvu9SV4HPdHie+4T/ncWli+EzFXxRY6ModEpyTETXqavAV4Y86q4ueP9vUlccAQImWmEjLqee+RqMvmGRl+OY5yM/nCR2AT9iI+aFTkn2sXwUBD2eJt0v+WGcHX0pYgH32Yjzy0N5TDD6BoGKtr4rSFTNc8zzX2eJUcBrHDIvpZ7JR4l3mvss8AFVlPGsZLRFPGV6m7rqGLEJWGUbn1YwInHYfJC6CnxBfcdfFiwL5nHgw5QpFgEP2IjrqWcW89rFEjpQihFHW4PUM8VMfZkyxSDgdRZvVSMqzlE26SVl1naLeMd5D+cJXcBP2Yh1cWrnCShFnxNVo5q368anUtlQBdzj0KnqvCfJkesZSJBilcVbJUE5j1dTphAFfI+Ivq+wVJDFnQ8ZSPAVqjBjN7H1rw5nvk2ZQhPwFq/vNjEiceE6Niz4QYeFu6gMtgyvffvwIQm46XxXc0tEe6mrwEV6HG3Vne8m8XLKFIKAO7zpfjv1TD3ecggN3EbNc3/gKVNTvJ0y+S7gLictmiSrklwR0WHqKnANJdofay4NZuHtlMlnAQ/YA6+knqmPd3OgCBlx2LxoF1FZJq5u1i+DrwJW4dNPDTPN85y5vG0MfGKDxVunOCMPr+vcfRSwCfESRl/n2eTpUpvi9b7Ovelyi21Midf5bWORY0K8xHt9va5z92kENiXemeubtiPnPlfVtS3eC1f7XFXBFwEr8f7csEQujwMUbTjLpiHxUihO24cQusfZZhPivUPRhrOMDIXNxMnKs9RVD3FdwF1e72tjsT6Lfa68Am6xyk7bhHgppDp3lwXcKdnysy5TjL5OMmTxmvpunrp4wkJdXBZwlaZzddhDnyvn6HPEZTI3E9QuM1cF/JiP8jTFLc43co5OxY6RdTjictlgcFHAG9w90CR72LDgHLst7SrKI8jG/K4JeNngsoHmFhsWnONhS/t5izgOsTG/SwLuc/KirSL1PN5j9HWKEY++Jgn2WByXBFx0tGNb3KLHs1MsGVzrTXIU6rE4rgh4p2bP5qpg9HUHvUxouhpwFvJyoQsCXuN2OKaZYPR1iqdse9MEOffVSAu4byFppcHo6w7rHHXZIOhiHWkBvzRU4zzPFOu+zjBgp22Dk9APZJcU8MMWe1kt4gCjrzO8tLgLzttWOWWREvCQD9a2wR1GX2fYtpSsJN5tFEzNcx5SAm6j+XpZjrDjyAmWLDptimWjioSAHxkumUsyiyGM8oSXFop0NJexNCi0LeChhTrnJKchLyF4hE2nTTE5bdsCthk6E/b7OsGSpXV+zU0Iva7KYlNMW5a98Bk6TTrBrsXQmThh6XWnySrYEnDPcgKDUHXlBJuGmzLMM41tp5ktAT9r8RybMox9O+c1QLoCTvswtvV+GwJeafHkwLJEFUY5yo6F3WXzRLfeb0PAzy3VOmvueO0XyLHEbZFschpjf2/TAt60nLgi3n0ySV0FNnkqsMIRZc7D5E3uCMyBCGWT4qwYbkiYxXWsJ0uaFPBDgTnQWWhdBz1EwmlHu+JgSsBq2ehJ6qp50KxOFokp04ynTVFiSsCPBQ5Om2LpSBybFVeak5hzHiYE3OfaV9scYc+vKPcNnmFVRNRRlwkBP7ZcOqdB+CyLxOh7E8opg3VpW8BSo+8FkleibHFTfttE77TbFvCO0B7j6A0pjETCUiWvoi/YaVNsPQvHY2RxF9P2MQe5LzT6qnXf6DuttCngR0Kj7wmOCRXFdsmkJvqoi1oUXFdo9KWY1wAdYGTwAPYilMP+UPB8NLQl4AeWtwtqbmPPQgpjqzn7PCfYbfaZtgQsFUbBkHKsWGwROw+iLqYNAW8I1DxrYEg5pKZMiLoStCFgiXVf4r2fwTfudpQ+r/1KgBWHBE0FvIwwKkoeCB4KALsnaGoEqTCKYEgxOoJR1w2irq9pIuCuQK8rzTVKJ8XYsHSiZBZw2nM0EfCWYBiFeZAcUk6bsF00TRMBwpDxMRDMedygUX+augJeFqrAIV5GgCFleGC5w2gSOO0M6goYo2+cSNodpZMZ1BFwR6DrYBIYUoaRYMGOaplznroKagl4XaDfleYOVThiSBVuEG8dRMlsBnUELG1I9L2yT4f3/UqBqCuHqgLuWj5tbh4YUoYNoT5nxCNvlE3by1BVwJuCa78EAYshGXVd4KicfKqKUdKQl2ihIkKPR2ApMPoWUEXAPcFFfIIhxdgQjrqQtCygimE2BBfxCYYUQzLnMcXmhWKqCFjSkDOsA4rQFQ6fz7B8VExZAUsb8hzLRyKsI3x2m7LGgSHjRDLqIkRdiykrSsnRl2BIMSTtPsWmlcX4IOAZEhkirAqWzBKcdjnKCHhFqOez5hLzXxEQdXlAGQHDkHECu3uADwJG+GyfAUdeUsww/y3HIgH3hA1JELAII+G/f4VpUzkWCXgkXH11yw3cgV0kS2YJTrs8ZQQsCcIoGWB3T1gkYHji+FgW7PusgYBLUrTONxA6eT1JnebtfZ6764eeAsy4OGDG+0snqLPNRHr0ndWweydh9+7c9/ou8ZiEtre4SMDShqQCT9xh57LGP5e54dqgYsnnhPsN3yROe7iMfN7tQgIrz7H2Oam6krD7El8vm6uZcW5F2/0qYfdp6tWOUyTgtdQVu0wTQury+9Enwq+2VJvd58d8j+tbXoc8533I16nfDBdpuydH3z5P49b5fbXRFbPDol/KcFZXc3Z3frR2WcA33L52U2AzxYCbuOlGbjfcj/q4ICoIgaFw1R2x495hu9s+POAePx4mSnhP+OFkN5g8Aff4g0iiwqSXwu9Bo77Yj/mhxHxIREcBtviRdtokePLhPB2+H+qxyzviDlnMeSG+dfIE7IIhXUWJ+RkRPeVR+X1A2XLYPZ8RP3ZZyPsuOPA8AUude+QTnUSYrbzzuwD2LcPui+lziP+YhbwnmfTME7B0+aRvaO+sEh9vPR2RXZg2+USH58rqvKgDduDWk155AoYnrofOmB6ykH2aI8Np16PD8/YHLOJ9m3PkrMzuUoGwQTmUV/4Te2hfgNNuhopgnhPRH23eyywBwxO3gzLoCyL6SfBUvypAwO2gpiE/s5iz9NUqWX8AAm6XEXtlyVMtygC7t0eHk1x/MF2OnCVgeOL2UaPxt0T0jfD2zDz6DmxgCJF77LyNnaedJWB4YnNsc3glXe00D7LP5uhyQdKuCec9L+AhEljGWWWv7JKjhNM2j8pU/9D2Ma3zAoYntsOAk1vS+601sLsd1tnurUVg8wKW3v8bEz32yNKnHxDsbpUVnka1knPACCyLmhN9l9j1JAUEbJchi7jx8iJGYHk6nKGWat+71Pa8DJS+7z82DachYDfQI7FENwzYXI4hi7h24jgp4KUMQQN7qHv/vYCgIGBZ7rHzrrXElBQs5r/y6MSWzaU8CFieUd3mFUkBw5BuMGzikWsAx+0GW3W6kUDAbjLijh82gN3d4XnVrihJAfuwYyYmdiwktXqovHMKvSJRelUAAnabl4aXeLCBwT2WeBtqKbSAOw4W2IOKxqwBBOwmW2WLe7SAh45ucwOfjWmqZhpRl7vslom+tIDhid3mhaE1etjdXQbcvrgQCNgPdGP5tsEI7Dbbi5b5IGB/2DGQp4Dd3abDoXQuELA/KFs9afndYgR2n1FRDkQLGBloP9hu0dl2sQvJG3KLeiBgv+hwKN0GsLk/rOZtN9UCRjWOPzxoyV6wuV9kJjG7KOLwjm5LR3DC5n4xymo+2IUn9pLtFgpvIGD/SB3V04UhvWSQNyeqABy3f2zNF/RgBPaX7YbvHI7bP7rzR/RgBPaX9YbOF3b3k5SAsRboJ52GPaVhdz9ZSzpfCNhvmvSTht395CvHDQH7zVqDXUqwu798Ka2EgP2mW7WHUgLY3V9GehkRWWj/yS10XwAE7C89fY43RmD/qTMC99CBxXs+2b2L0xi8Z6WGDWFz//kyAsOYftOp0Zwdo6//QMABUVXAmDb5j1oL7nfhjYMAI3Cc3EMSKwyqtsZB1BUGyzBkGEDAcbKEEDoMqvbJgs3DYAlJrDDAVChOBhBvOKCiLj76EHA4QMDxAQEHBOa18dFVAp7GfhcCAXPg+OhgBI6Tu9hvQCB0IeA4mcV+A0KhC28cDBBlfEy7MHwwVHHEyHsEApJY4VBFwIi6wmCiBDyJ/S4EQhU7wuZhMIWAw6GKHaeYOgXBpxH4Nva7EADTGmEx7O4/YyXgcex3IQBuanwE2N1/Pgm4jvGBW9QRI+zuPzdKwNex34UAuKrxEWB3/7nWIzCWFfymjoDr/A5wh5kW8Aze2Hsg4Pj4NPDqWuiL2O+Gx0xrOuAxElle80mzWsDnsd8Nj2liOzhuf4GAA6GJCGF3f/lkOy3gMebB3vKxwRtv8rtAjrHOYST3A8OY/jFpOAJfYx7sJV+0mhTwaex3xUM+tPCWYXf/+GL3pIDPsbHBO05aeMMQsF9M80bgWUtfCGCHaUvTnjNsbPCKD8nCq/meWMex3x2POG5xSyDs7g9HyXc6L+BzZKO94ajFN3qYugJcZDwfdWV1pYQx3eey5SKMa6wJe0HKaecJGJsb3GbfwLsz8X+C9lDTpYP5/y1LwFOMwk5za2jOeoI9wk5zlJVszBKw4j16JjnLvkHbvE9dAa6QaZs8AY8xCjvJxHCoe4jKLCc5zksu5wlYsYe5sHOYtoka2d+lrgJJCm1SJOAxEhtOcWPJHkfY7O8Uh3mjLy0QMLHHT02cgQhvLOUl1N94nboKJFAJ5bdFf3eRgKf8xQGynFkuc/2IGmkneLNof0KZ40WP+AsEZFBz3lcCf/m/ODdLlIusdd95yp4P/AoJLTHeCq3P3iL6EmNW1mmXFbD6Av2eugpMcyacSDxoac8xqMabsonEKif0H8KYVlHh628OFNS8wj5xq5zlFW1kUUXAiv+g3M4avzlSVHHLdkdlnnn0vS5NVQGrUeHfmA8bZ8+xLPDHomIC0Aoz1lalZduqAibeyiaRFY2F00Vrf0K8w8Z/o/xeZ0tnHQETG9LFL5nvXDkerr5CM3gj7JVZMsqiroCJPXKtPwoyUbmFXx2fnqj39k+UWrbKcZPluiYCJh72EVY1Z8zi9aFsdcIiRjKzOaecrKxNUwHP+A1AxPXR4vVJEOo9/wMibsQpJ60aTZeaCpgSIk716wEL0ULI3W3iMOq9/x1NEGtx0oZ4qSUBU0LE6OhQHpXN/5vno9gtixiJrfIctJmobEvAmtdcBI9F/2I+8sgbwlbNCX8W7F5azJu29dG2gIk9zK8ov8vlPSeBQtrpo7LT/0KxRy5Ttvle3gvqYkLAxPWcf0Vo9RW6iu11wBHKWxYynPf/ueKpkpF9BP3UlfbQSY6nRLRj8O/4wEVEdeSnPL9/SUSj1LNxsc9hs7G1fZMCJh5p3rD3UQYdpl4RNnccVsbWpldn1x+zAzcV6bnKmKvWjJ+5bVrAGlXj+RciesJG7aReER7nbMSYl1ne84j8gojWU8+Ghz49weiom8SWgIk/0BteL94N2KBj/pwobvmMLhHdJKLnAUdhZ5zfuEw9YxCbAtZcs0HXObxaTb3CTyY84uxju2UmpzyVesg5kUHWizzkkpN3Is0uJASs+ciPDTboWuoVfnDLoj1AE7iFzPheHbKQHxHRkuPvOY8Ldtiih+JLCljzgR9rbNT7nsyRL1m0RyhcqcxdIlrZYrv7EInNOJI4cKVTqwsC1pzzQ+1wesCGXUm9SpYJe9xD23OdQJmxA1SPe0S0zQ7ctfD6inMamScEStKZ/eLS20kxZINusIeWGJnHifnbGUZbK4w46bUhlPSasYP+wA7b2ZUE1wWcpM9h9hqLecXQ+uI1z290RIDdNrIM2eYjtvvQgCO/41H2gp30uS/VZC6F0IuY8Eioi+Y7bMx7nAgZ8s9+4qHo8c879qx3/H9NeHQd81LHNRsRGWS3uOGH3q6qnPYy213bXIXc6qFsrR7qu6Gdu04sapvP213ZXP30L7Iiov8BwaBxF6pf2+QAAAAASUVORK5CYII="/>
                            </svg></span>
                        </div>                            <?php                             
                                if( !empty($item['client_say']) ){
                                    echo '<p class="feedback-text">'.esc_html__( $item['client_say'], 'gommc-core' ).'</p>';
                                }
                            ?>

                        <div class="name-degree">

                            <?php                             
                                if( !empty($item['client_name']) ){
                                    echo '<p class="feedback-name">'.esc_html__( $item['client_name'], 'gommc-core' ).'</p>';
                                }
                            ?>
                            <?php                             
                                if( !empty($item['client_designation']) ){
                                    echo '<p class="feedback-degree">'.esc_html__( $item['client_designation'], 'gommc-core' ).'</p>';
                                }
                            ?>
                        </div>
                    </div>
                    <!-- Testimonial End -->
                </div>
           <?php elseif ($settings['testi_style'] == '3'): ?>

            <div class="feedback-single swiper-slide">
                <?php
                    if( !empty($item['thumbnail']['url']) ){
                        echo '<div class="feedback-image">'.Group_Control_Image_Size::get_attachment_image_html( $item, 'client_imagesize', 'thumbnail' ).'</div>';
                    } 
                ?>
                <div class="feedback-content-wrapper">
                    <div class="feedback-content">
                            <?php                             
                                if( !empty($item['client_say']) ){
                                    echo '<p class="feedback-text">'.esc_html__( $item['client_say'], 'gommc-core' ).'</p>';
                                }
                            ?>
                        <div class="name-degree">

                            <div class="quotes-icon-wrap">
                                <svg 
                                 xmlns="http://www.w3.org/2000/svg"
                                 xmlns:xlink="http://www.w3.org/1999/xlink"
                                 width="42px" height="37px">
                                <path fill-rule="evenodd"  fill="rgb(255, 255, 255)"
                                 d="M42.000,26.804 C42.000,32.435 37.524,36.999 32.002,36.999 C26.480,36.999 22.004,32.435 22.004,26.804 C22.004,26.799 22.005,26.796 22.005,26.791 C21.993,26.493 21.405,10.252 31.749,2.508 C41.077,-4.476 31.014,4.009 28.764,17.167 C29.781,16.811 30.867,16.610 32.002,16.610 C37.524,16.610 42.000,21.174 42.000,26.804 ZM10.007,36.999 C4.485,36.999 0.009,32.435 0.009,26.804 C0.009,26.799 0.010,26.796 0.010,26.791 C-0.002,26.493 -0.590,10.252 9.753,2.508 C19.081,-4.476 9.019,4.009 6.769,17.167 C7.786,16.811 8.872,16.610 10.007,16.610 C15.529,16.610 20.005,21.174 20.005,26.804 C20.005,32.435 15.529,36.999 10.007,36.999 Z"/>
                                </svg>
                            </div> 

                            <div class="quotes-name-degree-wrap">
                                <?php                             
                                    if( !empty($item['client_name']) ){
                                        echo '<p class="feedback-name">'.esc_html__( $item['client_name'], 'gommc-core' ).'</p>';
                                    }
                                ?>
                                <?php                             
                                    if( !empty($item['client_designation']) ){
                                        echo '<p class="feedback-degree">'.esc_html__( $item['client_designation'], 'gommc-core' ).'</p>';
                                    }
                                ?>
                            </div>  

                        </div>
         
                       
                    </div>
                </div>
            </div>

            <?php endif ?>
            <?php

            } ?>
        </div>
        <!-- If we need navigation buttons -->
        <?php if ($settings['use_prev_next']): ?>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        <?php endif ?>
       <?php if ($settings['use_pagination']): ?>
            <div class="swiper-pagination"></div>
        <?php endif ?>
    </div>
</div>   

<?php endif; // End only for style 1,2,3?>

<!-- ==== Start feedback style 4 ==== -->
<?php if ($settings['testi_style'] == '4'): ?>

<div class="gommc-dubble-feedback gommc-feedback-style-<?php echo $settings['testi_style']; ?>">
    
        <div class="feedback-author">
            <div class="feedback-author-wrapper">

                <div class="feedback-quote">
                   <svg 
                         xmlns="http://www.w3.org/2000/svg"
                         xmlns:xlink="http://www.w3.org/1999/xlink"
                         width="42px" height="37px">
                        <path fill-rule="evenodd"  fill="rgb(255, 255, 255)"
                         d="M42.000,26.804 C42.000,32.435 37.524,36.999 32.002,36.999 C26.480,36.999 22.004,32.435 22.004,26.804 C22.004,26.799 22.005,26.796 22.005,26.791 C21.993,26.493 21.405,10.252 31.749,2.508 C41.077,-4.476 31.014,4.009 28.764,17.167 C29.781,16.811 30.867,16.610 32.002,16.610 C37.524,16.610 42.000,21.174 42.000,26.804 ZM10.007,36.999 C4.485,36.999 0.009,32.435 0.009,26.804 C0.009,26.799 0.010,26.796 0.010,26.791 C-0.002,26.493 -0.590,10.252 9.753,2.508 C19.081,-4.476 9.019,4.009 6.769,17.167 C7.786,16.811 8.872,16.610 10.007,16.610 C15.529,16.610 20.005,21.174 20.005,26.804 C20.005,32.435 15.529,36.999 10.007,36.999 Z"/>
                        </svg>
                </div>

                <div class="author-images-wrapper author-images-active">
                     <div class="gommc__carousel">   
                        <div class="lmsmaer_feedback_id<?php echo $id; ?>">
                            <div class="swiper-wrapper">
                                <?php      
                                    foreach ($settings['list'] as $index => $item) {

                                        if( !empty($item['thumbnail']['url']) ){
                                            echo '<div class="swiper-slide author-image">'.Group_Control_Image_Size::get_attachment_image_html( $item, 'client_imagesize', 'thumbnail' ).'</div>';
                                        } 
                                } ?>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

      <div class="feedback-content feedback-content-active">

         <div class="gommc__carousel">   
            <div class="lmsmaer_feedback_id<?php echo $id; ?>">
                <div class="swiper-wrapper">
              <?php      
                    foreach ($settings['list'] as $index => $item) {
                   ?>
                <div class="swiper-slide single-feedback-content">
                        <?php                             
                            if( !empty($item['client_say']) ){
                                echo '<p class="feedback-text">'.esc_html__( $item['client_say'], 'gommc-core' ).'</p>';
                            }
                        ?>
                        <div class="quotes-name-degree-wrap">
                            <?php                             
                                if( !empty($item['client_name']) ){
                                    echo '<p class="feedback-name">'.esc_html__( $item['client_name'], 'gommc-core' ).'</p>';
                                }
                            ?>
                            <?php                             
                                if( !empty($item['client_designation']) ){
                                    echo '<p class="feedback-degree">'.esc_html__( $item['client_designation'], 'gommc-core' ).'</p>';
                                }
                            ?>
                        </div> 
                </div>
            <?php } ?>

                        </div>

            <?php if ($settings['use_pagination']): ?>
                <div class="swiper-pagination"></div>
            <?php endif ?>

         </div>

            <!-- If we need navigation buttons -->
            <?php if ($settings['use_prev_next']): ?>
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            <?php endif ?>

        </div>
    </div>
</div>
<!-- ==== Start feedback style 5 ==== -->
<?php elseif ($settings['testi_style'] == '5'): ?>

<div class="gommc-dubble-feedback gommc-feedback-style-<?php echo $settings['testi_style']; ?>">

        <img class="shape-1 tpc-animate-03" src="https://thepixelcurve.com/html/gommc/gommc/assets/images/shape/shape-19.svg" alt="shape">
        <img class="shape-2 tpc-animate-01" src="https://thepixelcurve.com/html/gommc/gommc/assets/images/shape/shape-20.svg" alt="shape">

        <div class="feedback-author">
            <div class="feedback-author-wrapper">

                <div class="feedback-quote">
                   <svg 
                         xmlns="http://www.w3.org/2000/svg"
                         xmlns:xlink="http://www.w3.org/1999/xlink"
                         width="42px" height="37px">
                        <path fill-rule="evenodd"  fill="rgb(255, 255, 255)"
                         d="M42.000,26.804 C42.000,32.435 37.524,36.999 32.002,36.999 C26.480,36.999 22.004,32.435 22.004,26.804 C22.004,26.799 22.005,26.796 22.005,26.791 C21.993,26.493 21.405,10.252 31.749,2.508 C41.077,-4.476 31.014,4.009 28.764,17.167 C29.781,16.811 30.867,16.610 32.002,16.610 C37.524,16.610 42.000,21.174 42.000,26.804 ZM10.007,36.999 C4.485,36.999 0.009,32.435 0.009,26.804 C0.009,26.799 0.010,26.796 0.010,26.791 C-0.002,26.493 -0.590,10.252 9.753,2.508 C19.081,-4.476 9.019,4.009 6.769,17.167 C7.786,16.811 8.872,16.610 10.007,16.610 C15.529,16.610 20.005,21.174 20.005,26.804 C20.005,32.435 15.529,36.999 10.007,36.999 Z"/>
                        </svg>
                </div>

                <div class="author-images-wrapper author-images-active">
                     <div class="gommc__carousel">   
                        <div class="lmsmaer_feedback_id<?php echo $id; ?>">
                            <div class="swiper-wrapper">
                                <?php      
                                    foreach ($settings['list'] as $index => $item) {

                                        if( !empty($item['thumbnail']['url']) ){
                                            echo '<div class="swiper-slide author-image">'.Group_Control_Image_Size::get_attachment_image_html( $item, 'client_imagesize', 'thumbnail' ).'</div>';
                                        } 
                                } ?>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

      <div class="feedback-content feedback-content-active">

         <div class="gommc__carousel">   
            <div class="lmsmaer_feedback_id<?php echo $id; ?>">
                <div class="swiper-wrapper">
              <?php      
                    foreach ($settings['list'] as $index => $item) {
                   ?>
                <div class="swiper-slide single-feedback-content">
                        <?php                             
                            if( !empty($item['client_say']) ){
                                echo '<p class="feedback-text">'.esc_html__( $item['client_say'], 'gommc-core' ).'</p>';
                            }
                        ?>
                        <div class="quotes-name-degree-wrap">
                            <?php                             
                                if( !empty($item['client_name']) ){
                                    echo '<p class="feedback-name">'.esc_html__( $item['client_name'], 'gommc-core' ).'</p>';
                                }
                            ?>
                            <?php                             
                                if( !empty($item['client_designation']) ){
                                    echo '<p class="feedback-degree">'.esc_html__( $item['client_designation'], 'gommc-core' ).'</p>';
                                }
                            ?>
                        </div> 
                </div>
            <?php } ?>

                        </div>

            <?php if ($settings['use_pagination']): ?>
                <div class="swiper-pagination"></div>
            <?php endif ?>

         </div>

            <!-- If we need navigation buttons -->
            <?php if ($settings['use_prev_next']): ?>
                <div class="swiper-button-prev"></div>
                <div class="swiper-button-next"></div>
            <?php endif ?>

        </div>
    </div>
</div>
<?php endif; ?>

<script>
jQuery(document).ready(function() {
    new Swiper('.lmsmaer_feedback_id<?php echo $id; ?>', {
        <?php if ($settings['infinite']): ?>
            loop: true,
        <?php endif ?>
          
        <?php if ($settings['autoplay']): ?>
          autoplay: {
            delay: <?php echo esc_attr($settings['autoplay_speed']); ?>,
          },
        <?php endif ?>
          pagination: {
            el: ".swiper-pagination",
            clickable: true,
          },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        },
        <?php if (!$settings['testi_style'] == '4' || !$settings['testi_style'] == '5' && $settings['coverflow_effect']): ?>   
            effect: 'coverflow',
            coverflowEffect: {
                rotate: 30,
                slideShadows: false,
            },
        <?php elseif ($settings['testi_style'] == '4' || $settings['testi_style'] == '5'): ?>   
          fadeEffect: { crossFade: true },
          effect: "fade",
        <?php endif ?>

        breakpoints: {
            1200: {
                slidesPerView: <?php echo $settings['item_grid'] ?>,
                spaceBetween: <?php echo $settings['space_between'] ?>
            },
            <?php echo $settings['tablet_width'] ?>: {
                slidesPerView: <?php echo $settings['tablet_item'] ?>,
                spaceBetween: <?php echo $settings['space_between'] ?>
            },
            <?php echo $settings['mobile_width'] ?>: {
                slidesPerView: <?php echo $settings['mobile_item'] ?>,
                spaceBetween: <?php echo $settings['space_between'] ?>
            }
        }
    });
});
</script>
<?php

    }

}
