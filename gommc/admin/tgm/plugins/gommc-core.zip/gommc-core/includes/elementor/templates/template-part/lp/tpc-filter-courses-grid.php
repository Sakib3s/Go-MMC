<?php

if (class_exists('LearnPress')) {

$_   = $this->get_settings_for_display();

$course    = LP()->global['course'];
$course_id = get_the_ID();
$count = $course->get_users_enrolled();

?>

<?php if ($_['course_style'] == '3'): ?>

<article class="tpc-course">
    <?php if ($_['show_hover_popup']): ?>
        <div class="course__popup-wrap">

                <?php if ($_['show_instructor_img'] && $_['show_instructor_name']): ?>
                    <div class="tpc-course-author-name">
                        <?php if ($_['show_instructor_img']): ?>
                            <?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
                         <?php endif; ?>
                        <?php if ($_['show_instructor_name']): ?>
                            <?php echo get_the_author(); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

              <div class="courses-content">

                <div class="course__top-meta">
                     <?php if ($_['show_popup_cat']): ?>
                        <div class="course__categories ">
                            <?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
                        </div>
                     <?php endif; ?>
                    <?php if ($_['show_popup_price']): ?>
                     <div class="price">
                          <?php get_template_part('templates/learnpress/price_within_button_2'); ?>
                     </div>
                    <?php endif; ?>
                </div>

                <?php if ($_['show_popup_title']): ?>
                <h4 class="course__title">
                    <a href="<?php the_permalink(); ?>" class="course__title-link">
                        <?php the_title(); ?>
                    </a>
                </h4>
                <?php endif; ?>
             </div>
            <div class="course__content--meta"> 

                <?php if ($_['show_popup_lesson']): 
                        $course = \LP_Global::course();
                        $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
                        $lessons_text = ('1' == $lessons) ? esc_html__('Lesson', 'gommc-core') : esc_html__('Lessons', 'gommc-core');
                        printf('<span class="course-lessons"> <i class="flaticon-book-1"></i>  %s %s</span>', $lessons, $lessons_text);
                 endif; ?>
                <?php if ($_['show_popup_duration']): ?>
                    <span class="course-lessons">
                    <i class="flaticon-wall-clock"> </i> <?php echo learn_press_get_post_translated_duration( get_the_ID(), esc_html__( ' Lifetime access', 'gommc-core' ) ); ?>
                    </span>
                <?php endif; ?>

            </div>

            <?php if ($_['show_popup_excerpt']): ?>
             <div class="course__excerpt">
                <?php the_excerpt(); ?> 
            </div>
            <?php endif; ?>
            <?php if ($_['show_popup_btn']): ?>
            <div class="btn__wrap">
                <a class="btn__a" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Preview This Course', 'gommc-core' ); ?></a>
            </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    <div class="course__container">

            <?php if ($_['show_media']): ?>
            <div class="course__media">

                <?php if ( has_post_thumbnail() ):?>
                  <a class="course__media-link" href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail('medium');?>
                  </a>
                 <?php endif; ?>
            </div>
        <?php endif ?>

        <div class="course__content">
            <div class="course__content--info">
                <div class="course__top-meta">

                    <?php if ($_['show_cat']): ?>
                        <div class="course__categories ">
                            <?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
                        </div>
                     <?php endif; ?>
                    <?php if ($_['show_price']): ?>
                     <div class="price">
                          <?php get_template_part('templates/learnpress/price_within_button_2'); ?>
                     </div>
                    <?php endif; ?>
                </div>
                    <?php if ($_['show_instructor_img']): ?>
                    <?php         
                        ob_start();
                        learn_press_courses_loop_item_instructor();
                        $author_name = ob_get_clean();
                    ?>
                <?php endif; ?>

                    <?php if ($_['show_instructor_img']): ?>
                <h4 class="course__title">
                    <a href="<?php the_permalink(); ?>" class="course__title-link">
                        <?php the_title(); ?>
                    </a>
                </h4>
                <?php endif; ?>
                <?php if ($_['show_instructor_img'] && $_['show_instructor_name']): ?>
                    <div class="tpc-course-author-name">
                        <?php if ($_['show_instructor_img']): ?>
                            <?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
                         <?php endif; ?>
                        <?php if ($_['show_instructor_name']): ?>
                            <?php echo get_the_author(); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="course__content--meta"> 
                <div class="course__meta-left">
                     <?php if ($_['show_enroll']): ?>
                            <?php $students = (int)learn_press_get_course()->count_students(); ?>
                            <span class="course-students"><i class="flaticon-user-2"></i> <?php echo esc_html($students); ?> </span>
                    <?php endif; ?>

                     <?php if ($_['show_lesson']): ?>
                        <?php         
                            $course = \LP_Global::course();
                            $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
                            printf('<span class="course-lessons"><i class="flaticon-book-1"></i> %s </span>', $lessons);
                        ?>
                    <?php endif; ?>
                </div>
                <?php if ($_['show_review'] && class_exists('LP_Addon_Course_Review_Preload')): ?>
                <div class="course__meta-right">
                    <div class="course__review">
                
                        <?php
                            $course_id       = get_the_ID();
                            $course_rate_res = learn_press_get_course_rate( $course_id, false );
                            $course_rate     = $course_rate_res['rated'];
                            $total           = $course_rate_res['total'];
                            learn_press_course_review_template( 'rating-stars.php', array( 'rated' => $course_rate ) );
                        ?>
                    </div>
                </div>
                 <?php endif; ?>
               
            </div>
        </div>
    </div>

</article>

<?php elseif ($_['course_style'] == '2'): ?>
<article class="tpc-course">
        <?php if ($_['show_hover_popup']): ?>
        <div class="course__popup-wrap">

              <div class="courses-content">

                <div class="course__top-meta">
                     <?php if ($_['show_popup_cat']): ?>
                        <div class="course__categories ">
                            <?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
                        </div>
                     <?php endif; ?>
                     <div class="price">
                          <?php get_template_part('templates/learnpress/price_within_button_2'); ?>
                     </div>
                </div>

                <?php if ($_['show_popup_title']): ?>
                <h4 class="course__title">
                    <a href="<?php the_permalink(); ?>" class="course__title-link">
                        <?php the_title(); ?>
                    </a>
                </h4>
                <?php endif; ?>
                <?php if ($_['show_review'] && class_exists('LP_Addon_Course_Review_Preload')): ?>
                    <div class="course__review">
                
                        <?php
                            $course_id       = get_the_ID();
                            $course_rate_res = learn_press_get_course_rate( $course_id, false );
                            $course_rate     = $course_rate_res['rated'];
                            $total           = $course_rate_res['total'];
                            learn_press_course_review_template( 'rating-stars.php', array( 'rated' => $course_rate ) );
                        ?>
                    </div>
                 <?php endif; ?>
             </div>
            <div class="course__content--meta"> 

                <?php if ($_['show_lesson']): 
                        $course = \LP_Global::course();
                        $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
                        $lessons_text = ('1' == $lessons) ? esc_html__('Lesson', 'gommc-core') : esc_html__('Lessons', 'gommc-core');
                        printf('<span class="course-lessons"> <i class="flaticon-book-1"></i>  %s %s</span>', $lessons, $lessons_text);
                 endif; ?>
                <?php if ($_['show_popup_duration']): ?>
                    <span class="course-lessons">
                    <i class="flaticon-wall-clock"> </i> <?php echo learn_press_get_post_translated_duration( get_the_ID(), esc_html__( ' Lifetime access', 'gommc-core' ) ); ?>
                    </span>
                <?php endif; ?>

            </div>
             <div class="course__excerpt">
                <?php the_excerpt(); ?> 
            </div>

            <div class="btn__wrap">
                <a class="btn__a" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Preview This Course', 'gommc-core' ); ?></a>
            </div>
        </div>
        <?php endif ?>
    <div class="course__container">

        <?php if ($_['show_media']): ?>
            <div class="course__media">

                <?php if ( has_post_thumbnail() ):?>
                  <a class="course__media-link" href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail('medium');?>
                  </a>
                 <?php endif; ?>
            </div>
        <?php endif ?>

        <div class="course__content">
            <div class="course__content--info">
                <div class="course__top-meta">

                     <?php if ($_['show_cat']): ?>
                        <div class="course__categories ">
                            <?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
                        </div>
                     <?php endif; ?>
                         <div class="price-round">
                             <?php get_template_part('templates/learnpress/price_within_button'); ?>
                        </div>
                </div>
                <?php if ($_['show_title']): ?>
                    <?php         
                        ob_start();
                        learn_press_courses_loop_item_instructor();
                        $author_name = ob_get_clean();
                    ?>
                <?php endif; ?>

                <?php if ($_['show_title']): ?>
                <h4 class="course__title">
                    <a href="<?php the_permalink(); ?>" class="course__title-link">
                        <?php the_title(); ?>
                    </a>
                </h4>
                <?php endif; ?>
                <?php if ($_['show_instructor_img'] && $_['show_instructor_name']): ?>
                    <div class="tpc-course-author-name">
                        <?php if ($_['show_instructor_img']): ?>
                            <?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
                         <?php endif; ?>
                        <?php if ($_['show_instructor_name']): ?>
                            <?php echo get_the_author(); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="course__content--meta"> 
                <div class="course__meta-left">
                    <?php if ($_['show_enroll']): ?>
                            <?php $students = (int)learn_press_get_course()->count_students(); ?>
                            <span class="course-students"><i class="flaticon-user-2"></i> <?php echo esc_html($students); ?> </span>
                    <?php endif; ?>

                    <?php if ($_['show_lesson']):       
                            $course = \LP_Global::course();
                            $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
                            printf('<span class="course-lessons"><i class="flaticon-book-1"></i> %s </span>', $lessons);
                        ?>
                    <?php endif; ?>
                </div>
                <?php if ($_['show_review'] && class_exists('LP_Addon_Course_Review_Preload')): ?>
                <div class="course__meta-right">
                    <div class="course__review">
                
                        <?php
                            $course_id       = get_the_ID();
                            $course_rate_res = learn_press_get_course_rate( $course_id, false );
                            $course_rate     = $course_rate_res['rated'];
                            $total           = $course_rate_res['total'];
                            learn_press_course_review_template( 'rating-stars.php', array( 'rated' => $course_rate ) );
                        ?>
                    </div>
                </div>
                 <?php endif; ?>
               
            </div>
        </div>
    </div>

</article>
<?php else : ?> 
<article class="tpc-course">

        <?php if ($_['show_hover_popup']): ?>
        <div class="course__popup-wrap">

              <div class="courses-content">

                <div class="course__top-meta">
                     <?php if ($_['show_popup_cat']): ?>
                        <div class="course__categories ">
                            <?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
                        </div>
                     <?php endif; ?>
                     <div class="price">
                          <?php get_template_part('templates/learnpress/price_within_button_2'); ?>
                     </div>
                </div>

                <?php if ($_['show_popup_title']): ?>
                <h4 class="course__title">
                    <a href="<?php the_permalink(); ?>" class="course__title-link">
                        <?php the_title(); ?>
                    </a>
                </h4>
                <?php endif; ?>
                <?php if ($_['show_review'] && class_exists('LP_Addon_Course_Review_Preload')): ?>
                    <div class="course__review">
                
                        <?php
                            $course_id       = get_the_ID();
                            $course_rate_res = learn_press_get_course_rate( $course_id, false );
                            $course_rate     = $course_rate_res['rated'];
                            $total           = $course_rate_res['total'];
                            learn_press_course_review_template( 'rating-stars.php', array( 'rated' => $course_rate ) );
                        ?>
                    </div>
                 <?php endif; ?>
             </div>
            <div class="course__content--meta"> 

                <?php if ($_['show_lesson']): 
                        $course = \LP_Global::course();
                        $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
                        $lessons_text = ('1' == $lessons) ? esc_html__('Lesson', 'gommc-core') : esc_html__('Lessons', 'gommc-core');
                        printf('<span class="course-lessons"> <i class="flaticon-book-1"></i>  %s %s</span>', $lessons, $lessons_text);
                 endif; ?>
                    <?php if ($_['show_duration']): ?>
                    <span class="course-lessons">
                    <i class="flaticon-wall-clock"> </i> <?php echo learn_press_get_post_translated_duration( get_the_ID(), esc_html__( ' Lifetime access', 'gommc-core' ) ); ?>
                    </span>
                <?php endif; ?>

            </div>
             <div class="course__excerpt">
                <?php the_excerpt(); ?> 
            </div>

            <div class="btn__wrap">
                <a class="btn__a" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Preview This Course', 'gommc-core' ); ?></a>
            </div>
        </div>
        <?php endif ?>
    <div class="course__container">

        <?php if ($_['show_media']): ?>
            <div class="course__media">

                <?php if ( has_post_thumbnail() ):?>
                  <a class="course__media-link" href="<?php the_permalink(); ?>">
                    <?php the_post_thumbnail('medium');?>
                  </a>
                 <?php endif; ?>
            </div>
        <?php endif ?>

        <div class="course__content">
            <div class="course__content--info">
                <div class="course__top-meta">

                     <?php if ($_['show_cat']): ?>
                        <div class="course__categories ">
                            <?php echo get_the_term_list(get_the_ID(), 'course_category'); ?>
                        </div>
                     <?php endif; ?>
                </div>
                <?php if ($_['show_title']): ?>
                    <?php         
                        ob_start();
                        learn_press_courses_loop_item_instructor();
                        $author_name = ob_get_clean();
                    ?>
                <?php endif; ?>

                <?php if ($_['show_title']): ?>
                <h4 class="course__title">
                    <a href="<?php the_permalink(); ?>" class="course__title-link">
                        <?php the_title(); ?>
                    </a>
                </h4>
                <?php endif; ?>
                <?php if ($_['show_instructor_img'] && $_['show_instructor_name']): ?>
                    <div class="tpc-course-author-name">
                        <?php if ($_['show_instructor_img']): ?>
                            <?php echo get_avatar( get_the_author_meta( 'ID' ), 32 ); ?>
                         <?php endif; ?>
                        <?php if ($_['show_instructor_name']): ?>
                            <?php echo get_the_author(); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="course__content--meta"> 
                <div class="course__meta-left">

                <?php if ($_['show_enroll']): ?>
                        <?php $students = (int)learn_press_get_course()->count_students(); ?>
                        <span class="course-students"><i class="flaticon-user-2"></i> <?php echo esc_html($students); ?> </span>
                <?php endif; ?>

                <?php if ($_['show_lesson']): ?>
                    <?php         
                        $course = \LP_Global::course();
                        $lessons = $course->get_items('lp_lesson', false) ? count($course->get_items('lp_lesson', false)) : 0;
                        printf('<span class="course-lessons"><i class="flaticon-book-1"></i> %s </span>', $lessons);
                    ?>
                <?php endif; ?>

                <?php if ($_['show_review'] && class_exists('LP_Addon_Course_Review_Preload')) : ?>
                <?php 
                    $total_reviews = learn_press_get_course_rate_total(get_the_ID());
                    $reviews_title = !empty($total_reviews) ? sprintf(_n('review is submitted', 'reviews are submitted', $total_reviews, 'gommc-core'), number_format_i18n($total_reviews)) : esc_html__('No any reviews yet', 'gommc-core');
                    printf(
                        '<span class="course-reviews" title="%1$s %2$s"><i class="flaticon-star-1"></i> %1$d </span>',
                        $total_reviews,
                        $reviews_title,
                    );
                 ?>
                 <?php endif; ?>
                </div>

                 <?php if ($_['show_enroll_btn']): ?>    
                    <div class="course__meta-right">
                         <div class="price">
                             <?php get_template_part('templates/learnpress/price_within_button_2'); ?>
                        </div>
                     </div>
                 <?php endif ?>
            </div>
        </div>
    </div>

</article>
<?php endif ?>
<?php } //if class exist learnpress ?>