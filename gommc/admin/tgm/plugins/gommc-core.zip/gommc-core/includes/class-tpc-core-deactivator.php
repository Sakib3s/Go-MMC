<?php
/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 * 
 * 
 * @link https://github.com/Sakib3s/Go-MMC
 *
 * @package oxiz-core\includes
 * @author MMC 
 * @since 1.0.0
 */
class GoMMC_Core_Deactivator
{
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate()
	{
	}
}
