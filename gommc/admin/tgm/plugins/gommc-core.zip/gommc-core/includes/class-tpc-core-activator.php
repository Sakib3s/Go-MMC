<?php
/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 * 
 * 
 * @link https://github.com/Sakib3s/Go-MMC
 *
 * @package oxiz-core\includes
 * @author MMC 
 * @since 1.0.0
 */
class GoMMC_Core_Activator
{
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate()
	{
	}
}
