<?php
/**
 * @link              https://github.com/Sakib3s/Go-MMC
 * @since             1.0.0
 * @package           lmsgommc-core
 *
 * @wordpress-plugin
 * Plugin Name:       GoMMC Core
 * Plugin URI:        https://github.com/Sakib3s/Go-MMC
 * Description:       Core plugin for GoMMC Theme.
 * Version:           1.0.0
 * Author:            Diploma in Engineering, Computer Technology (Session 18-19) Madan Mohan College, Sylhet
 * Author URI:        https://github.com/Sakib3s/Go-MMC
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       gommc-core
 * Domain Path:       /languages
 */

defined('WPINC') || die; // Abort, if called directly.


/**
 * Current version of the plugin.
 */
$plugin_data = get_file_data(__FILE__, ['version' => 'Version']);
define('TPC_CORE_VERSION', $plugin_data['version']);

class GoMMC_CorePlugin
{
    private static $minimum_php_version = '7.0';

    public function __construct()
    {
        add_action('admin_init', [$this, 'check_version']);
        if (!self::theme_is_compatible()) {
            return;
        }

        if (version_compare(PHP_VERSION, self::$minimum_php_version, '<')) {
            add_action('admin_notices', [$this, 'fail_php_version']);
        }

        add_action( 'init', array ( $this, 'gommc_after_setup_theme' ) );
    }

    /**
     * The backup sanity check, in case the plugin is activated in a weird way,
     * or the theme change after activation.
     */
    public function check_version()
    {
        if (
            !self::theme_is_compatible()
            && is_plugin_active(plugin_basename(__FILE__))
        ) {
            deactivate_plugins(plugin_basename(__FILE__));
            add_action('admin_notices', [$this, 'disabled_notice']);
            if (isset($_GET['activate'])) {
                unset($_GET['activate']);
            }
        }
    }

    public function fail_php_version()
    {
        $message = sprintf(
            __('GoMMC Core plugin requires PHP version %s+. Your current PHP version is %s.', 'gommc-core'),
            self::$minimum_php_version,
            PHP_VERSION
        );

        echo '<div class="error"><p>', esc_html($message), '</p></div>';
    }

    // Add Image size
    public function gommc_after_setup_theme() {
        add_image_size('team_thumb', 340, 480, true);
    }

    public static function activation_check()
    {
        if (!self::theme_is_compatible()) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(__('GoMMC Core plugin compatible with GoMMC theme only!', 'gommc-core'));
        }
    }

    public function disabled_notice()
    {
        echo '<strong>',
            esc_html__('GoMMC Core plugin compatible with GoMMC theme only!', 'gommc-core'),
        '</strong>';
    }

    public static function theme_is_compatible()
    {
        $plugin_name = trim(dirname(plugin_basename(__FILE__)));
        $theme_name = self::get_theme_slug();

        return false !== stripos($plugin_name, $theme_name);
    }

    public static function get_theme_slug()
    {
        return str_replace('-child', '', wp_get_theme()->get('TextDomain'));
    }
}

new GoMMC_CorePlugin();

register_activation_hook(__FILE__, ['GoMMC_CorePlugin', 'activation_check']);


/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-tpc-core-activator.php
 */
function activate_gommc_core()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-tpc-core-activator.php';
    GoMMC_Core_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-tpc-core-deactivator.php
 */
function deactivate_gommc_core()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-tpc-core-deactivator.php';
    GoMMC_Core_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_gommc_core');
register_deactivation_hook(__FILE__, 'deactivate_gommc_core');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path(__FILE__) . 'includes/class-tpc-core.php';

/**
 * Start execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since 1.0.0
 */
function run_gommc_core()
{
    (new GoMMC_Core())->run();
}

run_gommc_core();



/*=============================================
=  * Get Taxonomy for tutor lms * return array   =
=============================================*/
if (!function_exists('gommc_tutor_get_taxonomies')) {
    function gommc_tutor_get_taxonomies($tutor_course_category = 'mec_category')
    {
        $terms = get_terms(array(
            'taxonomy'   => $tutor_course_category,
            'hide_empty' => false,
        ));
        if (!empty($terms) && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                $options[$term->slug] = $term->name;
            }
            return $options;
        }
    }
}




